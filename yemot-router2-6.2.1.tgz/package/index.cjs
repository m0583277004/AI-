'use strict';

var colors = require('colors');
var ms = require('ms');
var express = require('express');
var EventEmitter = require('events');

class CallError extends Error {
    constructor ({ message, call }) {
        super();

        this.name = 'CallError';
        this.message = message;
        this.call = call;
        this.date = new Date();
    }
}

class ExitError extends CallError {
    constructor (call, context) {
        super({ call, message: 'the call was exited from the extension (by go_to_folder or id_list_message)' });

        this.name = 'ExitError';
        this.context = context;
    }
}

class HangupError extends CallError {
    constructor (call) {
        super({ call, message: 'the call was hangup by the caller' });

        this.name = 'HangupError';
    }
}

class TimeoutError extends CallError {
    constructor (call, timeout) {
        super({ call, message: 'timeout for receiving a response from the caller' });

        this.name = 'TimeoutError';
        this.timeout = timeout;
    }
}

const dataTypes = {
    file: 'f',
    text: 't',
    speech: 's',
    digits: 'd',
    number: 'n',
    alpha: 'a',
    zmanim: 'z',
    go_to_folder: 'g',
    system_message: 'm',
    music_on_hold: 'h',
    date: 'date',
    dateH: 'dateH'
};

/**
 * @param {String} messagesCombined
 * @param {Object} options
 * @returns {String} - the read text
 */
function makeTapModeRead (messagesCombined, options, call) {
    const PRESETS_MIN_MAX = { // from yemot docs https://f2.freeivr.co.il/post/77520
        Date: { min_digits: 8, max_digits: 8 },
        HebrewDate: { min_digits: 8, max_digits: 8 },
        Time: { min_digits: 4, max_digits: 4 },
        TeudatZehut: { min_digits: 8, max_digits: 9 },
        Phone: { min_digits: 9, max_digits: 10 }
    };

    if (options.typing_playback_mode && PRESETS_MIN_MAX[options.typing_playback_mode]) {
        options.min_digits = PRESETS_MIN_MAX[options.typing_playback_mode].min_digits;
        options.max_digits = PRESETS_MIN_MAX[options.typing_playback_mode].max_digits;
    }

    if (options.digits_allowed && !Array.isArray(options.digits_allowed)) {
        throw new CallError({ message: `digits_allowed must be array, got ${typeof options.digits_allowed} (${options.digits_allowed})`, call });
    }

    const tapOps = [
        options.valName,
        options.re_enter_if_exists ? 'yes' : 'no',
        (options.max_digits || ''),
        (options.min_digits || 1),
        (options.sec_wait || 7),
        (options.typing_playback_mode || 'No'),
        options.block_asterisk_key ? 'yes' : 'no',
        options.block_zero_key ? 'yes' : 'no',
        options.replace_char,
        options.digits_allowed ? options.digits_allowed.join('.') : '',
        (options.amount_attempts || ''),
        (options.allow_empty ? 'Ok' : ''),
        (typeof options.empty_val === 'undefined' ? '' : String(options.empty_val)),
        (options.block_change_keyboard ? 'InsertLettersTypeChangeNo' : '')
    ];
    return `read=${messagesCombined}=${tapOps.join(',')}`;
}
/**
 * @param {String} messagesCombined
 * @param {Object} options
 * @returns {String} - the read text
 */
function makeSttModeRead (messagesCombined, options, call) {
    if (options.use_records_recognition_engine) {
        if (typeof options.block_typing !== 'undefined') {
            throw new CallError({ message: 'block_typing setting option is not available when use_records_recognition_engine is true - typing is always blocked in records recognition engine', call });
        }
    } else {
        if (options.quiet_max) {
            throw new CallError({ message: 'quiet_max option is only available when use_records_recognition_engine is true', call });
        } else if (options.length_max) {
            throw new CallError({ message: 'length_max option are only available when use_records_recognition_engine is true', call });
        }
    }

    const sttOps = [
        options.valName,
        options.re_enter_if_exists ? 'yes' : 'no',
        'voice',
        options.lang,
        (options.block_typing ? 'no' : ''),
        (options.max_digits || ''),
        (options.quiet_max || ''),
        (options.max_length || ''),
        (options.use_records_recognition_engine ? 'record' : '')
    ];
    return `read=${messagesCombined}=${sttOps.join(',')}`;
}
/**
 * @param {String} messagesCombined
 * @param {Object} options (record options)
 * @returns {String} - the read text
 */
function makeRecordModeRead (messagesCombined, options, call) {
    const recordOps = [
        options.valName,
        options.re_enter_if_exists ? 'yes' : 'no',
        'record',
        options.path,
        options.file_name,
        (options.no_confirm_menu ? 'no' : ''),
        (options.save_on_hangup ? 'yes' : ''),
        (options.append_to_existing_file ? 'yes' : ''),
        (options.min_length || ''),
        (options.max_length || '')
    ];
    return `read=${messagesCombined}=${recordOps.join(',')}`;
}
function validateCharsForTTS (text, call) {
    const invalidCharsRgx = /[.\-"'&|]/g;
    const invalidCharsMatched = text.match(invalidCharsRgx);
    if (invalidCharsMatched) {
        throw new CallError({ message: `message '${text}' has invalid characters for yemot: ${colors.red(invalidCharsMatched.join(', '))}`, call });
    }
}

function removeInvalidChars (text) {
    const invalidCharsRgx = /[.\-"'&|]/g;
    const invalidCharsMatched = text.match(invalidCharsRgx);
    if (invalidCharsMatched) {
        console.log(`invalid characters for yemot have been removed from the text: ${colors.red(invalidCharsMatched.join(''))} [original text: ${text}]`);
    }
    return text.replaceAll(invalidCharsRgx, '');
}

function makeMessagesData (messages, options, call) {
    for (const msg of messages) {
        if (typeof msg.data !== 'string') continue;
        if (msg.type === 'text' && (msg.removeInvalidChars ?? options.removeInvalidChars)) {
            msg.data = removeInvalidChars(msg.data);
        } else {
            validateCharsForTTS(msg.data, call);
        }
    }

    let res = '';
    let i = 1;
    for (const value of messages) {
        if (i > 1) res += '.';

        if (typeof value.type !== 'string') {
            throw new CallError({ message: `type must be a string, got ${typeof value.type}`, call });
        }
        if (!dataTypes[value.type]) {
            throw new CallError({ message: `${value.type} is not a valid type!\nValid types are: ${Object.keys(dataTypes).join(', ')}`, call });
        }

        res += dataTypes[value.type] + '-';

        switch (value.type) {
        case 'zmanim': {
            if (typeof value.data !== 'object') throw new CallError({ message: 'in "zmanim" type, data should be an object', call });
            let differenceSplitted;
            if (value.data.difference) {
                if (!/(-|\+)[YMDHmSs]\d+/.test(value.data.difference)) throw new CallError({ message: 'difference is invalid', call });
                differenceSplitted = value.data.difference.match(/(-|\+)(.+)/);
            }
            res += [
                value.data.time || 'T',
                value.data.zone || 'IL/Jerusalem',
                differenceSplitted ? differenceSplitted[1] : '',
                differenceSplitted ? differenceSplitted[2] : ''
            ].join(',');
            i++;
            break;
        }
        case 'music_on_hold': {
            if (typeof value.data !== 'object') throw new CallError({ message: 'in "music_on_hold" type, data should be an object', call });
            if (typeof value.data.musicName !== 'string') throw new CallError({ message: 'in "music_on_hold" type, data.musicName should be a string', call });
            if (typeof value.data.maxSec !== 'undefined' && !Number.isInteger(parseInt(value.data.maxSec))) throw new CallError({ message: 'in "music_on_hold" type, data.seconds should be a integer', call });
            if (value.data.maxSec) {
                res += `${value.data.musicName},${value.data.maxSec}`;
            } else {
                res += value.data.musicName;
            }
            i++;
            break;
        }
        case 'system_message': {
            const sysMsgId = String(value.data).replace('M', '').trim();
            if (!Number.isInteger(parseInt(sysMsgId))) {
                throw new CallError({ message: `'${value.data}' is not a valid system message id`, call });
            }
            if (sysMsgId.length !== 4) {
                throw new CallError({ message: `'${value.data}' is not a valid system message id - it should be 4 digits, got ${sysMsgId.length}!`, call });
            }
            res += sysMsgId;
            i++;
            break;
        }
        case 'date':
        case 'dateH':
            if (!/^\d{2}\/\d{2}\/\d{4}$/.test(value.data)) {
                throw new CallError({ message: `'${value.data}' is not a valid date format. should be DD/MM/YYYY format`, call });
            }
            res += value.data;
            i++;
            break;
        default:
            res += value.data;
            i++;
        }
        if (value.type === 'go_to_folder') break;
    }
    return res;
}

function shiftDuplicatedValues (values) {
    /** אם יש ערך מסויים כמה פעמים, שייקבע רק האחרון **/
    for (const key of Object.keys(values)) {
        const value = values[key];
        if (Array.isArray(value)) {
            values[key] = value[value.length - 1];
        }
    }
    return values;
}

class Call {
    #eventsEmitter;
    #defaults;
    #valNameIndex;
    #timeoutId;
    #_responsesTextQueue;
    #responsesTextQueue;
    #values;

    constructor (callId, eventsEmitter, defaults) {
        this.#eventsEmitter = eventsEmitter;
        this.#defaults = defaults;

        this.callId = callId;
        this.did = '';
        this.phone = '';
        this.real_did = '';
        this.extension = '';

        this.#valNameIndex = 0;
        this.#_responsesTextQueue = '';
        this.#responsesTextQueue = {
            pull: () => {
                const queueText = this.#_responsesTextQueue;
                this.#_responsesTextQueue = '';
                return queueText;
            },
            push: (newResText) => {
                this.#_responsesTextQueue += `${newResText}&`;
            }
        };
    }

    get defaults () {
        return this.#defaults;
    }

    set defaults (newDefaults) {
        if (newDefaults.id_list_message?.prependToNextAction) {
            throw new CallError({ message: 'prependToNextAction is not supported as default', call: this });
        }

        if (typeof newDefaults.read?.timeout !== 'undefined' && !ms(newDefaults.read.timeout)) {
            throw new CallError({ message: 'timeout must be a valid ms liberty string/milliseconds number', call: this });
        }

        this.#defaults = {
            ...this.#defaults,
            ...newDefaults
        };
    }

    get values () {
        return this.#values;
    }

    set values (newValues) {
        throw new CallError({ message: 'call.values is read-only', call: this });
    }

    #logger (msg, color = 'blue') {
        if (!this.#defaults.printLog) return;
        console.log(colors[color](`[${this.callId}]: ${msg}`));
    }

    async read (messages, mode = 'tap', options = {}) {
        if (!Array.isArray(messages)) {
            throw new CallError({ message: `messages must be array, got ${typeof messages}`, call: this });
        }

        if (!messages.length) {
            throw new CallError({ message: 'messages must not be empty array', call: this });
        }

        if (messages.some((message) => typeof message !== 'object')) {
            throw new CallError({ message: `message must be object, one or more of the messages got type ${typeof messages}`, call: this });
        }

        if (messages.some((message) => typeof message.type !== 'string')) {
            throw new CallError({ message: `message type must be string, one or more of the messages got type ${typeof messages.type}`, call: this });
        }

        messages.forEach((message) => {
            if (typeof message.data === 'undefined') {
                throw new CallError({ message: 'message data is required, got undefined', call: this });
            }
            if (message.type !== 'zmanim' && message.type !== 'music_on_hold') {
                if (['number', 'digits'].includes(message.type) && Number.isInteger(message.data)) return;
                if (typeof message.data !== 'string') throw new CallError({ message: `message (in type ${message.type}) data must be string, got ${typeof message.data}`, call: this });
            }
        });

        if (!['tap', 'stt', 'record'].includes(mode)) {
            throw new CallError({ message: `mode '${mode}' is invalid. valid modes are: tap, stt, record`, call: this });
        }

        let valName;
        let responseText;
        const sendResp = async () => {
            if (options.val_name) {
                valName = options.val_name;
            } else {
                this.#valNameIndex++;
                valName = `val_${this.#valNameIndex}`;
            }

            const messagesCombined = makeMessagesData(messages, {
                removeInvalidChars: options.removeInvalidChars ?? this.#defaults.read.removeInvalidChars ?? this.#defaults.removeInvalidChars
            }, this);

            const readOptions = {
                ...this.#defaults.read[mode],
                timeout: this.#defaults.read.timeout,
                re_enter_if_exists: this.#defaults.read.re_enter_if_exists,
                removeInvalidChars: this.#defaults.read.removeInvalidChars ?? this.#defaults.removeInvalidChars,
                ...options,
                valName
            };

            const readOptionsDeprecates = [
                ['play_ok_mode', 'typing_playback_mode'],
                ['read_none', 'allow_empty'],
                ['read_none_var', 'empty_val'],
                ['block_change_type_lang', 'block_change_keyboard'],
                ['min', 'min_digits'],
                ['max', 'max_digits'],
                ['block_zero', 'block_zero_key'],
                ['block_asterisk', 'block_asterisk_key'],
                ['record_ok', 'no_confirm_menu'],
                ['record_hangup', 'save_on_hangup'],
                ['record_attach', 'append_to_existing_file'],
                ['allow_typing', 'block_typing'],
                ['use_records_engine', 'use_records_recognition_engine'],
                ['lenght_min', 'min_length'],
                ['length_min', 'min_length'],
                ['lenght_max', 'min_length'],
                ['length_max', 'max_length']
            ];

            for (const [oldName, newName] of readOptionsDeprecates) {
                if (typeof readOptions[oldName] !== 'undefined') {
                    throw new CallError({ message: `read option '${oldName}' is deprecated, use '${newName}' instead`, call: this });
                }
            }

            if (mode === 'tap') {
                responseText = makeTapModeRead(messagesCombined, readOptions, this);
            } else if (mode === 'stt') {
                responseText = makeSttModeRead(messagesCombined, readOptions, this);
            } else if (mode === 'record') {
                responseText = makeRecordModeRead(messagesCombined, readOptions);
            }

            this.send(this.#responsesTextQueue.pull() + responseText);

            await this.blockRunningUntilNextRequest(options.timeout ?? this.#defaults.read.timeout);

            if (!(valName in this.#values)) {
                await sendResp();
            }
        };

        await sendResp();

        const value = this.#values[valName];
        if (options.allow_empty && String(value) === String(options.empty_val)) {
            return options.empty_val;
        }
        return value;
    }

    go_to_folder (target) {
        const responseTxt = `go_to_folder=${target}`;
        this.send(this.#responsesTextQueue.pull() + responseTxt);
        throw new ExitError(this, { target, caller: 'go_to_folder' });
    }

    restart_ext () {
        const currentFolder = this.extension;
        return this.go_to_folder(`/${currentFolder}`);
    }

    hangup () {
        return this.go_to_folder('hangup');
    }

    /**
    * @param {Msg[]} messages
    * @param {Object} options
    * @param {Boolean} options.prependToNextAction
    * @param {Boolean} options.removeInvalidChars
    */
    id_list_message (messages, options = {}) {
        if (!Array.isArray(messages)) {
            throw new CallError({ message: `messages must be array, got ${typeof messages}.\nmessages got: ${JSON.stringify(messages)}`, call: this });
        }

        messages.forEach((message) => {
            if (typeof message.data === 'undefined') {
                throw new CallError({ message: 'message data is required, got undefined', call: this });
            }
            if (message.type !== 'zmanim' && message.type !== 'music_on_hold') {
                if (['number', 'digits'].includes(message.type) && Number.isInteger(message.data)) return;
                if (typeof message.data !== 'string') throw new CallError({ message: `message (in type ${message.type}) data must be string, got ${typeof message.data}`, call: this });
            }
        });

        if (!['object', 'undefined'].includes(typeof options)) {
            throw new CallError({ message: `if you pass options argument to id_list_message it must be object, but got ${typeof options} ('${options}')`, call: this });
        }

        const { prependToNextAction = false } = options;

        if (prependToNextAction && messages.some((message) => message?.type === 'go_to_folder')) {
            throw new CallError({ message: 'if you use go_to_folder message type in id_list_message you can\'t use prependToNextAction=true!', call: this });
        }

        const goToFolderMessageIndex = messages.findIndex((message) => message?.type === 'go_to_folder');
        if (goToFolderMessageIndex !== -1 && goToFolderMessageIndex !== messages.length - 1) {
            throw new CallError({ message: 'go_to_folder message type must be the last message in id_list_message. No further messages can be threaded after this message type', call: this });
        }

        const messagesCombined = makeMessagesData(messages, { removeInvalidChars: options.removeInvalidChars ?? this.#defaults.id_list_message.removeInvalidChars ?? this.#defaults.removeInvalidChars }, this);
        const responseTxt = `id_list_message=${messagesCombined}`;

        if (prependToNextAction) {
            this.#responsesTextQueue.push(responseTxt);
        } else {
            if (this.res._headerSent) {
                this.#logger('Cannot send id_list_message after sending response (probably done from uncaughtErrorHandler due to error in asynchronous code after returning response)', 'red');
                return;
            }
            this.send(this.#responsesTextQueue.pull() + responseTxt + '&');
            throw new ExitError(this, {
                target: goToFolderMessageIndex !== -1 ? messages[goToFolderMessageIndex].data : `parent of /${this.extension}`,
                caller: goToFolderMessageIndex !== -1 ? 'go_to_folder' : 'id_list_message'
            });
        }
    }

    routing_yemot (number) {
        const responseTxt = `routing_yemot=${number}`;
        this.send(this.#responsesTextQueue.pull() + responseTxt);
        throw new ExitError(this, { target: `other system - ${number}`, caller: 'routing_yemot' });
    }

    send (data) {
        this.res.send(data);
    }

    setReqValues (req, res) {
        this.req = req;
        this.res = res;

        this.#values = shiftDuplicatedValues(req.method === 'POST' ? req.body : req.query);

        this.phone = this.#values.ApiPhone;
        this.callId = this.#values.ApiCallId;
        this.did = this.#values.ApiDID;
        this.real_did = this.#values.ApiRealDID;
        this.extension = this.#values.ApiExtension;

        const valuesToInject = Object.keys(this.#values).filter((key) => key.startsWith('Api'));
        for (const key of valuesToInject) {
            this[key] = this.#values[key];
        }
    }

    async blockRunningUntilNextRequest (timeout) {
        this.#logger(`🔒 fn running blocked - waiting to next request from yemot ${timeout ? `(timeout ${timeout === 'number' ? ms(timeout, { long: true }) : ms(ms(timeout), { long: true })} is defined)` : ''}`);
        return new Promise((resolve, reject) => {
            clearTimeout(this.#timeoutId);
            if (timeout) {
                const timeoutMilliseconds = typeof timeout === 'number' ? timeout : ms(timeout);
                this.#timeoutId = setTimeout(() => {
                    if (!this.res._headerSent) this.res.json({ message: 'timeout' });
                    reject(new TimeoutError(this, timeoutMilliseconds));
                }, timeoutMilliseconds);
            }
            this.#eventsEmitter.once(this.callId, (isHangup) => {
                clearTimeout(this.#timeoutId);
                this.#logger('🔓 fn running unblocked');
                if (isHangup) {
                    if (!this.res._headerSent) this.res.json({ message: 'hangup' });
                    reject(new HangupError(this));
                } else {
                    resolve();
                }
            });
        });
    }

    get query () {
        throw new CallError({ message: 'call.query is deprecated, use call.values instead', call: this });
    }

    get body () {
        throw new CallError({ message: 'call.body is deprecated, use call.values instead', call: this });
    }

    get params () {
        throw new CallError({ message: 'call.params is deprecated, use call.req.params instead', call: this });
    }
}

var globalDefaults = {
    printLog: false,
    removeInvalidChars: false,
    read: {
        // val_name is dynamic generated
        timeout: 0,
        re_enter_if_exists: false,
        removeInvalidChars: false,
        tap: {
            min_digits: 1,
            max_digits: '',
            sec_wait: 7,
            typing_playback_mode: 'No',
            block_asterisk_key: false,
            block_zero_key: false,
            replace_char: '',
            digits_allowed: '',
            amount_attempts: '',
            allow_empty: false,
            empty_val: 'None',
            block_change_keyboard: false
        },
        stt: {
            lang: '',
            block_typing: false,
            max_digits: '',
            quiet_max: '',
            max_length: '',
            use_records_recognition_engine: false
        },
        record: {
            path: '',
            file_name: '',
            no_confirm_menu: false,
            save_on_hangup: false,
            append_to_existing_file: false,
            min_length: '',
            max_length: ''
        }
    },
    id_list_message: {
        removeInvalidChars: false
        // prependToNextAction not supported as default
    }
};

function parse(err) {
  if (!err.stack) {
    return [];
  }

  const lines = err.stack.split('\n').slice(1);
  return lines
    .map(function(line) {
      if (line.match(/^\s*[-]{4,}$/)) {
        return createParsedCallSite({
          fileName: line,
          lineNumber: null,
          functionName: null,
          typeName: null,
          methodName: null,
          columnNumber: null,
          'native': null,
        });
      }

      const lineMatch = line.match(/at (?:(.+?)\s+\()?(?:(.+?):(\d+)(?::(\d+))?|([^)]+))\)?/);
      if (!lineMatch) {
        return;
      }

      let object = null;
      let method = null;
      let functionName = null;
      let typeName = null;
      let methodName = null;
      let isNative = (lineMatch[5] === 'native');

      if (lineMatch[1]) {
        functionName = lineMatch[1];
        let methodStart = functionName.lastIndexOf('.');
        if (functionName[methodStart-1] == '.')
          methodStart--;
        if (methodStart > 0) {
          object = functionName.substr(0, methodStart);
          method = functionName.substr(methodStart + 1);
          const objectEnd = object.indexOf('.Module');
          if (objectEnd > 0) {
            functionName = functionName.substr(objectEnd + 1);
            object = object.substr(0, objectEnd);
          }
        }
      }

      if (method) {
        typeName = object;
        methodName = method;
      }

      if (method === '<anonymous>') {
        methodName = null;
        functionName = null;
      }

      const properties = {
        fileName: lineMatch[2] || null,
        lineNumber: parseInt(lineMatch[3], 10) || null,
        functionName: functionName,
        typeName: typeName,
        methodName: methodName,
        columnNumber: parseInt(lineMatch[4], 10) || null,
        'native': isNative,
      };

      return createParsedCallSite(properties);
    })
    .filter(function(callSite) {
      return !!callSite;
    });
}

function CallSite(properties) {
  for (const property in properties) {
    this[property] = properties[property];
  }
}

const strProperties = [
  'this',
  'typeName',
  'functionName',
  'methodName',
  'fileName',
  'lineNumber',
  'columnNumber',
  'function',
  'evalOrigin'
];

const boolProperties = [
  'topLevel',
  'eval',
  'native',
  'constructor'
];

strProperties.forEach(function (property) {
  CallSite.prototype[property] = null;
  CallSite.prototype['get' + property[0].toUpperCase() + property.substr(1)] = function () {
    return this[property];
  };
});

boolProperties.forEach(function (property) {
  CallSite.prototype[property] = false;
  CallSite.prototype['is' + property[0].toUpperCase() + property.substr(1)] = function () {
    return this[property];
  };
});

function createParsedCallSite(properties) {
  return new CallSite(properties);
}

function YemotRouter (options = {}) {
    const ops = {
        printLog: options.printLog,
        timeout: options.timeout,
        uncaughtErrorHandler: options.uncaughtErrorHandler || null,
        defaults: options.defaults || {}
    };

    if (options.uncaughtErrorsHandler) {
        throw new Error('YemotRouter: uncaughtErrorsHandler is renamed to uncaughtErrorHandler');
    }

    if (typeof ops.timeout !== 'undefined' && !ms(ops.timeout)) {
        throw new Error('YemotRouter: timeout must be a valid ms liberty string/milliseconds number');
    }

    if (ops.defaults.id_list_message?.prependToNextAction) {
        throw new Error('YemotRouter: prependToNextAction is not supported as default');
    }

    let mergedDefaults = {
        printLog: ops.printLog ?? globalDefaults.printLog,
        removeInvalidChars: ops.defaults?.removeInvalidChars ?? globalDefaults.removeInvalidChars,
        read: {
            timeout: ops.timeout ?? globalDefaults.read.timeout,
            tap: {
                ...globalDefaults.read.tap,
                ...ops.defaults.read?.tap
            },
            stt: {
                ...globalDefaults.read.stt,
                ...ops.defaults.read?.stt
            },
            record: {
                ...globalDefaults.read.record,
                ...ops.defaults.read?.record
            }
        },
        id_list_message: {
            ...globalDefaults.id_list_message,
            ...ops.defaults.id_list_message
        }
    };

    const activeCalls = {};
    const eventsEmitter = new EventEmitter();

    function logger (callId, msg, color = 'blue') {
        if (!(ops.printLog ?? mergedDefaults.printLog)) return;
        console.log(colors[color](`[${callId}]: ${msg}`));
    }

    function deleteCall (callId) {
        const call = activeCalls[callId];
        if (call && call._timeoutId) {
            clearTimeout(call._timeoutId);
        }
        delete activeCalls[callId];
        return !!call;
    }

    async function makeNewCall (fn, callId, call) {
        try {
            await fn(call);
            deleteCall(callId);
            logger(callId, '🆗 the function is done');
        } catch (error) {
            deleteCall(callId);

            const [trace] = parse(error);
            const errorPath = trace ? `(${trace.getFileName()}:${trace.getLineNumber()}:${trace.getColumnNumber()})` : '';

            // טיפול בשגיאות מלאכותיות שנועדו לעצור את ריצת הפונקציה - בניתוק לדוגמה
            if (error instanceof HangupError) {
                logger(callId, '👋 the call was hangup by the caller');
            } else if (error instanceof TimeoutError) {
                logger(callId, `💣 timeout for receiving a response from the caller (after ${ms(error.timeout, { long: true })}). the call has been deleted from active calls`);
            } else if (error instanceof ExitError) {
                logger(callId, `👋 the call was exited from the extension /${call.extension}` + (error.context ? ` (by ${error.context?.caller} to ${error.context?.target})` : ''));
            } else {
                if (ops.uncaughtErrorHandler) {
                    logger(callId, `💥 Uncaught error. applying uncaughtErrorHandler ${errorPath}`, 'red');
                    try {
                        await ops.uncaughtErrorHandler(error, call);
                    } catch (err) {
                        const [trace] = parse(err);
                        const errorPath = `${trace.getFileName()}:${trace.getLineNumber()}:${trace.getColumnNumber()}`;
                        if (err instanceof ExitError) {
                            console.log(`👋 the call was exited from the extension /${call.extension} in uncaughtErrorHandler ${errorPath}` + (error.context ? ` (by ${error.context?.caller} to ${error.context?.target})` : ''));
                        } else {
                            console.error('💥 Error in uncaughtErrorHandler! process is crashing');
                            throw err;
                        }
                    }
                } else {
                    logger(callId, `💥 Uncaught error. no uncaughtErrorHandler, throwing error ${errorPath}`, 'red');
                    throw error;
                }
            }
        }
    }

    const expressRouter = express.Router(options);

    const proxyHandler = {
        get (target, key) {
            if (key === 'add_fn') {
                throw new Error('YemotRouter: router.add_fn is deprecated, use get/post/all instead');
            } else if (['get', 'post', 'all'].includes(key)) {
                return (path, fn) => {
                    target[key](path, (req, res, next) => {
                        if (req.method === 'POST' && !req.body) {
                            throw new Error('YemotRouter: it look you use api_url_post=yes, but you didn\'t include express.urlencoded({ extended: true }) middleware! (https://expressjs.com/en/4x/api.html#express.urlencoded)');
                        }

                        const values = req.method === 'POST' ? req.body : req.query;
                        const requiredValues = ['ApiPhone', 'ApiDID', 'ApiExtension', 'ApiCallId'];
                        if (requiredValues.some((key) => !Object.prototype.hasOwnProperty.call(values, key))) {
                            return res.json({ message: 'the request is not valid yemot request' });
                        }

                        const callId = values.ApiCallId;

                        let isNewCall = false;
                        let currentCall = activeCalls[callId];
                        if (!currentCall) {
                            isNewCall = true;
                            currentCall = new Call(callId, eventsEmitter, mergedDefaults);
                            currentCall.setReqValues(req, res);
                            if (values.hangup === 'yes') {
                                logger(callId, '👋 call is hangup (outside the function)');
                                eventsEmitter.emit('call_hangup', currentCall);
                                return res.json({ message: 'hangup' });
                            }
                            activeCalls[callId] = currentCall;
                            logger(callId, `📞 new call - from ${values.ApiPhone || 'AnonymousPhone'}`);
                            eventsEmitter.emit('new_call', currentCall);
                        } else {
                            currentCall.setReqValues(req, res);
                        }

                        if (isNewCall) {
                            makeNewCall(fn, callId, currentCall);
                        } else {
                            eventsEmitter.emit(callId, values.hangup === 'yes');
                            eventsEmitter.emit(values.hangup === 'yes' ? 'call_hangup' : 'call_continue', currentCall);
                        }
                    });
                };
            } else if (key === 'deleteCall') {
                return deleteCall;
            } else if (key === 'activeCalls') {
                return activeCalls;
            } else if (key === 'defaults') {
                return mergedDefaults;
            } else if (key === 'events') {
                return eventsEmitter;
            } else if (key === 'asExpressRouter') {
                return new Proxy(expressRouter, proxyHandler);
            } else if (['use', 'handle', 'set', 'name', 'length', 'caseSensitive', 'stack'].includes(key)) {
                return target[key];
            } else {
                throw new Error(`YemotRouter: ${key.toString()} is not supported yet [get]`);
            }
        },
        set (target, key, value) {
            if (key === 'defaults') {
                if (value.id_list_message?.prependToNextAction) {
                    throw new Error('prependToNextAction is not supported as default');
                }

                if (typeof value.read?.timeout !== 'undefined' && !ms(value.read.timeout)) {
                    throw new Error('timeout must be a valid ms liberty string/milliseconds number');
                }

                mergedDefaults = {
                    ...mergedDefaults,
                    ...value
                };
            } else {
                throw new Error(`YemotRouter: ${key.toString()} is not supported yet [set]`);
            }
        }
    };

    return new Proxy(expressRouter, proxyHandler);
}

const SYSTEM_MESSAGE_CODES = {
    /** הודעת ברוכים הבאים - הודעה ראשונה בשלוחה */
    M0000: 'M0000',
    /** הודעה זמנית */
    M0001: 'M0001',
    /** הודעה שעל כל מקש חוזר במודול */
    M0002: 'M0002',
    /** ניתן להיכנס ממספר ישראלי בלבד */
    M0003: 'M0003',
    /** מודול זה אינו מאושר לשימוש במערכת זו, שלום ותודה. */
    M0004: 'M0004',
    /** כותרת הקובץ היא */
    M0010: 'M0010',
    /** כותרת השידור היא */
    M0011: 'M0011',
    /** לשמיעת כמות המספרים השונים ששמעו הודעה זו הקישו 1. לבדיקה האם מספר מסוים שמע את ההודעה הקישו 2. לחזרה הקישו כוכבית */
    M0012: 'M0012',
    /** כמות המספרים השונים ששמעו את ההודעה היא */
    M0013: 'M0013',
    /** אנא הקישו מספר טלפון, לסיום הקישו סולמית */
    M0014: 'M0014',
    /** מספר הטלפון שהוקש לא שמע את ההודעה */
    M0015: 'M0015',
    /** מספר הטלפון שהוקש שמע את ההודעה */
    M0016: 'M0016',
    /** הינכם מבקשים להוסיף לרשימת התפוצה את טלפון מספר */
    M0026: 'M0026',
    /** הרשמתכם בוטלה */
    M0027: 'M0027',
    /** לאישור ההרשמה הקישו 1, לביטול הקישו 2. */
    M0028: 'M0028',
    /** הודעה אחרונה בשלוחה */
    M0099: 'M0099',
    /** להקלטת כותרת לקובץ, הקישו 1, להמשך ללא הקלטת כותרת הקישו 2 */
    M0100: 'M0100',
    /** להקלטת כותרת לשידור, הקישו 1, להמשך ללא הקלטת כותרת הקישו 2 */
    M0101: 'M0101',
    /** אנא הקליטו את כותרת השידור לאחר הצליל ובסיום הקישו סולמית */
    M0102: 'M0102',
    /** אנא הקישו את מספר החלק המבוקש לעריכה וסולמית לסיום לעריכת הקובץ הראשי הקישו אפס וסולמית לקטע הנוסף הראשון הקישו אחת וסולמית */
    M0998: 'M0998',
    /** הנכם מועברים להקלטת תוספות מספר */
    M0999: 'M0999',
    /** זהו תפריט בחירה. אנא הקישו את מספר השלוחה המבוקש */
    M1000: 'M1000',
    /** המקש שֶהוֹקַש שגוי */
    M1001: 'M1001',
    /** לא הוקשה בחירה */
    M1002: 'M1002',
    /** אורך */
    M1003: 'M1003',
    /** דקות */
    M1004: 'M1004',
    /** סוף הודעות */
    M1005: 'M1005',
    /** ביפ */
    M1006: 'M1006',
    /** השידור החי עדיין לא החל. להמתנה לַשידור הַקִישוּ 1,. להאזנה לשידורים קודמים הַקִישוּ 2 */
    M1007: 'M1007',
    /** השידור יחל מיד עם כניסתו של המנהל. */
    M1008: 'M1008',
    /** לשמיעת ההקלטה הקישו 1. לאישור ההקלטה הקישו 2. להקלטה מחודשת 3. לביטול וחזרה הקישו 4 */
    M1009: 'M1009',
    /** הֶקְלַטֶתֶם בהצלחה את קובץ מספר */
    M1010: 'M1010',
    /** להקלטה נוספת הַקִישוּ 1. לְסיום הַקִישוּ 2 או הַמתינו. */
    M1011: 'M1011',
    /** אנא הקליטו את הודעתכם לאחר הצליל. בסיום הַקישו סולמית */
    M1012: 'M1012',
    /** עד היום צברת */
    M1013: 'M1013',
    /** נקודות */
    M1014: 'M1014',
    /** מספר הטלפון שלכם אינו מזוהה */
    M1015: 'M1015',
    /** קיבלת */
    M1017: 'M1017',
    /** אין נתונים על השמעה אחרונה */
    M1018: 'M1018',
    /** הנך בדקה */
    M1019: 'M1019',
    /** מתוך */
    M1020: 'M1020',
    /** שלוחה */
    M1021: 'M1021',
    /** האזנה */
    M1022: 'M1022',
    /** לא ניתן לצרף את טלפון */
    M1023: 'M1023',
    /** הוספתם בהצלחה לרשימת התפוצה את טלפון מספר */
    M1024: 'M1024',
    /** לא ניתן להסיר את טלפון */
    M1025: 'M1025',
    /** שלום ותודה */
    M1026: 'M1026',
    /** הסרת מספר. הנכם מבקשים להסיר את טלפון מספר */
    M1027: 'M1027',
    /** האם הנכם בטוחים? לאישור ההסרה הַקישו1 , לֶביטול הקישו 2, או נתקו את השיחה. */
    M1028: 'M1028',
    /** הסרת מספר הטלפון בוטלה */
    M1029: 'M1029',
    /** הסרתם בהצלחה מרשימת התפוצה את טלפון מספר */
    M1030: 'M1030',
    /** להוראות הפעלה הקישו1. להשארת הודעה למנהל המערכת הקישו2. לחזרה למיקום האחרון אליו הֶאֵזַנְתֶם הקישו3. לשמיעת כל התכנים המוקלטים במערכת הקישו 4. לפתיחת מערכת וואצפון שבהקשה על 8 וסולמית עוברים ישירות למערכת שלנו הקישו 5. לרשימות ההשמעה האישיות שלכם הקישו 6. להקלטת השמעות הקישו 7. להגדרת בחירת קובץ בכל השלוחות הקישו 8 */
    M1031: 'M1031',
    /** הוראות הפעלה. בכל שלב ניתן להקיש סולמית ולחזור שְלַב אחד אחורה,. או כוכבית לחזרה לתחילת המערכת. בעת שמיעת קובץ לחזרה 10 שניות אחורה הקישו 1, קדימה 3. חזרה 5 דקות אחורה הקישו 4, קדימה 6. להפסקה זמנית הקישו 5, ושוב 5 להמשך האזנה. להשמעה קודמת הקישו 2, להשמעה הבאה הקישו 8. לחזרה להתחלה הקישו 4 ועוד 4 כפי הצורך. להפעלת קובץ אקראי הקישו 9. לשמיעת פרטי ההודעה ואפשרויות האזנה הקישו0. חזרה לתפריט קודם הַקישו סולמית. חזרה לתחילת המערכת הַקישו כוכבית */
    M1032: 'M1032',
    /** לגישה אנא הכנס כמנהל */
    M1033: 'M1033',
    /** לאישור הקישו 1, להקשה מחודשת 2. */
    M1034: 'M1034',
    /** לא הקּשתּם את מינימום הספרות הנדרשות */
    M1035: 'M1035',
    /** אנא הקישו את מספר הקובץ וסולמית לֶסיום */
    M1036: 'M1036',
    /** הכותרת הוקלטה בהצלחה */
    M1037: 'M1037',
    /** אנא הקליטו את כותרת הקובץ לאחר הצליל ובסיום הקישו סולמית */
    M1038: 'M1038',
    /** אנא הקישו את מספר השלוחה לניתוב וסולמית */
    M1039: 'M1039',
    /** ליציאה הקישו כוכבית */
    M1040: 'M1040',
    /** המענה סַגוּר כעת, אנא נסו שוב בשעות הפעילות */
    M1041: 'M1041',
    /** שלוחה זו אינה מוגדרת במערכת */
    M1042: 'M1042',
    /** יתרת יחידות נמוכה לביצוע השיחה */
    M1043: 'M1043',
    /** אנא נסו שנית ממספר טלפון מזוהה */
    M1044: 'M1044',
    /** ברוכים הבאים למערכת ההזמנות של המערכות החינמיות, לקבלת מערכת הקישו 1 */
    M1045: 'M1045',
    /** ניתן לפתוח מערכת אחת בשבוע, אנא נסו שוב בשבוע הבא */
    M1046: 'M1046',
    /** אנא בחרו סיסמת ניהול ולסיום הקישו סולמית */
    M1047: 'M1047',
    /** לצערינו אין כרגע מספרי טלפון להקצאה, אנא נסו שוב במועד מאוחר יותר */
    M1048: 'M1048',
    /** מזל טוב - פתחתם מערכת חינמית משלכם, מספר הטלפון של המערכת הוא */
    M1049: 'M1049',
    /** הטלפון של מנהל המערכת */
    M1050: 'M1050',
    /** סיסמת הניהול היא */
    M1051: 'M1051',
    /** לשמיעה מחודשת של מספר המערכת הקישו 1. לֶסיום הקישו 2 */
    M1052: 'M1052',
    /** אנא אֶמׂר במספר מילים עבור מה מיועדת המערכת */
    M1053: 'M1053',
    /** אנא הקליטו את שמכם הפרטי אות אחר אות. לדוגמא לַשֶם משה אִמרו משה, מם שין הֶי. בסיום הַקישו סולמית */
    M1054: 'M1054',
    /** אנא הקליטו את שם המשפחה שלכם אות אחר אות. לדוגמא למשפחת כהן אִמרו כהן, כף הֶי נון. בסיום הַקישו סולמית */
    M1055: 'M1055',
    /** להלן הפרטים שנקלטו */
    M1056: 'M1056',
    /** לאישור הקישו 1 לשמיעה חוזרת 2 להקלטה מחדש הקישו 3 */
    M1057: 'M1057',
    /** סיסמה קצַרה מידי */
    M1058: 'M1058',
    /** במידה וברצונכם להכניס טלפון נוסף בתור מנהל מערכת, הַקישו את מספרו וסולמית לֶסיום. לֶדילוג הַקישו סולמית או הַמתינו. */
    M1059: 'M1059',
    /** אנא השאירו הודעתכם לאחר הִשַמע הצליל. לֶסיום נתקו את השיחה או הַקישו סולמית */
    M1060: 'M1060',
    /** לשמיעת ההודעה הקישו 1, לֶאישור הקישו 2, להקלטה מחודשת 3, לביטול וחזרה הקישו 4. */
    M1061: 'M1061',
    /** מיד תועברו להקלטת הברכה, לפני בקשת הברכה מקבלים החלטה טובה בתורה מצוות ומעשים טובים ומכריזים יחי.. אנא השאירו את בקשת הברכה שמכם שם אמכם. בסיום ההקלטה הקישו סולמית */
    M1062: 'M1062',
    /** לאישור ושליחת בקשת הברכה, הקישו 1 לשמיעת בקשת הברכה 2 להקלטה מחודשת של בקשת הברה 3 */
    M1063: 'M1063',
    /** קיבלתם תשובה מהרבי שליטא מלך המשיח באמצעות האיגרות קודש בכרך */
    M1064: 'M1064',
    /** עמוד */
    M1065: 'M1065',
    /** ועמוד */
    M1066: 'M1066',
    /** לשמיעה חוזרת של מיקום התשובה הקש 1. לקבלת העתק ממכתב התשובה מיידית לתיבת הדואר האלקטרוני שלכם הקישו 2. לקבלת העתק ממכתב התשובה בדואר רגיל לביתכם הקישו 3. לחזרה לתפריט הראשי הקישו * */
    M1067: 'M1067',
    /** על מנת שנוכל לשלוח את הְעֶתֶק התשובה לביתכם, אנא הקליטו את הפרטים לְמשלוח - שלב אחר שלב */
    M1068: 'M1068',
    /** אנא הקליטו את מספר הבית, ובסיום הַקישו סולמית */
    M1069: 'M1069',
    /** אנא הקליטו את מספר הדירה, ובסיום הַקישו סולמית */
    M1070: 'M1070',
    /** אנא הקליטו את שם העיר אות אחר אות. לדוגמא לעיר חיפה אִמרו חיפה, חת יוד פְּי הֶי. בסיום הַקישו סולמית */
    M1071: 'M1071',
    /** להלן הפרטים למשלוח הדואר */
    M1072: 'M1072',
    /** אנא הקישו על מקשי הטלפון, את מספר מיקוד הדואר בכתובת שציינתם, בסיום הַקישו סולמית */
    M1073: 'M1073',
    /** אנא הקישו על מקשי הטלפון, מספר טלפון בו במידת הצורך יהיה ניתן ליצור אתכם קשר, בסיום הַקישו סולמית */
    M1074: 'M1074',
    /** תודה רבה, בקשתכם למשלוח הְעֶתֶק התשובה בדואר, התקבלה בהצלחה */
    M1075: 'M1075',
    /** מספר הפּנִיַה הוא */
    M1076: 'M1076',
    /** לסיום ומַעַבַר לתפריט הראשי, הקישו 1. לשמיעת מספר הפּנִיַה שנית, לצורך בירור עתידי, הקישו 2 */
    M1077: 'M1077',
    /** לְאישור הקישו 1. להקלטה מחודשת של הפרטים הקישו 2 */
    M1078: 'M1078',
    /** אנא הקליטו את שם הרחוב אות אחר אות, לדוגמא לרחוב חבצלת אִמְרוּ: חבצלת, ח,ב,צ,ל,ת. בסיום הַקישו סולמית. */
    M1079: 'M1079',
    /** שגיאה */
    M1080: 'M1080',
    /** הפרק אותו קיבלת לקריאה הינו פרק (מיועד לחלוקת פרק אחד או שניים) */
    M1081: 'M1081',
    /** וכן את פרק (מיועד לחלוקה של 2 פרקים) (עד פרק בקריאה אישית) */
    M1082: 'M1082',
    /** תזכה למצוות (וכן את כל ההודעות לאחרי השמעת הפרקים) */
    M1083: 'M1083',
    /** הפרקים אותם קיבלתם לקריאה הינם פרקים (מיועד לחלוקה של מעל 2 פרקים) */
    M1084: 'M1084',
    /** עד פרק (מיועד לחלוקה של מעל 2 פרקים) */
    M1085: 'M1085',
    /** הפרשה אותה קיבלת לקריאה הינה פרשת */
    M1086: 'M1086',
    /** עד פרשת / וכן את פרשת */
    M1087: 'M1087',
    /** עד פרשת */
    M1088: 'M1088',
    /** תפריט בחירה שְלַב... */
    M1089: 'M1089',
    /** אנא הקישו את בחירתכם ב... */
    M1090: 'M1090',
    /** סְפַרוֹת */
    M1091: 'M1091',
    /** לפרשת */
    M1092: 'M1092',
    /** תזכורת ספירת העומר */
    M1093: 'M1093',
    /** הודעה לאחר תזכורת ספירת העומר - ברירת מחדל ניתן ללמוד את השיעור היומי מפי הרב יוסף יצחק כץ */
    M1094: 'M1094',
    /** שגיאת ניהול, לא הוגדר סוג זיהוי */
    M1095: 'M1095',
    /** להקלטה אנא הקישו את מספר התיקייה וסולמית לסיום. להקלטה בתיקייה הזמנית הקישו סולמית. להקלטה בתתי תיקיות הקישו את הכתובת המלאה, כאשר בין תיקייה לתיקייה הקישו כוכבית. בסיום הכתובת המלאה הקישו סולמית. */
    M1096: 'M1096',
    /** אין הרשאה להקלטה בתיקיה זו */
    M1097: 'M1097',
    /** כבר קיבלתם ניקוד על ערך זה */
    M1098: 'M1098',
    /** אין הודעה להשמעה */
    M1099: 'M1099',
    /** נא הקש את הסיסמה ובסיום הקש סולמית */
    M1100: 'M1100',
    /** סיסמה שגויה */
    M1101: 'M1101',
    /** אין לכם הרשאת גישה לתיקייה זו */
    M1102: 'M1102',
    /** אנא הקישו את המספר האישי וסולמית לְסיום */
    M1103: 'M1103',
    /** המספר האישי שֶ הוּקַש שגוי */
    M1104: 'M1104',
    /** התחברתם בהצלחה */
    M1105: 'M1105',
    /** שלום לך מספר אישי */
    M1106: 'M1106',
    /** ניכר כי הנכם משתמשים חדשים במערכת */
    M1107: 'M1107',
    /** אנא אמרו את שמכם ושם משפחתכם לאחר השמע הצליל */
    M1108: 'M1108',
    /** אם אתם מרוצים מההקלטה הקישו 1 להקלטה מחודשת 2 */
    M1109: 'M1109',
    /** הקלטת השם נקלטה בהצלחה */
    M1110: 'M1110',
    /** שלום ל.. */
    M1111: 'M1111',
    /** תזכורת ספירת העומר */
    M1112: 'M1112',
    /** הודעה לאחר תזכורת ספירת העומר - ברירת מחדל ניתן ללמוד את השיעור היומי מפי הרב יוסף יצחק כץ */
    M1113: 'M1113',
    /** שלוחה זו סגורה כעת, אנא נסו שוב בשעות הפעילות */
    M1114: 'M1114',
    /** לא ניתן להכנס שוב עם משתמש זה */
    M1115: 'M1115',
    /** עד היום צברת */
    M1116: 'M1116',
    /** נקודות */
    M1117: 'M1117',
    /** הדרגה אליה הגעת היא */
    M1118: 'M1118',
    /** לאישור הקישו 1, להקשה מחודשת הקישו 2 */
    M1119: 'M1119',
    /** לא ניתן לבצע פעולה זו. שלום ותודה. */
    M1120: 'M1120',
    /** לכניסה ממספר הטלפון ממנו חייגתם הקישו 1 וסולמית, לכניסה עם מספר טלפון אחר הקישו את מספרו וסולמית לסיום */
    M1121: 'M1121',
    /** מספר הטלפון שלכם אינו מזוהה */
    M1122: 'M1122',
    /** רשימת התפוצה. */
    M1123: 'M1123',
    /** להכנסת מספרים ברצף לרשימת התפוצה הקישו 4 להוספה הסרה או חסימה של מספר הקישו 1 לאיפוס ומחיקת כל רשימת התפוצה הקישו 2 למידע אודות רשימת התפוצה הקישו 3 לקבלת רשימה עדכנית של כל המספרים ברשימת התפוצה שלכם למייל הקישו 5 */
    M1124: 'M1124',
    /** אנא הקש מספר טלפון ובסיום הקש סולמית */
    M1125: 'M1125',
    /** איננו קיים ברשימת התפוצה שלך */
    M1126: 'M1126',
    /** כבר קיים ברשימת התפוצה שלך במצב פעיל */
    M1127: 'M1127',
    /** כבר קיים ברשימת התפוצה שלך במצב חסום */
    M1128: 'M1128',
    /** מספר הטלפון שהוקש אינו תקין אנא נסו שנית */
    M1129: 'M1129',
    /** להוספת המספר לרשימת התפוצה הקש 1 להסרת המספר מרשימת התפוצה הקש 2 לחסימת חיוג למספר זה הקש 3 לביטול חסימת חיוג למספר זה הקש 4, להקשת טלפון אחר הקישו 5, לחזרה לתפריט הקישו כוכבית */
    M1130: 'M1130',
    /** המספר נוסף בהצלחה */
    M1131: 'M1131',
    /** מספר הטלפון הוסר בהצלחה מרשימת התפוצה */
    M1132: 'M1132',
    /** מספר הטלפון נחסם לחיוג */
    M1133: 'M1133',
    /** בוטלה החסימה ממספר הטלפון, מספר הטלפון הוסף בהצלחה לחיוג ברשימת התפוצה */
    M1134: 'M1134',
    /** למספר נוסף הקישו 1 לחזרה לתפריט הקישו 2 */
    M1135: 'M1135',
    /** איפוס רשימת התפוצה שימו לב כי אישור איפוס הרשימה תמחוק את כל מספרי הטלפון לחיוג ברשימת התפוצה שלכם,באם הנכם בטוחים כי ברצונכם למחוק את כל מספרי הטלפון הקישו 1, לביטול וחזרה לתפריט הקישו 2. */
    M1136: 'M1136',
    /** איפוס רשימת התפוצה - בוטלה */
    M1137: 'M1137',
    /** הנך מועבר לתפריט */
    M1138: 'M1138',
    /** על מנת להשלים את מחיקת כל מספרי הטלפון ברשימת התפוצה , אנא הקישו את הסיסמה שלכם ובסיום הקישו סולמית. */
    M1139: 'M1139',
    /** רשימת התפוצה שלכם אופסה בהצלחה */
    M1140: 'M1140',
    /** ברשימת התפוצה שלכם ישנם */
    M1141: 'M1141',
    /** מספרים בתבנית */
    M1142: 'M1142',
    /** מתוכם */
    M1143: 'M1143',
    /** מספרים פעילים */
    M1144: 'M1144',
    /** ועוד */
    M1145: 'M1145',
    /** מספרים חסומים */
    M1146: 'M1146',
    /** הקמפיין יוצא מזיהוי טלפוני שמספרו */
    M1147: 'M1147',
    /** אפשרות זו עדיין איננה זמינה */
    M1148: 'M1148',
    /** אנא הכניסו את כל המספרים שברצונכם להכניס, כאשר בין מספר למספר יש להקיש כוכבית ולסיום כל המספרים יש להקיש סולמית */
    M1149: 'M1149',
    /** אנא המתן לאישור זמן ממוצע כ 3 שניות למספר */
    M1150: 'M1150',
    /** אישור */
    M1151: 'M1151',
    /** הכנסת */
    M1152: 'M1152',
    /** מספרי טלפון */
    M1153: 'M1153',
    /** נכנסו בהצלחה */
    M1154: 'M1154',
    /** ועוד */
    M1155: 'M1155',
    /** מספרי טלפון חסומים */
    M1156: 'M1156',
    /** שגיאה במספר. */
    M1157: 'M1157',
    /** לשמיעת כל מספרי הטלפון שהוכנסו יחד עם הגדרת המצב שלהם הקישו 1,למספרים שהוכנסו בהצלחה הקישו 2,למספרים החסומים הקישו 3,למספרים שגויים הקישו 4,לחזרה לתפריט הראשי הקישו 5 */
    M1158: 'M1158',
    /** סוף מספרים */
    M1159: 'M1159',
    /** אין מספרי טלפון שנכנסו בהצלחה */
    M1160: 'M1160',
    /** מספרי טלפון שנכנסו בהצלחה */
    M1161: 'M1161',
    /** אין מספרי טלפון חסומים */
    M1162: 'M1162',
    /** מספרי טלפון חסומים */
    M1163: 'M1163',
    /** אין מספרי טלפון שגויים */
    M1164: 'M1164',
    /** מספרי טלפון שגויים */
    M1165: 'M1165',
    /** ביפ - הקלטה */
    M1166: 'M1166',
    /** שלום ותודה - לאחר סיום הזמן בחיוג limit_call_seconds */
    M1167: 'M1167',
    /** מספרך אינו משוייך לרשימת הכניסה במערכת. אנא צור קשר עם מנהל המערכת */
    M1168: 'M1168',
    /** קובץ הנקודות גדול מידי, שגיאה בעדכון הנתונים */
    M1169: 'M1169',
    /** המערכת סגורה בשבתות וחגים */
    M1170: 'M1170',
    /** לא נכנסת בהצלחה למערכת הבסיס */
    M1171: 'M1171',
    /** לא הוגדר מערכת בסיס */
    M1172: 'M1172',
    /** לא הוגדר סוג כניסה ממערכת בסיס */
    M1173: 'M1173',
    /** תם הזמן לכניסה לשלוחה */
    M1174: 'M1174',
    /** מספרכם אינו מזוהה כשיך למערכת, אנא הקישו את מספר הזיהוי שלכם,. או את מספר הטלפון המשוייך למערכת, וסולמית לסיום. */
    M1175: 'M1175',
    /** שגיאה בהגדרת טמפלט, אנא תקנו את ההגדרות */
    M1176: 'M1176',
    /** ירדו לכם */
    M1177: 'M1177',
    /** התווספו לכם */
    M1178: 'M1178',
    /** לכניסה לשידור חי, באם קיים - הקישו 1, לשמיעת שידורים קודמים, הקישו 2 */
    M1179: 'M1179',
    /** הכניסה לשלוחה תחל מ */
    M1180: 'M1180',
    /** בשעה */
    M1181: 'M1181',
    /** ו... */
    M1182: 'M1182',
    /** דקות */
    M1183: 'M1183',
    /** הכניסה לשלוחה תחל בעוד */
    M1184: 'M1184',
    /** שעות */
    M1185: 'M1185',
    /** להמתנה הקישו 1. ליציאה הקישו 2 או כוכבית */
    M1186: 'M1186',
    /** השלוחה תסגר */
    M1187: 'M1187',
    /** בתאריך */
    M1188: 'M1188',
    /** בשעה */
    M1189: 'M1189',
    /** היום */
    M1190: 'M1190',
    /** מחר */
    M1191: 'M1191',
    /** בעוד */
    M1192: 'M1192',
    /** שעות */
    M1193: 'M1193',
    /** ו... */
    M1194: 'M1194',
    /** דקות */
    M1195: 'M1195',
    /** שניות */
    M1196: 'M1196',
    /** ב... */
    M1197: 'M1197',
    /** שינוי מהירות ההשמעה מתבצע כעת, אנא המתינו */
    M1198: 'M1198',
    /** שעון מתקטק - קובץ לא קיים ניתן להקצאה מחדש */
    M1199: 'M1199',
    /** ענית בהצלחה */
    M1200: 'M1200',
    /** עדכון המשימה התקבל בהצלחה */
    M1201: 'M1201',
    /** תשובה נכונה תזכה אתכן עד */
    M1202: 'M1202',
    /** ברוכים הבאים למשחק הטריוויה */
    M1203: 'M1203',
    /** ועכשיו נשאל אתכם שאלה על הקטע שלמדתם */
    M1204: 'M1204',
    /** נקודות */
    M1205: 'M1205',
    /** הנך מועבר לשאלה הבאה */
    M1206: 'M1206',
    /** השאלה היא */
    M1207: 'M1207',
    /** אנא הקישו את מספר התשובה הנכונה */
    M1208: 'M1208',
    /** שעון מתקטק */
    M1209: 'M1209',
    /** תשובתך שגויה */
    M1210: 'M1210',
    /** תשובה ראשונה */
    M1211: 'M1211',
    /** תשובה שניה */
    M1212: 'M1212',
    /** תשובה שלישית */
    M1213: 'M1213',
    /** תשובה רביעית */
    M1214: 'M1214',
    /** אנא נסה שנית */
    M1215: 'M1215',
    /** התשובה הנכונה היא */
    M1216: 'M1216',
    /** נכון או לא נכון */
    M1217: 'M1217',
    /** לנכון הקישו 1 ללא נכון הקישו 0 */
    M1218: 'M1218',
    /** התשובה היא */
    M1219: 'M1219',
    /** לא נכון */
    M1220: 'M1220',
    /** נכון */
    M1221: 'M1221',
    /** סך הניקוד שברשותך הוא */
    M1222: 'M1222',
    /** קיבלת */
    M1223: 'M1223',
    /** בחירה לא חוקית */
    M1224: 'M1224',
    /** השיא שלכם בטרוויה הוא */
    M1225: 'M1225',
    /** הנכם מתחילים משחק חדש */
    M1226: 'M1226',
    /** סך הניקוד במשחק החדש הוא */
    M1227: 'M1227',
    /** סיימתם בהצלחה את כל השאלות בטריוויה בפעם מספר */
    M1228: 'M1228',
    /** סך הניקוד שצברתם במהלך המשחק הוא */
    M1229: 'M1229',
    /** כל הכבוד */
    M1230: 'M1230',
    /** להפעלה מחודשת של הטריוויה הקישו 1 לחזרה לתפריט הראשי הקישו 2 */
    M1231: 'M1231',
    /** השיא החדש שלך הוא */
    M1232: 'M1232',
    /** כבר קיבלת ניקוד על תשובה זו */
    M1233: 'M1233',
    /** הניקוד שלכם עד היום במשחק הוא */
    M1234: 'M1234',
    /** סך הניקוד הכללי שלכם בטריוויה */
    M1235: 'M1235',
    /** הנכם מקבלים כפל נקודות. סך הנקודות החדש כולל הבונוס הוא. */
    M1236: 'M1236',
    /** כבר קיבלת כפל נקודות בסיום המשחק בפעם הראשונה - לא פעיל כרגע ואין הקלטה כזן */
    M1237: 'M1237',
    /** בפעם מספר */
    M1238: 'M1238',
    /** סיימתם בהצלחה את משחק הטריוויה */
    M1239: 'M1239',
    /** אולי בפעם אחרת */
    M1240: 'M1240',
    /** אופס, טעות */
    M1241: 'M1241',
    /** הפעם שגית */
    M1242: 'M1242',
    /** לא נורא */
    M1243: 'M1243',
    /** ממש... לא! */
    M1244: 'M1244',
    /** מענין, אבל זה לא זה */
    M1245: 'M1245',
    /** נסה שוב */
    M1246: 'M1246',
    /** שווה לקרוא את החומר פעם נוספת */
    M1247: 'M1247',
    /** סיימתם את כל השאלות בטריוויה */
    M1248: 'M1248',
    /** לסיום הדירוג ויציאה הקישו 1 להמשך הקישו 2 או המתינו */
    M1249: 'M1249',
    /** אדיר */
    M1250: 'M1250',
    /** איזו בקיאות */
    M1251: 'M1251',
    /** אין כמוך */
    M1252: 'M1252',
    /** אתה ממש גאון */
    M1253: 'M1253',
    /** אתה פשוט עשר */
    M1254: 'M1254',
    /** וואו!! אתה מקסים */
    M1255: 'M1255',
    /** חכם כמוך לא רואים כל יום */
    M1256: 'M1256',
    /** יפה מאוד */
    M1257: 'M1257',
    /** יש במה להתגאות */
    M1258: 'M1258',
    /** יש לך ראש פיצוץ */
    M1259: 'M1259',
    /** כל הכבוד */
    M1260: 'M1260',
    /** לא יאומן! */
    M1261: 'M1261',
    /** מדהים */
    M1262: 'M1262',
    /** מיוחד */
    M1263: 'M1263',
    /** נפלא */
    M1264: 'M1264',
    /** תמיד אמרו עליך שאתה ילד מחונן */
    M1265: 'M1265',
    /** תמשיך כך */
    M1266: 'M1266',
    /** בעוד X... */
    M1267: 'M1267',
    /** דירוגים, תוכלו לצאת */
    M1268: 'M1268',
    /** לסיום הדירוג ויציאה הקישו 1 להמשך הקישו 2 או המתינו */
    M1269: 'M1269',
    /** הנך מועבר להקלטת שאלה מספר */
    M1270: 'M1270',
    /** אנא הקליטו את השאלה לאחר השמע הצליל, לסיום הקישו סולמית */
    M1271: 'M1271',
    /** אנא הקליטו את התשובה הנכונה ובסיום הקישו סולמית */
    M1272: 'M1272',
    /** אנא הקליטו מסיח ראשון ובסיום הקישו סולמית */
    M1273: 'M1273',
    /** אנא הקליטו מסיח שני ובסיום הקישו סולמית */
    M1274: 'M1274',
    /** אנא הקליטו מסיח שלישי ובסיום הקישו סולמית */
    M1275: 'M1275',
    /** ניתן להכנס לשלוחה זו, רק לאחר האזנה לקובץ מוגדר */
    M1276: 'M1276',
    /** אם ברצונכם בהקלטת מסיח שלישי הקישו 1. להקלטת שאלה נוספת הקישו 2. לחזרה לתפריט הראשי הקישו 3 */
    M1277: 'M1277',
    /** להקלטת שאלה נוספת הקישו 1. לחזרה לתפריט הראשי הקישו 2 */
    M1278: 'M1278',
    /** להקלטת שאלה טריוויה אמריקאית. הקישו 1. להקלטת שאלת נכון או לא נכון הקישו 2 */
    M1279: 'M1279',
    /** להקלטת שאלה שהתשובה עליה נכון הקישו 1. להקלטת שאלה שהתשובה עליה לא נכון הקישו 2 */
    M1280: 'M1280',
    /** השאלה הוקלטה בהצלחה */
    M1281: 'M1281',
    /** התשובה הנכונה הוקלטה בהצלחה */
    M1282: 'M1282',
    /** מסיח ראשון הוקלט בהצלחה */
    M1283: 'M1283',
    /** מסיח שני הוקלט בהצלחה */
    M1284: 'M1284',
    /** מסיח שלישי הוקלט בהצלחה */
    M1285: 'M1285',
    /** עדיין לא הגיע זמן הכניסה שלכם לשלוחה זו */
    M1286: 'M1286',
    /** זמן אישור הכניסה שלכם לשלוחה זו, הסתיים */
    M1287: 'M1287',
    /** הנכם ממשיכים לפי הגדרות ברירת המחדל */
    M1288: 'M1288',
    /** להקלטת שאלה חדשה הקישו 1. לעריכת שאלה קיימת הקישו 2 */
    M1290: 'M1290',
    /** השלוחה האַחַרונה שנפתחה עבורכם היא שלוחה... */
    M1291: 'M1291',
    /** הודעת שקט עבור פונקציית השמעת השלוחה שנפתחה */
    M1292: 'M1292',
    /** מספר הטלפון שנקלט הוא */
    M1294: 'M1294',
    /** לאישור הקישו אחת וסולמית. לכניסה עם מספר אחר הקישו את המספר טלפון המלא וסולמית לסיום */
    M1295: 'M1295',
    /** אנא הקישו את מספר הטלפון המלא וסולמית לסיום */
    M1296: 'M1296',
    /** קליק מספר */
    M1298: 'M1298',
    /** לא מוגדר כמות תיקיות לסריקה */
    M1299: 'M1299',
    /** להמשך, הקישו 1 או המתינו. לחזרה לתפריט קודם, הקישו 2 */
    M1300: 'M1300',
    /** בשלוחה זו צברת */
    M1301: 'M1301',
    /** אי צבירת נקודות נוספות עדיין בתוקף */
    M1302: 'M1302',
    /** אי צבירת נקודות נוספות בתיקיה זו עדיין בתוקף */
    M1303: 'M1303',
    /** על ערך זה צברת */
    M1304: 'M1304',
    /** ההודעה קצרה מידי */
    M1305: 'M1305',
    /** ההודעה מבוטלת */
    M1306: 'M1306',
    /** תגובות */
    M1307: 'M1307',
    /** סוף תגובות */
    M1308: 'M1308',
    /** אין תגובות להשמעה */
    M1309: 'M1309',
    /** להקלטת תגובה הקישו 1. לשמיעת התגובות הקישו 2. להמשך הקישו 9 או המתינו */
    M1310: 'M1310',
    /** אנא הקש את מספר מערכת הלקוח עבורו להוציא את החשבונית */
    M1311: 'M1311',
    /** אין ארועים */
    M1312: 'M1312',
    /** אירועים להיום */
    M1313: 'M1313',
    /** אירועים ליום */
    M1314: 'M1314',
    /** לאירועים מהיום הקישו 1 או המתינו. לאירועים מיום אחר הקישו 2 */
    M1315: 'M1315',
    /** לבחירת תאריך עברי הקישו 1. לבחירת תאריך לועזי הקישו 2 */
    M1316: 'M1316',
    /** אנא הקישו את התאריך העברי ב6 ספרות. לדוגמא ליום ג תשרי בשנת עה. הקישו ג 03, תשרי 01, עה 75 */
    M1317: 'M1317',
    /** . אנא הקישו את התאריך הלועזי ב6 ספרות. לדוגמא ליום הראשון במרץ 2015. הקישו יום 01, חודש מרץ 03, ושנה ב2 ספרות - 15. */
    M1318: 'M1318',
    /** לדירוג הקש 1 לשמיעת הדירוגים הקש 2 להמשך הקישו 3 או המתינו */
    M1320: 'M1320',
    /** אנא דרג מ1 עד 5, כאשר 1 זה הדירוג הנמוך ביותר ו5 זה הדירוג הגבוה ביותר */
    M1321: 'M1321',
    /** אין זיהוי טלפוני. לא ניתן לדרג. */
    M1322: 'M1322',
    /** על פי רשומי המערכת כבר דירגת את השמעה זו. */
    M1323: 'M1323',
    /** הדרוג שהוקש שגוי ניתן לדרג בין 1 ל 5 בלבד */
    M1324: 'M1324',
    /** הדירוג התקבל בהצלחה */
    M1325: 'M1325',
    /** לשמיעת הדירוגים הקש 1 להמשך הקישו 2 או המתינו */
    M1326: 'M1326',
    /** הדירוג שלך הוא */
    M1327: 'M1327',
    /** כמות המדרגים */
    M1328: 'M1328',
    /** ממוצע הדירוג */
    M1329: 'M1329',
    /** בשלוחה זו עדיין אין השמעות */
    M1330: 'M1330',
    /** לצורכי אבטחה מיד נשמיע לך 3 ספרות אותם תצטרך להקיש על מקשי הטלפון - הספרות הן */
    M1331: 'M1331',
    /** תודה רבה. המערכת נפתחה בהצלחה. מיד תקבלו שיחת טלפון מהמערכת החדשה שלכם. אנו חזרו למספר המופיע על הצג להשלמת הרישום */
    M1332: 'M1332',
    /** באם ברצונכם בקבלת תגמול עבור המערכת אנא הקישו 1 למעבר להקשת ת.ז. לדילוג הקישו 2 */
    M1333: 'M1333',
    /** אנא הקישו את ת.ז. של בעל המערכת ב9 ספרות */
    M1334: 'M1334',
    /** תעודת הזהות שגויה */
    M1335: 'M1335',
    /** לתשומת לבכם, השימוש עם מספר אישי זה הגיע לסיומו, שלום ותודה. */
    M1336: 'M1336',
    /** השעה כעת */
    M1337: 'M1337',
    /** ve - ו... */
    M1338: 'M1338',
    /** דקות */
    M1339: 'M1339',
    /** נרשמת בהצלחה, אישור מספר */
    M1340: 'M1340',
    /** לסיום הקישו 1. לשמיעת מספר האישור פעם נוספת הקישו 2. */
    M1341: 'M1341',
    /** ההרשמה התמלאה. אנא נסו שוב מחר. */
    M1342: 'M1342',
    /** המספר עכשיו הוא */
    M1343: 'M1343',
    /** המספר לעכשיו עדיין לא הוגדר */
    M1344: 'M1344',
    /** אנא הקש את המספר להשמעה,. לביטול עריכה הקש כוכבית וסולמית,. להגדיר שהמספרים לעכשיו הסתיימו הקישו אפס וסולמית,. להגדיר שהמספר עדיין לא הוגדר הקישו כוכבית כוכבית כוכבית וסולמית */
    M1345: 'M1345',
    /** המספרים לעכשיו הסתיימו */
    M1346: 'M1346',
    /** אין נתונים להשמעה */
    M1347: 'M1347',
    /** הרשמה זו התמלאה והסתיימה. שלום ותודה. */
    M1348: 'M1348',
    /** להוספת השמעה זו לרשימת השמעה ברירת המחדל הקישו 1. להוספת השמעה זו לרשימת השמעה אחרת הקישו 2. להוספת כל ההשמעות שבשלוחה זו לרשימת השמעה חדשה הקישו 3. לביטול הקישו כוכבית */
    M1349: 'M1349',
    /** מספרך אינו מזוהה במערכת. ניתן להוסיף לרשימות השמעה מטלפון מזוהה בלבד */
    M1350: 'M1350',
    /** ההשמעה צורפה בהצלחה ל... (רשימת השמעה) */
    M1351: 'M1351',
    /** אנא הקליטו את שם רשימת ההשמעה */
    M1352: 'M1352',
    /** לאישור הקישו 1 להקלטה מחודשת 2 */
    M1353: 'M1353',
    /** שם רשימת ההשמעה נקלט בהצלחה */
    M1354: 'M1354',
    /** אנא הקישו את מספר רשימת ההשמעה להוספה וסולמית לסיום, ניתן להקיש כל מספר עד 10 ספרות. */
    M1355: 'M1355',
    /** הרשימות הקיימות הם: */
    M1356: 'M1356',
    /** הוספת קיצור דרך לכל השלוחה - ברשימת השמעה שלכם. אנא הקישו את מספר הרשימה להוספה וסולמית לסיום, ניתן להקיש כל רשימה שאינה קיימת ועד 10 ספרות. */
    M1357: 'M1357',
    /** רשימת השמעה זו כבר קיימת. */
    M1358: 'M1358',
    /** מספרך אינו מזוהה במערכת. ניתן להתחבר לרשימות השמעה אישיות מטלפון מזוהה בלבד */
    M1359: 'M1359',
    /** ברוכים הבאים לרשימת ההשמעה האישית שלכם. רשימת ההשמעה שלכם ריקה, ניתן להוסיף לרשימה במהלך האזנה בתכני המערכת. */
    M1360: 'M1360',
    /** ברוכים הבאים לרשימת ההשמעה האישית שלכם. להפעלת רשימת ברירת המחדל הקישו 1 או המתינו. להפעלת רשימה אחרת הקישו 2. להגדרת רשימת השמעה ברירת המחדל הקישו 3. להגדרת צורת ההפעלה וההגדרות נוספות בשלוחה הקישו 4. לחזרה הקישו כוכבית */
    M1361: 'M1361',
    /** רשימת השמעה זו ריקה אנא בחרו רשימה אחרת */
    M1362: 'M1362',
    /** רשימת השמעה ברירת מחדל שלכם היא רשימה מספר */
    M1363: 'M1363',
    /** לאישור וחזרה הקישו 1. לשינוי הקישו 2 */
    M1364: 'M1364',
    /** אנא הקישו את הרשימה אותה ברצונכם להגדיר כברירת מחדל וסולמית לסיום. */
    M1365: 'M1365',
    /** הגדרתם בהצלחה לרשימת ברירת מחדל את */
    M1366: 'M1366',
    /** אנא הקישו את מספר רשימת ההשמעה וסולמית לסיום */
    M1367: 'M1367',
    /** לא ניתן להקיש מקש כוכבית */
    M1368: 'M1368',
    /** להגדרת מיקום תחילת הפעלת הרשימה הקישו 1. לשינוי שם השלוחה הקישו 2. להעברת השמעה זו לרשימת השמעה חדשה אחרת הקישו 3. להגדרת השמעה זו כהשמעת ברירת מחדל הקישו 4. למחיקת כל רשימת השמעה זו הקישו 5. ליציאה הקישו כוכבית */
    M1369: 'M1369',
    /** האם הנכם בטוחים? לאישור מחיקת כל רשימת השמעה זו הקישו 1 */
    M1370: 'M1370',
    /** הרשימה נמחקה בהצלחה */
    M1371: 'M1371',
    /** אנא הקישו את מספר הרשימה החדשה להעברה וסולמית לסיום */
    M1372: 'M1372',
    /** רשימת השמעה כבר קיימת אנא בחרו רשימה אחרת */
    M1373: 'M1373',
    /** רשימת ההשמעה הועברה בהצלחה */
    M1374: 'M1374',
    /** ההפעלה בשלוחה זו מוגדרת כ... */
    M1375: 'M1375',
    /** הפעלה מהקובץ שצורף אחרון */
    M1376: 'M1376',
    /** הפעלה מהקובץ שצורף ראשון */
    M1377: 'M1377',
    /** הפעלה בסדר אקראי */
    M1378: 'M1378',
    /** להפעלה מהקובץ שצורף ראשון הקישו 1. להפעלה מהקובץ שצורף אחרון הקישו 2. להפעלה בסדר אקראי הקישו 3. לביטול ויציאה הקישו כוכבית */
    M1379: 'M1379',
    /** הגדרתם בהצלחה */
    M1380: 'M1380',
    /** מחיקת ההשמעה. האם הנכם בטוחים? לאישור המחיקה הקישו 1 */
    M1381: 'M1381',
    /** מחיקת ההשמעה התבצעה בהצלחה */
    M1382: 'M1382',
    /** שמיעה חוזרת 0. לפרטי ההשמעה הקישו 1. לשיתוף ההשמעה עם רשימת השמעה נוספת הקישו 2. להעברת השמעה זו לרשימת השמעה אחרת הקישו 3. למחיקת השמעה זו הקישו 4. לשיתוף ההשמעה זו עם קבוצות ומערכות תכנים אחרות הקישו 5 */
    M1383: 'M1383',
    /** אנא הקישו את מספר רשימת ההשמעה להעברה וסולמית לסיום */
    M1384: 'M1384',
    /** האם הנכם בטוחים? לאישור מחיקת השמעה זו מרשימת ההשמעה הקישו 1 */
    M1385: 'M1385',
    /** ההשמעה נמחקה בהצלחה */
    M1386: 'M1386',
    /** שמיעה חוזרת 0. לפרטי ההשמעה הקישו 1. לשיתוף ההשמעה עם רשימת השמעה נוספת הקישו 2. לשיתוף ההשמעה זו עם קבוצות ומערכות תכנים אחרות הקישו 5 */
    M1387: 'M1387',
    /** לא ניתן להעביר השמעה בהפעלת רשימת השמעה של שלוחה שלמה,. במקום זאת, ניתן לשתף. */
    M1388: 'M1388',
    /** לא ניתן למחוק השמעה בהפעלת רשימת השמעה של שלוחה שלמה */
    M1389: 'M1389',
    /** לאפשרויות האזנה הקישו כוכבית */
    M1390: 'M1390',
    /** תפריט אפשרויות more_optionsA במודול playfile. לשמיעה חוזרת הקישו אפס. להוספת ההשמעה לרשימת ההשמעות האישיות שלכם הקישו 1. לדירוג ההשמעה הקישו 2. לשיתוף השמעה זו עם מערכות אחרות הקישו 3. לתגובה על השמעה זו הקישו 4. מונה האזנות - ובמידה ומורשה להשמיע את הרשימה 5. 6... להפעלת כל שלוחה זו בסדר אקראי הקישו 7. לשמיעת אפשרויות הקשה במהלך ההשמעה הקישו 8. לשמיעת מיקום ההשמעה בה אתה נמצא הקישו 9. לחזרה להשמעה הקישו כוכבית או המתינו. */
    M1391: 'M1391',
    /** אין אישור להעברת הקובץ */
    M1392: 'M1392',
    /** אנא הקישו את מספר המערכת להעתקת הקובץ */
    M1393: 'M1393',
    /** הקובץ הועתק בהצלחה */
    M1394: 'M1394',
    /** חלה שגיאה בהעתקת הקובץ */
    M1395: 'M1395',
    /** אנא הקישו את מספר השלוחה לשיתוף ניתן לשתף רק לתיקיות של השמעת תכנים בלבד לביטול השיתוף הקישו כוכבית וסולמית */
    M1396: 'M1396',
    /** השלוחה שבחרתם אינה קיימת או שאינה של השמעת קבצים */
    M1397: 'M1397',
    /** לא ניתן להקליט תגובה בשלוחה זו. */
    M1398: 'M1398',
    /** תגובתך התקבלה בהצלחה */
    M1399: 'M1399',
    /** תגובתך התקבלה בהצלחה והועברה לאישור המנהל */
    M1400: 'M1400',
    /** לא ניתן להקליט תגובה ללא זיהוי טלפוני, אנא צלצלו מספר מזוהה */
    M1401: 'M1401',
    /** אנא הקליטו את תגובתכם לאחר השמע הצליל, לסיום הקישו סולמית */
    M1402: 'M1402',
    /** יש לך... */
    M1403: 'M1403',
    /** תגובות ממתינות לאישור */
    M1404: 'M1404',
    /** אין תגובות ממתינות לאישור */
    M1405: 'M1405',
    /** . לשמיעה חוזרת הקישו 0. לאישור התגובה הקישו 1. למחיקת התגובה הקישו 2. לפרטי התגובה הקישו 3. לדילוג והחלטה במועד מאוחר יותר הקישו 4. ליציאה הקישו כוכבית. */
    M1406: 'M1406',
    /** להשמעה הבאה (X ,תגובות להאזנה הקישו..) */
    M1407: 'M1407',
    /** תגובות, להאזנה הקישו כוכבית ארבע */
    M1408: 'M1408',
    /** הקובץ הועבר בהצלחה */
    M1409: 'M1409',
    /** עדין אין תגובות, להקלטת תגובה הקישו 1. להמשך הקישו 9 או המתינו */
    M1410: 'M1410',
    /** יש (X תגובות) */
    M1411: 'M1411',
    /** (יש X) תגובות */
    M1412: 'M1412',
    /** הקופונים נגמרו. */
    M1413: 'M1413',
    /** אין כרגע קופונים לחלוקה */
    M1414: 'M1414',
    /** הקופון שלך הוא */
    M1415: 'M1415',
    /** לסיום הקישו 1. לשמיעת הקופון פעם נוספת הקישו 2. */
    M1416: 'M1416',
    /** הסרתם בהצלחה את הטלפון שלכם מרשימת התפוצה */
    M1417: 'M1417',
    /** הוספתם בהצלחה את הטלפון שלכם לרשימת התפוצה */
    M1418: 'M1418',
    /** אנא הקישו הסכום לחיוב */
    M1419: 'M1419',
    /** שקלים חדשים */
    M1420: 'M1420',
    /** הסכום חייב להיות גדול מ 0 שקלים, אנא נסו שנית */
    M1421: 'M1421',
    /** אנא הקישו את מספר כרטיס האשראי משמאול לימין ובסיום הקישו סולמית ליציאה הקישו כוכבית וסולמית */
    M1422: 'M1422',
    /** תוקף הכרטיס שגוי - יש להקיש תוקף ב4 ספרות חודש ב2 ספרות ושנה ב2 ספרות */
    M1423: 'M1423',
    /** אנא הקישו את תוקף הכרטיס בארבע ספרות */
    M1424: 'M1424',
    /** קיימת שגיאת התחברות עם השרת, אנא נסו מחדש בעוד מספר דקות, תודה */
    M1425: 'M1425',
    /** העיסקה נדחתה - סטטוס סירוב */
    M1426: 'M1426',
    /** אנא נסו שנית - עם כרטיס אחר */
    M1427: 'M1427',
    /** אנא הקישו את 3 הספרות בגב הכרטיס */
    M1428: 'M1428',
    /** אנא הקישו את מספר תעודת הזהות של בעל הכרטיס ובסיום הקישו סולמית */
    M1429: 'M1429',
    /** העיסקה התקבלה בהצלחה */
    M1430: 'M1430',
    /** אישור מספר */
    M1431: 'M1431',
    /** לשמיעה חוזרת של מספר האישור הקישו 1 לסיום הרכישה והמשך הקישו 2 */
    M1432: 'M1432',
    /** אין שם משתמש */
    M1433: 'M1433',
    /** אין מספר מסוף */
    M1434: 'M1434',
    /** אין סיסמת מסוף */
    M1435: 'M1435',
    /** אנא הקישו את מספר התשלומים, ניתן לחלק עד ל */
    M1436: 'M1436',
    /** תשלומים */
    M1437: 'M1437',
    /** כאשר התשלום הראשון יהיה בגובה של .. */
    M1438: 'M1438',
    /** כמות התשלומים אינה תקינה */
    M1439: 'M1439',
    /** אנא הקש את המפתח שלך וסולמית לסיום */
    M1440: 'M1440',
    /** המפתח שהוקש אינו קיים. */
    M1441: 'M1441',
    /** מפתח זה כבר סיים את מקסימום השימושים. */
    M1442: 'M1442',
    /** אנא הקישו את השיוך שלכם, לדילוג הקישו סולמית או המתינו */
    M1443: 'M1443',
    /** עד כה חולקו */
    M1444: 'M1444',
    /** ספרים */
    M1445: 'M1445',
    /** סיסמת הקלטות והפעלת שידור חי */
    M1446: 'M1446',
    /** נרשמת בהצלחה */
    M1447: 'M1447',
    /** פג תוקף השידור. לחידוש אנא פנה לשרות הלקוחות */
    M1448: 'M1448',
    /** ההגדרות לא הושלמו */
    M1449: 'M1449',
    /** שגיאה בהפעלת השידור */
    M1450: 'M1450',
    /** השידור כבר החל - לא ניתן להכנס לשידור פעיל */
    M1451: 'M1451',
    /** ההודעה הוקלטה בהצלחה */
    M1452: 'M1452',
    /** בשלוחה זו */
    M1453: 'M1453',
    /** השמעות */
    M1454: 'M1454',
    /** תגובות משלוחה */
    M1455: 'M1455',
    /** התגובה נכנסה בהצלחה */
    M1456: 'M1456',
    /** תגובה הבאה */
    M1457: 'M1457',
    /** התגובה נמחקה בהצלחה */
    M1458: 'M1458',
    /** לשמיעה חוזרת הקישו 0. למעבר להשמעה הבאה הקישו 1 */
    M1459: 'M1459',
    /** אין מספרים לחיוג אנא הוסיפו מספרים לחיוג ונסו שנית */
    M1460: 'M1460',
    /** אין הודעה מוקלטת לשידור */
    M1461: 'M1461',
    /** הפעלת קמפיין */
    M1462: 'M1462',
    /** ברשותך */
    M1463: 'M1463',
    /** יחידות */
    M1464: 'M1464',
    /** ברשימת התפוצה שלכם ישנם */
    M1465: 'M1465',
    /** מספרי טלפון לחיוג */
    M1466: 'M1466',
    /** עבור קמפיין זה תחויב ב */
    M1467: 'M1467',
    /** ההודעה לשידור היא */
    M1468: 'M1468',
    /** לאישור הפעלת הקמפיין הקישו 1, לחזרה לתפריט הקישו 2 */
    M1469: 'M1469',
    /** לקוח יקר הקמפיין שביקשת להפעיל כבר פועל במערכת ועדיין לא הסתיים, האם אתה בטוח שברצונך להפעיל קמפיין נוסף? להפעלת קמפין נוסף הקישו 1 אחרת הקישו 2 */
    M1470: 'M1470',
    /** יתרת היחידות החדשה היא */
    M1471: 'M1471',
    /** הקמפיין מופעל כעת */
    M1472: 'M1472',
    /** ההשמעה אותה שמעת לאחרונה, בתיקייה ...XXX */
    M1473: 'M1473',
    /** האזנה מספר */
    M1474: 'M1474',
    /** עצרת בדקה */
    M1475: 'M1475',
    /** אורך ההשמעה */
    M1476: 'M1476',
    /** דקות */
    M1477: 'M1477',
    /** למעבר למשאיר ההודעה הקישו 1, לשמיעה חוזרת של פרטי ההודעה, הקישו 2, לחזרה להודעות הקישו * */
    M1478: 'M1478',
    /** לא ניתן לבצע את השיחה. אנא פנה למנהל המערכת. */
    M1479: 'M1479',
    /** למעבר למשאיר ההודעה הקישו 1,לחזרה להודעות הקישו * */
    M1480: 'M1480',
    /** לשמיעה חוזרת של פרטי ההודעה, הקישו 1, לחזרה להודעות הקישו * */
    M1481: 'M1481',
    /** הוקלטה */
    M1482: 'M1482',
    /** ביום */
    M1483: 'M1483',
    /** אתמול */
    M1484: 'M1484',
    /** בשעה */
    M1485: 'M1485',
    /** הודעה ממספר טלפון */
    M1486: 'M1486',
    /** אין פרטים על ההודעה */
    M1487: 'M1487',
    /** היום */
    M1488: 'M1488',
    /** הועברה ביום */
    M1489: 'M1489',
    /** ו.. */
    M1490: 'M1490',
    /** דקות */
    M1491: 'M1491',
    /** לא מעודכן תאריך להודעה זו */
    M1492: 'M1492',
    /** לא מעודכנת שעה להודעה זו */
    M1493: 'M1493',
    /** להודעה זו לא מעודכן מספר מקליט ההודעה */
    M1494: 'M1494',
    /** ב.. */
    M1495: 'M1495',
    /** יתרת היחידות שברשותך אינה מאפשרת את הוצאת הקמפיין */
    M1496: 'M1496',
    /** הפעלת הקמפין בוטלה */
    M1497: 'M1497',
    /** אנא הקישו את מספר השורה המבוקש. ליציאה הקישו סולמית. */
    M1498: 'M1498',
    /** אין כסאות לבחירה בשורה זו */
    M1499: 'M1499',
    /** בשורה... */
    M1500: 'M1500',
    /** יש */
    M1501: 'M1501',
    /** כסאות זמינים */
    M1502: 'M1502',
    /** אנא הקישו את מספר הכסא המבוקש, לבחירת כסא אקראי הקישו 0 וסולמית ליציאה הקישו סולמית. */
    M1503: 'M1503',
    /** הכסאות הזמינים הם: */
    M1504: 'M1504',
    /** כסא זה אינו זמין למכירה */
    M1505: 'M1505',
    /** בחרת שורה */
    M1506: 'M1506',
    /** כסא */
    M1507: 'M1507',
    /** הסכום לתשלום על הכסא הינו: */
    M1508: 'M1508',
    /** לשמירת המקום הקישו 1. לבחירת כסא אחר הקישו 2 */
    M1509: 'M1509',
    /** הכסא נשמר עד לסיום השיחה */
    M1510: 'M1510',
    /** (כסא...) עדין פנוי באם ברצונך לרכוש גם אותו הקש 1. לחזרה לתפריט הקישו 2 */
    M1511: 'M1511',
    /** שגיאה בשמירת הכסא */
    M1512: 'M1512',
    /** סיום הזמנה */
    M1513: 'M1513',
    /** הוזמנו (X כסאות) */
    M1514: 'M1514',
    /** (הוזמנו X) כסאות */
    M1515: 'M1515',
    /** הסך הכולל לתשלום */
    M1516: 'M1516',
    /** להלן הפירוט */
    M1517: 'M1517',
    /** שורה.. */
    M1518: 'M1518',
    /** מחיר */
    M1519: 'M1519',
    /** הסך הכולל לתשלום */
    M1520: 'M1520',
    /** שקלים */
    M1521: 'M1521',
    /** לאישור ההזמנה הקישו 1. לביטול ההזמנה הקישו 2 */
    M1522: 'M1522',
    /** ההזמנה בוטלה. שלום ותודה */
    M1523: 'M1523',
    /** לתשלום בכרטיס אשראי הקישו 1. לתשלום בהוראת קבע הקובעה במוסד הקישו 2. להקשת קופון הקישו 3 */
    M1524: 'M1524',
    /** המקומות נרכשו בהצלחה. */
    M1525: 'M1525',
    /** הגעת למקסימום כרטיסים הניתן לשמור עבורך הינך מועבר לתשלום */
    M1526: 'M1526',
    /** . כבר יש כסאות קנויים על שמך. לשמיעת הפרטים הקישו 1. להזמנה נוספת הקישו 2. ליציאה הקישו כוכבית */
    M1527: 'M1527',
    /** כבר קנית את מקסימום כסאות האפשרי עבורך, לא ניתן להזמין כסאות נוספים. */
    M1528: 'M1528',
    /** נקנו... (כסאות) */
    M1529: 'M1529',
    /** לסיום ומעבר לתשלום הקישו 1. לקניית כסא נוסף סמוך הקישו 2. לבחירת כסא נוסף בשורה זו הקישו 3. לבחירת מקום בשורה אחרת הקישו 4 */
    M1530: 'M1530',
    /** ...אינו זמין למכירה אנא נסו אפשרויות נוספות */
    M1531: 'M1531',
    /** אין כסא אקראי לבחירה בשורה זו אנא בחר כסא מהתפריט */
    M1532: 'M1532',
    /** העיסקה נקלטה בהצלחה */
    M1533: 'M1533',
    /** חובה לודא מול הנציג תוך 24 שעות שהוראת הקבע נקלטה ותקינה, אחרת הרישום יבוטל */
    M1534: 'M1534',
    /** חובה לודא מול הנציג תוך 24 שעות שהקופון נקלט ותקין אחרת הרישום יבוטל */
    M1535: 'M1535',
    /** אנא הקישו את קוד הקופון שברשותכם וסולמית לסיום */
    M1536: 'M1536',
    /** לסיום ומעבר לתשלום הקישו 1. לבחירת מקום נוסף הקישו 2 */
    M1537: 'M1537',
    /** הקופון שהוקש שגוי */
    M1538: 'M1538',
    /** אין הרשאה לחיוב בהוראת קבע */
    M1539: 'M1539',
    /** עניתם בהצלחה */
    M1540: 'M1540',
    /** תשובתכם שגויה אנא נסו בפעם הבאה */
    M1541: 'M1541',
    /** שגיאה בהפעלת השאלה */
    M1542: 'M1542',
    /** שגיאה בקבלת תשובה נכונה */
    M1543: 'M1543',
    /** שגיאה בהגדרת מספר לניתוב בהפעלה */
    M1544: 'M1544',
    /** אין הרשאה לחיוג למספר זה */
    M1545: 'M1545',
    /** לשיחה יוצאת עם הזיהוי הראשי הקישו 1וסולמית ,לשיחה יוצאת עם זיהוי הטלפון שלכם הקישו 2 וסולמית. לשיחה יוצאת עם זיהוי משויך אחר הקישו את מספרו, ליציאה הקישו כובית וסולמית */
    M1546: 'M1546',
    /** מספר זיהוי עדיין לא אושר לשיחות יוצאות. דרך המערכת, אנא פנה לשרות הלקוחות */
    M1547: 'M1547',
    /** אנא הקישו את מספר הטלפון לחיוג וסולמית לסיום */
    M1548: 'M1548',
    /** אנא הקליטו את השם שעבורו אתם רוכשים את המקומות וכן את הכתובת למשלוח דואר שלו, בסיום ההקלטה הקישו סולמית */
    M1549: 'M1549',
    /** אם ברצונכם שמעתה כל שלוחה אליה תיכנסו תאפשר לכם לבחור איזו השמעה להפעיל, הקישו 1. אם ברצונכם לבטל בחירה זו, כך שבכל השלוחות לא יתאפשר לכם לבחור קובץ, אלא השלוחה תופעל בצורה רגילה, הקישו 2. */
    M1550: 'M1550',
    /** ההגדרה עודכנה בהצלחה - מעתה, בשיחה זו, יתאפשר לבחור קובץ להשמעה, בכל שלוחה של השמעת קבצים. */
    M1551: 'M1551',
    /** ההגדרה עודכנה בהצלחה - מעתה, בשיחה זו, כל השלוחות יופעלו בצורה רגילה. */
    M1552: 'M1552',
    /** לאישור ההקלטה הקישו 1 , לשמיעה הקישו 2 , להקלטה מחדש 3 */
    M1553: 'M1553',
    /** הפרטים נקלטו בהצלחה */
    M1554: 'M1554',
    /** למחיקת ההודעה הקישו 1 לשינוי ההודעה הקישו 2 לחזרה הקישו כוכבית */
    M1555: 'M1555',
    /** הנכם מועברים להקלטת הקובץ מחדש. אנא הקליטו את הודעתכם לאחר הצליל, ובסיום הקישו #. */
    M1556: 'M1556',
    /** הקלטת הקובץ מחדש הסתיימה בהצלחה. */
    M1557: 'M1557',
    /** הודעה לפני הודעת המפתח (במודול כניסה לפי מפתח) */
    M1558: 'M1558',
    /** לשינוי הקלטה זו הקישו 8. להקלטת קובץ חדש לשלוחה זו הקישו 7. שלמיעה חוזרת הקישו 9. למעבר.. להודעה הבאה הקישו 1 או המתינו. למחיקת הקובץ הקישו 2. לשכפול הקובץ 3. להעברת הקובץ 4. להוספת כותרת לשיעור הקישו 5. לשמיעת פרטי ההודעה הקישו 6. להקלטת קובץ חדש לשלוחה זו הקישו 7. לשינוי הקלטה זו הקישו 8 */
    M1559: 'M1559',
    /** שעון נוכחות. לדיווח על כניסה הקישו 1, לדיווח על יציאה הקישו 2, לחזרה לתפריט קודם הקישו כוכבית */
    M1560: 'M1560',
    /** דיווח כניסה התבצע בהצלחה */
    M1561: 'M1561',
    /** דיווח כניסה כבר התבצע בהצלחה */
    M1562: 'M1562',
    /** לחזרה לתפריט הקישו כוכבית, לדיווח מאוחר על היציאה הקישו 1, לדיווח על כניסה נוספת ללא דיווח על היציאה הקישו 2 */
    M1563: 'M1563',
    /** דיווח יציאה התבצע בהצלחה */
    M1564: 'M1564',
    /** דיווח יציאה כבר התבצע בהצלחה */
    M1565: 'M1565',
    /** לחזרה לתפריט הקישו כוכבית , לדיווח מאוחר על הכניסה הקישו 1 , לדיווח על יציאה נוספת ללא דיווח על כניסה הקישו 2 */
    M1566: 'M1566',
    /** לא ניתן לבצע יציאה ללא כניסה, אנא דווחו על כניסה ולאחר מכן יציאה */
    M1567: 'M1567',
    /** סך המשמרת הינו */
    M1568: 'M1568',
    /** שעות */
    M1569: 'M1569',
    /** דיווח מאוחר על כניסה. שימו לב: לאישור סופי של הנתונים יש לגשת למעסיק שלכם. הנתונים נשלחים עם סימון של דיווח מאוחר עם שעת הדיווח. לביטול דיווח הקישו כוכבית וסולמית. לדיווח מאוחר על כניסה מהיום הקישו ב4 ספרות את השעה והדקה. לדוגמא לדיווח על כניסה בשעה שמונה וחמשה הקישו 0805. לדיווח מאוחר על כניסה ביום אחר הקישו 1 וסולמית */
    M1570: 'M1570',
    /** השעה אינה תקינה */
    M1571: 'M1571',
    /** דיווח מאוחר על כניסה התבצע בהצלחה */
    M1572: 'M1572',
    /** דיווח יציאה ללא דיווח כניסה התבצע בהצלחה */
    M1573: 'M1573',
    /** שים לב - על מנת להשלים את הפירוט עליך לגשת למעסיק */
    M1574: 'M1574',
    /** התאריך אינו תקין */
    M1575: 'M1575',
    /** דיווח מאוחר על כניסה בתאריך אחר . אנא הקישו ב4 ספרות את היום והחודש של הדיווח , לדוגמא לדיווח על כניסה ב19 לספטמבר הקישו תשע עשרה אפס תשע , לביטול דיווח הקישו כוכבית וסולמית */
    M1576: 'M1576',
    /** חודש.. */
    M1577: 'M1577',
    /** לא ניתן להקיש תאריך עתידי */
    M1578: 'M1578',
    /** אנא הקישו ב4 ספרות את השעה והדקה. לדוגמא לדיווח על כניסה בשעה שמונה וחמשה הקישו 0805 */
    M1579: 'M1579',
    /** שימו לב! לסיום הטיפול בכניסה ללא יציאה עליך לגשת למעביד. דיווח כניסה נוספת התבצע בהצלחה */
    M1580: 'M1580',
    /** דיווח מאוחר על יציאה. שימו לב: לאישור סופי של הנתונים יש לגשת למעסיק שלכם, הנתונים נשלחים עם סימון של דיווח מאוחר עם שעת הדיווח. לביטול דיווח הקישו כוכבית וסולמית. לדיווח מאוחר על יציאה מהיום הקישו ב4 ספרות את השעה והדקה. לדוגמא לדיווח על יציאה בשעה ארבע אחר הצהרים הקישו 1600, לדיווח מאוחר על יציאה ביום אחר הקישו 1 וסולמית */
    M1581: 'M1581',
    /** לתשומת לבכם סיכום המשמרת הינו על סמך דיווח כניסה מאוחר */
    M1582: 'M1582',
    /** שים לב! לסיום הטיפול עליך לגשת למעביד, דיווח מאוחר של יציאה התקבל בהצלחה. */
    M1583: 'M1583',
    /** דיווח מאוחר על יציאה בתאריך אחר. אנא הקישו ב4 ספרות את היום והחודש של הדיווח, לדוגמא לדיווח על יציאה ב19 לספטמבר הקישו תשע עשרה אפס תשע, לביטול דיווח הקישו כוכבית וסולמית */
    M1584: 'M1584',
    /** אנא הקישו ב4 ספרות את השעה והדקה. לדוגמא לדיווח על יציאה בשעה ארבע אחר הצהרים הקישו 1600 */
    M1585: 'M1585',
    /** לא ניתן להקיש זמן עתידי */
    M1586: 'M1586',
    /** עדיין אין כסאות בהזמנה זו */
    M1587: 'M1587',
    /** לבחירת כסא נוסף בשורה זו הקישו 1, לבחירת כסא נוסף בשורה אחרת הקישו 2, לסיום ומעבר לתשלום הקישו 3 */
    M1588: 'M1588',
    /** לשידור מספר הטלפון ממנו התקשרתם הקישו 1 וסולמית , לשידור מספר טלפון אחר הקישו את מספר הטלפון וסולמית לסיום */
    M1589: 'M1589',
    /** לימוד דף גמרא */
    M1590: 'M1590',
    /** נותרו */
    M1591: 'M1591',
    /** דפים לסיום מחזור מספר */
    M1592: 'M1592',
    /** של השס */
    M1593: 'M1593',
    /** לקבלת דף ללימוד הקישו 1, לחזרה הקישו 2 */
    M1594: 'M1594',
    /** הדף שנפל בחלקך להשלמת סיום השס הוא */
    M1595: 'M1595',
    /** דף */
    M1596: 'M1596',
    /** במסכת */
    M1597: 'M1597',
    /** עד דף */
    M1598: 'M1598',
    /** עיסקה זו תחוייב בפריסה של (X תשלומים) */
    M1599: 'M1599',
    /** אנא הקש מספר תשלומים וסולמית לסיום */
    M1600: 'M1600',
    /** לא ניתן לבחור יותר מ36 תשלומים */
    M1601: 'M1601',
    /** בעיסקה זו ניתן עד */
    M1602: 'M1602',
    /** הסכום לכל תשלום לא יכול להיות קטן מעשרה שקלים */
    M1603: 'M1603',
    /** אין סוג סליקה */
    M1604: 'M1604',
    /** הקש את הספרות כעת */
    M1605: 'M1605',
    /** שגיאה בסוג מערכת לפתיחה */
    M1606: 'M1606',
    /** אין מענה משרת API */
    M1607: 'M1607',
    /** שגיאה בההעברה לשלוחה הבאה */
    M1608: 'M1608',
    /** לא מוגדר לינק */
    M1609: 'M1609',
    /** לאחר הצליל אמרו או הקישו את שם השלוחה המובקשת , לחזרה לתפריט קודם אמרו חזור או הקישו סולמית */
    M1610: 'M1610',
    /** דיבור לא ברור. אנא אמרו שוב */
    M1611: 'M1611',
    /** אין הגדרה לבקשה. אנא אמרו שוב */
    M1612: 'M1612',
    /** לא זוהה דיבור */
    M1613: 'M1613',
    /** כשלון במעבר לשלוחת התשובה */
    M1614: 'M1614',
    /** לאחר הצליל, אנא אמרו את שם המוצר או הקטגוריה המבוקשת */
    M1615: 'M1615',
    /** בקשתכם לקבלת מספר אישי למערכת זו נקלטה בהצלחה. מייד יופיע לכם המספר על צג הטלפון. כעת תוכלו לחייג למערכת זו, דרך המספר שקיבלתם. */
    M1616: 'M1616',
    /** לצערנו לא קיים כעת מספר אישי למספר שלכם */
    M1617: 'M1617',
    /** הכמות ממוצר זה אזלה , אנא נסה שוב במועד אחר */
    M1618: 'M1618',
    /** אנא הקליטו את השם שעבורו התבצעה ההזמנה וכן את הכתובת למשלוח דואר בסיום ההקלטה הקישו סולמית */
    M1619: 'M1619',
    /** אנא הקישו מספר קטלוגי. לתפריט קולי הקישו כוכבית כוכבית וסולמית , לסיום הזמנה ומעבר לתשלום הקישו סולמית, לשמיעת כל המוצרים ברצף הקישו אפס וסולמית, ליציאה הקישו כוכבית וסולמית */
    M1620: 'M1620',
    /** מספר מוצר זה אינו מוגדר */
    M1621: 'M1621',
    /** המחיר למוצר זה */
    M1622: 'M1622',
    /** להזמנת המוצר הקישו 1 . לחזרה הקישו 2 */
    M1623: 'M1623',
    /** אנא הקישו את הכמות להזמנה ממוצר זה */
    M1624: 'M1624',
    /** הכמות לא יכולה להיות אפס */
    M1625: 'M1625',
    /** הכמות היא */
    M1626: 'M1626',
    /** הסך הכולל לתשלום על מוצר זה */
    M1627: 'M1627',
    /** לאישור הזמנת המוצר הקישו 1 לביטול הקישו 2 */
    M1628: 'M1628',
    /** כבר הזמנת */
    M1629: 'M1629',
    /** יחידות ממוצר זה */
    M1630: 'M1630',
    /** הזמנת המוצר נקלטה ונשמרה עד לסיום השיחה. לסיום ומעבר לתשלום הקישו 1. להמשך קניה הקישו 2 */
    M1631: 'M1631',
    /** סיום הזמנה */
    M1632: 'M1632',
    /** הוזמנו */
    M1633: 'M1633',
    /** מוצרים */
    M1634: 'M1634',
    /** שהם */
    M1635: 'M1635',
    /** פריטים */
    M1636: 'M1636',
    /** הסך הכולל לתשלום עבור כלל המוצרים */
    M1637: 'M1637',
    /** שקלים */
    M1638: 'M1638',
    /** לאישור ההזמנה הקישו 1 , לביטול ההזמנה הקישו 2 */
    M1639: 'M1639',
    /** להלן פירוט ההזמנה */
    M1640: 'M1640',
    /** מוצר */
    M1641: 'M1641',
    /** מחיר */
    M1642: 'M1642',
    /** הוזמנו */
    M1643: 'M1643',
    /** פריטים */
    M1644: 'M1644',
    /** תשלום כולל עבור מוצר זה */
    M1645: 'M1645',
    /** לשמיעת הפירוט אנא המתינו */
    M1646: 'M1646',
    /** לתשלום בכרטיס אשראי הקישו 1 לתשלום בהכנסת נתונים הקישו 2 לתשלום במזומן הקישו 3 לתשלום סוכנים הקישו 4 */
    M1647: 'M1647',
    /** סוכן לא מאושר */
    M1648: 'M1648',
    /** אנא הקישו את מספר הסוכן שלכם וסולמית לסיום */
    M1649: 'M1649',
    /** ההזמנה התבצעה בהצלחה */
    M1650: 'M1650',
    /** אישור מספר */
    M1651: 'M1651',
    /** ההזמנה בוטלה שלום ותודה */
    M1652: 'M1652',
    /** אין מוצרים בסל הקניות שלך */
    M1653: 'M1653',
    /** לפניכם */
    M1654: 'M1654',
    /** מוצרים לבחירה */
    M1655: 'M1655',
    /** אין מוצרים לבחירה */
    M1656: 'M1656',
    /** כבר בוצעה כניסה עם קוד זה. לא ניתן לבצע כניסה עם אותו קוד פעמיים */
    M1657: 'M1657',
    /** לאישור הקישו 1, לעריכת ההזמנה הקישו 2 */
    M1658: 'M1658',
    /** להזמנה ממוצר זה הקישו1, למעבר למוצר הבא הקישו 2, לסיום הזמנה ומעבר לתשלום הקישו 3 או אפס , לחזרה לתפריט קודם הקישו 4 או סולמית */
    M1659: 'M1659',
    /** אנא הקישו כמות ובסיום הקישו # */
    M1660: 'M1660',
    /** הכמות שהוקשה היא */
    M1661: 'M1661',
    /** לאישור הקישו 1 לשינוי הקישו 2 */
    M1662: 'M1662',
    /** הכמות שהוקשה אינה תקינה */
    M1663: 'M1663',
    /** הכמות שבחרת ניקלטה בהצלחה */
    M1664: 'M1664',
    /** עד כה חולק */
    M1665: 'M1665',
    /** מהכמות המבוקשת */
    M1666: 'M1666',
    /** תודה רבה */
    M1667: 'M1667',
    /** לתשומת ליבכם, דמי משלוח עבור הזמנה זו בסך של */
    M1668: 'M1668',
    /** לקבלת דף גמרא נוסף הקישו 1, לחזרה לתפריט הקישו 2 */
    M1669: 'M1669',
    /** לקבלת פרק נוסף הקישו 1, לחזרה לתפריט הקישו 2 */
    M1670: 'M1670',
    /** לקבלת מספר אישי לטלפון אשר ממנו אתם מחייגים, הקישו 1, לשליחת מספר אישי לטלפון אחר, הקישו 2, לדיווח על מספר שנחסם, הקישו 3, */
    M1671: 'M1671',
    /** אנא הקישו את מספר הטלפון שאליו בירצוכם לשלוח מספר אישי של מערכת זו. */
    M1672: 'M1672',
    /** הפעולה בוצעה בהצלחה, מספר אישי למערכת זו, נשלח בהצלחה למיספר הטלפון שהקשתם. */
    M1673: 'M1673',
    /** לצערנו לא ניתן לישלוח כעת מספר אישי, למספר הטלפון שהוקש. */
    M1674: 'M1674',
    /** שלום, קיבלתם שיחה זו מפני שמישהו המליץ לכם להאזין למערכת מסויימת. לשמיעת מספר הטלפון של מי שהימליץ לכם, הקישו 1. לקבלת מספר המערכת שהומלצה עבורכם, הקישו 2. כדי להגדיר האם תמשיכו לקבל, או לא תמשיכו לקבל יותר התראות על המלצות חדשות, הקישו 3. */
    M1675: 'M1675',
    /** מספר הטלפון של מי שהמליץ לכם הוא */
    M1676: 'M1676',
    /** המערכת שלחה לכם כעת שיחה ממספר הטלפון של המערכת שהומלצה עבורכם, כעת תוכלו להתקשר למערכת שהומלצה עבורכם, דרך מיספר הטלפון שקיבלתם. */
    M1677: 'M1677',
    /** להפסקת קבלת התראות על המלצות חדשות, הקישו 1, להמשך קבלת התראות על המלצות חדשות, הקישו 2. */
    M1678: 'M1678',
    /** ההגדרה עודכנה בהצלחה, לא תקבלו יותר התראות על המלצות חדשות, עד שתשנו הגדרה זו, להמשך קבלת התראות. */
    M1679: 'M1679',
    /** ההגדרה עודכנה בהצלחה, כעת תמשיכו לקבל התראות על המלצות חדשות. */
    M1680: 'M1680',
    /** ברוכים הבאים למשחק חשבון */
    M1681: 'M1681',
    /** במשחק חשבון עד היום צברת */
    M1682: 'M1682',
    /** דמי משלוח . באם ברצונכם לאסוף את המוצר בעצמכם ללא תוספת דמי משלוח הקישו 2 , להמשך כולל דמי משלוח בסך */
    M1683: 'M1683',
    /** הקישו 1 */
    M1684: 'M1684',
    /** לֶיֶצִיאַה, הקישו 1, להמשך המתנה, הקישו 2, או הַמְתִּינוּ. */
    M1685: 'M1685',
    /** קטגוריה זו הסתיימה. למעבר לתשלום הקישו הקישו 1 או אפס. לחזרה לתפריט קודם הקישו 2 או סולמית */
    M1686: 'M1686',
    /** אפשרות לא מאושרת */
    M1687: 'M1687',
    /** המלאי הזמין ממוצר זה כרגע הוא */
    M1688: 'M1688',
    /** אנא בחר כמות הקיימת במלאי */
    M1689: 'M1689',
    /** מיקומך בתור הוא */
    M1690: 'M1690',
    /** לאחר הצליל אנא הקליטו את ההודעה למנהל המערכת, ההודעה תשלח במידה והעיסקה תבוצע בהצלחה, בסיום ההקלטה הקישו סולמית. */
    M1691: 'M1691',
    /** ימות המשיח עתיד התקשורת כבר כאן - גינגל חתוך לצורך שיחה נכנסת בראוטינג */
    M1692: 'M1692',
    /** שיחה זו מועברת אליכם באמצעות הפלטפורמה הטכנולגית של ימות המשיח, לקבלת השיחה הקישו 1, לדחיית השיחה הקישו 2 */
    M1693: 'M1693',
    /** לשמיעה חוזרת של מספר האישור הקישו 1 . לסיום הקישו 2 */
    M1694: 'M1694',
    /** הזמן המשוער להמתנה בדקות הוא */
    M1695: 'M1695',
    /** לא ניתן לבצע סליקה עם מספר האשראי שהוקש */
    M1696: 'M1696',
    /** שימו לב, לבקשתכם, נחסמתם מלקבל צינתוקים ממערכת זו.  ולכן, לא ניתן לשלוח לכם כעת מספר אישי. */
    M1697: 'M1697',
    /** אם ברצונכם לאשר קבלת צינתוקים מהמערכת, ולקבל מספר אישי, הקישו 1. לביטול ויְצִיאָה, הקישו 2, או הַמְתינו. */
    M1698: 'M1698',
    /** לצערנו לא קַיָּם מספר אישי למספר הטלפון שלכם . המספר הישיר לְחיוג למערכת זו הוא */
    M1699: 'M1699',
    /** הקווים העוברים בתחנה הם */
    M1701: 'M1701',
    /** בשעה */
    M1702: 'M1702',
    /** קו */
    M1703: 'M1703',
    /** אנא הקישו מספר תחנה */
    M1704: 'M1704',
    /** יגיע בעוד */
    M1705: 'M1705',
    /** דקות */
    M1706: 'M1706',
    /** יגיע בעוד פחות מדקה */
    M1710: 'M1710',
    /** א' */
    M1711: 'M1711',
    /** שתי */
    M1712: 'M1712',
    /** אנא הקישו מספר אוטובוס */
    M1713: 'M1713',
    /** ונמצא בתחנה */
    M1715: 'M1715',
    /** ונמצא בתחנת המוצא */
    M1716: 'M1716',
    /** לכיוון */
    M1717: 'M1717',
    /** אין מיקום משוער */
    M1718: 'M1718',
    /** הנך פעם ראשונה במערכת, ועדיין אין לך חיפושים שמורים. */
    M1719: 'M1719',
    /** אנא הקישו יום בשבוע */
    M1720: 'M1720',
    /** ל- */
    M1722: 'M1722',
    /** הקישו */
    M1723: 'M1723',
    /** נבחר מפעיל שגוי */
    M1724: 'M1724',
    /** אנא בחר מפעיל מהרשימה */
    M1726: 'M1726',
    /** נבחר יום שגוי */
    M1727: 'M1727',
    /** אנא בחר מסלול מהרשימה */
    M1728: 'M1728',
    /** נבחר מסלול שגוי */
    M1729: 'M1729',
    /** אנא הקישו שעה רצויה בין 0 ל-23 */
    M1730: 'M1730',
    /** אנא הקישו מספר דקות רצוי בין 0 ל-59 */
    M1731: 'M1731',
    /** נבחרה שעה שגויה */
    M1732: 'M1732',
    /** נבחר מספר דקות שגוי */
    M1733: 'M1733',
    /** הקו יעבור בתחנה */
    M1734: 'M1734',
    /** לא נמצאה תזכורת */
    M1735: 'M1735',
    /** אנא הקישו את מספר הדקות טרם הגעת האוטובוס לתחנה לקבלת התזכורת */
    M1736: 'M1736',
    /** התזכורת התקבלה בהצלחה */
    M1737: 'M1737',
    /** אין הגדרה לבקשה */
    M1797: 'M1797',
    /** האם לא קיבלתם את שיחת האימות? */
    M1798: 'M1798',
    /** הקישו 1 כדי לקבל שוב את שיחת האימות, או 2 כדי לחזור להקיש את הספרות שקיבלתם. שימו לב, אם אינכם מקבלים את השיחה, עליכם לוודא, כי האפשרות של שיחה ממתינה, לא חסומה אצלכם בהגדרות הטלפון, תוכלו גם לפנות לחברת התקשורת שלכם לפתיחת האפשרות של שיחה ממתינה. הקישו 1 כדי לקבל שוב את שיחת האימות, או 2 כדי לחזור להקיש את הספרות שקיבלתם. */
    M1799: 'M1799',
    /** אנא הקישו את סיסמת הניהול וסולמית לסיום */
    M1800: 'M1800',
    /** אחד או יותר מהנתונים שהקשת שגוי */
    M1801: 'M1801',
    /** לצורך אימות מספר הטלפון שלכם, תקבלו כעת שיחה ממספר מסויים, יש לזכור את ארבעת הספרות האחרונות של המספר, ולהקיש אותם לאחר קבלת הצינתוק. */
    M1802: 'M1802',
    /** אנא הקישו את ארבעת הספרות האחרונות של מספר הטלפון שקיבלתם ממנו שיחה כעת */
    M1803: 'M1803',
    /** אחד או יותר מהנתונים שהוקשו שגויים */
    M1804: 'M1804',
    /** חלה שגיאה באימות מספר הטלפון */
    M1805: 'M1805',
    /** אימות מספר הטלפון בוצע בהצלחה */
    M1806: 'M1806',
    /** מספר החברים בקבוצה הוא */
    M1807: 'M1807',
    /** לשמיעת מספר הטלפון של מנהל הקבוצה הקישו 1, לבדיקה האם מספר מסויים חבר בקבוצה הקישו 2, לשמיעת כל המספרים החברים בקבוצה ברצף הקישו 3. */
    M1808: 'M1808',
    /** מנהל הקבוצה הוא: */
    M1809: 'M1809',
    /** מִסְפָּר הַטֶּלֶפוֹן שהוקש אֵינֶנּוּ תַּקִּין, אָנָּא נַסּוּ שֵׁנִית. */
    M1810: 'M1810',
    /** כבר קיים בקבוצה שלך. (משלים את מספר הטלפון XXX כבר קיים בקבוצה שלך) */
    M1811: 'M1811',
    /** כבר קיים בקבוצה שלך במצב חסום. */
    M1812: 'M1812',
    /** איננו קיים בקבוצה שלך */
    M1813: 'M1813',
    /** אנא הקישו את הסיסמה החדשה ולסיום הקישו סולמית. */
    M1814: 'M1814',
    /** הוצאתם מחדר הועידה */
    M1815: 'M1815',
    /** הנך מועבר לחדר הועידה */
    M1816: 'M1816',
    /** צליל כניסת משתתף לחדר הועידה (ברית מחדל שקט) */
    M1817: 'M1817',
    /** צליל יציאת משתתף מחדר הועידה (ברירת מחדל שקט) */
    M1818: 'M1818',
    /** כבר הקשתם בשיחה זו את הנתון הנוכחי,לא ניתן להכניס נתון זה שוב */
    M1819: 'M1819',
    /** אין סיסמה */
    M1820: 'M1820',
    /** אין מספר חנות או פרויקט */
    M1821: 'M1821',
    /** לא הוגדר תוקן מסוף */
    M1822: 'M1822',
    /** לא הוגדר כמות עמודים בפרק זה */
    M1823: 'M1823',
    /** הדף שיצא לך ללמוד הוא דף */
    M1824: 'M1824',
    /** עמוד */
    M1825: 'M1825',
    /** בפרק */
    M1826: 'M1826',
    /** לקבלת עמוד נוסף הקישו 1, לחזרה לתפריט הקישו 2 או המתינו */
    M1827: 'M1827',
    /** שם החלל לתפילה הוא */
    M1828: 'M1828',
    /** דולר ארהב */
    M1829: 'M1829',
    /** על פי רשומי המערכת נתון זה כבר עודכן בעבר, לא ניתן לעדכן נתון זה שוב, אנא עדכנו נתון חדש */
    M1830: 'M1830',
    /** הזמנת המוצר נקלטה ונשמרה עד לסיום השיחה */
    M1831: 'M1831',
    /** יש */
    M1832: 'M1832',
    /** הזמנות מאושרות שבוצעו מזיהוי זה */
    M1833: 'M1833',
    /** עסקה מאושרת מספר */
    M1834: 'M1834',
    /** אישור מספר */
    M1835: 'M1835',
    /** כמות הפריטים שהוזמנה */
    M1836: 'M1836',
    /** הסך הכולל ששולם */
    M1837: 'M1837',
    /** לשמיעה חוזרת הקישו 1. לשמיעת העיסקה הבאה הקישו 2 (מבוטל - לפירוט מלא של עיסקה זו הקישו 3), ליציאה הקישו כוכבית */
    M1838: 'M1838',
    /** אין הזמנות מאושרות ממספר זיהוי זה */
    M1839: 'M1839',
    /** סוף אישורים */
    M1840: 'M1840',
    /** אנא הקישו את מספר השלוחה וסולמית לסיום. למעבר לשלוחות הפנימיות הקישו את הכתובות המלאה, כאשר בין שלוחה לשלוחה הקישו כוכבית, בסיום כתובת השלוחה המלאה הקישו סולמית, ליציאה הקישו כוכבית וסולמית */
    M1841: 'M1841',
    /** לא הוגדר זמן להפעלת השידור */
    M1842: 'M1842',
    /** אין קובץ להפעלת השידור */
    M1843: 'M1843',
    /** השידור הסתיים */
    M1844: 'M1844',
    /** השידור הסתיים כעת בהצלחה */
    M1845: 'M1845',
    /** שגיאה בהפעלת השידור */
    M1846: 'M1846',
    /** השידור יחל בעוד... */
    M1847: 'M1847',
    /** להמתנה הקישו 1, לשידור חוזר מהשיעור האחרון הקישו 2 , ליציאה הקישו 3 או כוכבית */
    M1848: 'M1848',
    /** שעות */
    M1849: 'M1849',
    /** ו.. */
    M1850: 'M1850',
    /** דקות */
    M1851: 'M1851',
    /** קיבלתם הנחה של */
    M1852: 'M1852',
    /** הנכם מועברים לתשלום עבור הדמי משלוח */
    M1853: 'M1853',
    /** בשיחה טלפונית זו כבר סיימתם רכישת מוצרים בהצלחה, לרכישה נוספת אנא נתקו את השיחה וחייגו שוב. */
    M1854: 'M1854',
    /** הנכם מועברים להאזנה לשידור המוקלט */
    M1855: 'M1855',
    /** השעה אינה תקינה */
    M1856: 'M1856',
    /** התאריך אינו תקין */
    M1857: 'M1857',
    /** מספר תעודת הזהות שהקשתם אינו תקין אתם מועברים להקשה מחדש */
    M1858: 'M1858',
    /** על פי רשומי המערכת כבר הכנסת בעבר את הפרטים אותם הכנסת עכשיו, לא ניתן להמשיך, שלום ותודה */
    M1859: 'M1859',
    /** במודול זה מחושב הסכום אותו אתם צריכים לטעון בפועל בשביל שלאחר אחוזי התוספת תגיעו לסכום המופיע בחנות. התוספת הינה על סך */
    M1860: 'M1860',
    /** אחוזים */
    M1861: 'M1861',
    /** אנא הקישו את הסכום המלא לתשלום המופיע בחנות. לסימון נקודה הקישו כוכבית, לסיום הקישו סולמית. לדוגמא לסכום 35.90 שח הקישו : שלושים וחמש כוכבית תשעים וסולמית לסיום. ליציאה הקישו כוכבית וסולמית */
    M1862: 'M1862',
    /** לא הוגדרו אחוזים לחישוב */
    M1863: 'M1863',
    /** בקניה זו הנכם חוסכים */
    M1864: 'M1864',
    /** שקלים. */
    M1865: 'M1865',
    /** לרכישת מוצר זה, הסכום אותו תצטרכו לטעון בפועל בכרטיס הוא */
    M1866: 'M1866',
    /** כאשר לאחר תוספת של */
    M1867: 'M1867',
    /** אחוזים, יטען לכם בכרטיס סך של.. */
    M1868: 'M1868',
    /** להקשת סכום נוסף הקישו 1, להמשך הקישו 2 או כוכבית, לשמיעה חוזרת הקישו סולמית או המתינו */
    M1869: 'M1869',
    /** לבחירת המוצר אנא הקישו את הכמות */
    M1870: 'M1870',
    /** למעבר למוצר הבא הקישו כוכבית */
    M1871: 'M1871',
    /** למעבר לתשלום הקישו אפס */
    M1872: 'M1872',
    /** לחזרה הקישו כוכבית */
    M1873: 'M1873',
    /** בסיום הבחירה הקישו סולמית */
    M1874: 'M1874',
    /** לפירוט ההזמנה הקישו 3 */
    M1875: 'M1875',
    /** בחירת מסכת משניות ללימוד, נותרו */
    M1876: 'M1876',
    /** מסכתות, לסיום מחזור */
    M1877: 'M1877',
    /** של המשניות, למסכתות מסדר */
    M1878: 'M1878',
    /** אנא הקישו את מספר המסכת שבחרתם ללימוד */
    M1879: 'M1879',
    /** ליציאה הקישו כוכבית */
    M1880: 'M1880',
    /** סדר המשניות שהקשתם שגוי */
    M1881: 'M1881',
    /** כל המסכתות בסדר זה כבר נלקחו, אנא בחר מסכת מסדר אחר */
    M1882: 'M1882',
    /** לחזרה לתפריט בחירת סדר הקישו כוכבית וסולמית */
    M1883: 'M1883',
    /** המסכת שהקשתם שגויה אנא נסו שנית */
    M1884: 'M1884',
    /** מסכת זו כבר נלקחה , אנא נסה מסכת אחרת */
    M1885: 'M1885',
    /** אם ברצונכם לאשר את קבלת המסכת ללימוד הקישו 1 , לחזרה לתפריט הקישו 2 */
    M1886: 'M1886',
    /** תודה רבה. לקחתם ללימוד את.. */
    M1887: 'M1887',
    /** הרישום התבצע בהצלחה */
    M1888: 'M1888',
    /** לבחירת מסכת נוספת הקישו 1, לחזרה לתפריט הקישו 2 */
    M1889: 'M1889',
    /** חלוקת מסכתות ללימוד - צד ניהול . לקבלת הדוח המלא לאיימיל של כל הנרשמים הקישו 1 . לשמיעת פרטי הנרשמים הקישו 2 . לחזרה הקישו כוכבית */
    M1890: 'M1890',
    /** הכמות לא יכולה להיות גדולה מ */
    M1891: 'M1891',
    /** הכמות לא יכולה להיות קטנה מ */
    M1892: 'M1892',
    /** לשמיעת משניות מהקריין ר' צבי פלורנטל הקישו 1 או המתינו, לשמיעת משניות בניגון מהרב משה חבושה הקישו 2 , לשמיעת משניות מאת הרב גבריאל לרר זכרונו לברכה הקישו 3, לשמיעת משניות בניגון מהרב שלמה זילברמן הקישו 4 */
    M1893: 'M1893',
    /** לקבלת מסכת ללימוד הקישו 1, לשמיעת שיעורים על המסכתות הקישו 2, לחזרה למיקום אליו עצרתם בשמיעה האחרונה הקישו 3, לשמיעת המסכתות שלקחתם ועדכון על סיום לימוד מסכת הקישו 4 */
    M1894: 'M1894',
    /** לפרק הבא הקישו 8 לפרק הקודם הקישו 2 */
    M1895: 'M1895',
    /** לא נלקחו מסכתות ללימוד דרך זיהוי זה */
    M1896: 'M1896',
    /** לקחת */
    M1897: 'M1897',
    /** מסכתות משניות ללימוד */
    M1898: 'M1898',
    /** בחירה מספר */
    M1899: 'M1899',
    /** סוף התפריט - לחזרה הקישו סולמית */
    M1900: 'M1900',
    /** מסכת */
    M1901: 'M1901',
    /** במחזור לימוד מספר */
    M1902: 'M1902',
    /** סוף מסכתות משניות שלקחת */
    M1903: 'M1903',
    /** כבר עדכנת שסיימת את הלימוד במסכת זו. תודה רבה. */
    M1904: 'M1904',
    /** עדיין לא עדכנת שסיימת את הלימוד במסכת זו, אם ברצונך לעדכן עכשיו כי סיימת, הקש 1 . אחרת הקש 2 או המתן */
    M1905: 'M1905',
    /** עדכון הלימוד הסתיים בהצלחה. תודה רבה */
    M1906: 'M1906',
    /** שקלים. */
    M1907: 'M1907',
    /** ו.. */
    M1908: 'M1908',
    /** אגורות */
    M1909: 'M1909',
    /** מספר הטלפון שהוקש אינו תקין אנא נסו שנית */
    M1910: 'M1910',
    /** ברכות */
    M1911: 'M1911',
    /** שבת */
    M1912: 'M1912',
    /** עירובין */
    M1913: 'M1913',
    /** פסחים */
    M1914: 'M1914',
    /** יומא */
    M1915: 'M1915',
    /** סוכה */
    M1916: 'M1916',
    /** שקלים */
    M1917: 'M1917',
    /** ביצה */
    M1921: 'M1921',
    /** ראש השנה */
    M1922: 'M1922',
    /** תענית */
    M1923: 'M1923',
    /** מגילה */
    M1924: 'M1924',
    /** מועד קטן */
    M1925: 'M1925',
    /** חגיגה */
    M1926: 'M1926',
    /** יבמות */
    M1931: 'M1931',
    /** כתובות */
    M1932: 'M1932',
    /** נדרים */
    M1933: 'M1933',
    /** נזיר */
    M1934: 'M1934',
    /** סוטה */
    M1935: 'M1935',
    /** גיטין */
    M1936: 'M1936',
    /** קידושין */
    M1937: 'M1937',
    /** בבא קמא */
    M1941: 'M1941',
    /** בבא מציעא */
    M1942: 'M1942',
    /** בבא בתרא */
    M1943: 'M1943',
    /** סנהדרין */
    M1944: 'M1944',
    /** מכות */
    M1945: 'M1945',
    /** שבועות */
    M1946: 'M1946',
    /** עבודה זרה */
    M1947: 'M1947',
    /** הוריות */
    M1948: 'M1948',
    /** תמיד */
    M1950: 'M1950',
    /** זבחים */
    M1951: 'M1951',
    /** מנחות */
    M1952: 'M1952',
    /** חולין */
    M1953: 'M1953',
    /** בכורות */
    M1954: 'M1954',
    /** ערכין */
    M1955: 'M1955',
    /** תמורה */
    M1956: 'M1956',
    /** כריתות */
    M1957: 'M1957',
    /** מעילה */
    M1958: 'M1958',
    /** קנים */
    M1959: 'M1959',
    /** מידות */
    M1960: 'M1960',
    /** נידה */
    M1961: 'M1961',
    /** ההגדרות לא הושלמו */
    M1962: 'M1962',
    /** חדר הוועידה פעיל כרגע */
    M1963: 'M1963',
    /** אנא הקישו את המיספר שאליו ברצונכם לשלוח את הודעה */
    M1964: 'M1964',
    /** בשלב זה לא ניתן לשלוח למיספר שהקשתם, אנא נסו מאוחר יותר */
    M1965: 'M1965',
    /** לאחר הצליל אנא אמרו את ההודעה שברצונכם לשלוח */
    M1966: 'M1966',
    /** להלן ההודעה שנקלטה */
    M1967: 'M1967',
    /** לשמיעה חוזרת הקישו 1, לשליחת ההודעה הקישו 2, להקלטה מחדש הקישו 3, לביטול ויְצִיאָה הקישו 4. */
    M1968: 'M1968',
    /** ההודעה נשלחה בהצלחה */
    M1969: 'M1969',
    /** לצערנו ההודעה לא נשלחה, אנא נסו שנית מאוחר יותר */
    M1970: 'M1970',
    /** שימו לב ! מספר הטלפון שאליו נשלחת ההודעה, עדיין לא קיבל הודעות מכם דרך שירות זה, ולכן, כדי שיוכל להשיב לכם הודעה, אנו נשלח לו הודעת הסבר, איך יוכל להשיב לכם הודעה. לא תחוייבו עבור שליחת הודעת ההסבר. הודעת ההסבר שתישלח אליו היא: */
    M1971: 'M1971',
    /** לאישור הקישו 1, לשליחת ההודעה ללא הודעת ההסבר, הקישו 2. */
    M1972: 'M1972',
    /** אנא המתינו מספר שניות לאישור שליחת ההודעה */
    M1973: 'M1973',
    /** לא הוגדר מספר עסק */
    M1974: 'M1974',
    /** אין קובץ רשימת עסקים */
    M1975: 'M1975',
    /** אנא הקישו את הסכום בשקלים מלאים אותו שילמת, להזכירך ניתן להזין רק מה שכבר שולם ולא תשלום עתידי, הכל בכפוף לתקנון, לדוגמא במידה ושילמתם תשעים ותשע וחצי ₪ הקישו 99 וסולמית */
    M1976: 'M1976',
    /** לדירוג בעל המקצוע הקישו 1 או המתינו, לדילוג הקש 2 */
    M1977: 'M1977',
    /** עסק לא מופיע ברשימה */
    M1978: 'M1978',
    /** חלה שגיאה בבדיקת תוקף המפתח שלך, אנא פנה למנהל המערכת */
    M1979: 'M1979',
    /** אישור הכניסה של המפתח שלך פג תוקף, לפרטים אנא פנה למנהל המערכת */
    M1980: 'M1980',
    /** הערך גבוה מידי */
    M1981: 'M1981',
    /** הערך נמוך מידי */
    M1982: 'M1982',
    /** לצורך שידור לחברת הסליקה , אנא הקליטו את השם של בעל הכרטיס וסולמית לסיום */
    M1983: 'M1983',
    /** הוספתם את הטלפון שלכם לרשימות התפוצה שמספרם, 1,2,3 */
    M1984: 'M1984',
    /** לא ניתן לצרף את הטלפון שלכם לרשימת תפוצה, X */
    M1985: 'M1985',
    /** הסרתם את הטלפון שלכם מרשימות התפוצה שמספרם, 1,2,3 */
    M1986: 'M1986',
    /** לא ניתן להסיר את הטלפון שלכם מרשימת תפוצה, X */
    M1987: 'M1987',
    /** אנא הקליטו את הכתובת שלכם, עיר רחוב ומספר בית, ובסיום הקישו סולמית */
    M1988: 'M1988',
    /** האות שהקשת אינו קיים */
    M1989: 'M1989',
    /** מוזיקת רקע - כל זמן שהנשמה בקרבי , RecordMix */
    M1990: 'M1990',
    /** לקבלת דוח נוכחות למייל הקישו 1, ליציאה הקישו כוכבית */
    M1991: 'M1991',
    /** אימייל דוח נוכחות נשלח בהצלחה */
    M1992: 'M1992',
    /** אנא הקש את מספר הזיהוי של הנמען וסולמית לסיום */
    M1993: 'M1993',
    /** לשמיעת התהילים בנוסח ספרד הקישו 1 או המתינו, לשמיעת התהילים בנוסח אשכנז הקישו 2 */
    M1994: 'M1994',
    /** חדר הוועידה פעיל כרגע */
    M1995: 'M1995',
    /** המספר שהוקש הוא */
    M1996: 'M1996',
    /** הספר שקיבלת מתוך חמשת הספרים הינו ספר */
    M1997: 'M1997',
    /** תזכו למצוות */
    M1998: 'M1998',
    /** לקבלת ספר נוסף לקריאה הקישו 1 */
    M1999: 'M1999',
    /** תהילים הקדמה */
    M2000: 'M2000',
    /** תהילים אשכנז 1 */
    M2001: 'M2001',
    /** תהילים אשכנז 2 */
    M2002: 'M2002',
    /** תהילים אשכנז 3 */
    M2003: 'M2003',
    /** תהילים אשכנז 4 */
    M2004: 'M2004',
    /** תהילים אשכנז 5 */
    M2005: 'M2005',
    /** תהילים אשכנז 6 */
    M2006: 'M2006',
    /** תהילים אשכנז 7 */
    M2007: 'M2007',
    /** תהילים אשכנז 8 */
    M2008: 'M2008',
    /** תהילים אשכנז 9 */
    M2009: 'M2009',
    /** תהילים אשכנז 10 */
    M2010: 'M2010',
    /** תהילים אשכנז 11 */
    M2011: 'M2011',
    /** תהילים אשכנז 12 */
    M2012: 'M2012',
    /** תהילים אשכנז 13 */
    M2013: 'M2013',
    /** תהילים אשכנז 14 */
    M2014: 'M2014',
    /** תהילים אשכנז 15 */
    M2015: 'M2015',
    /** תהילים אשכנז 16 */
    M2016: 'M2016',
    /** תהילים אשכנז 17 */
    M2017: 'M2017',
    /** תהילים אשכנז 18 */
    M2018: 'M2018',
    /** תהילים אשכנז 19 */
    M2019: 'M2019',
    /** תהילים אשכנז 20 */
    M2020: 'M2020',
    /** תהילים אשכנז 21 */
    M2021: 'M2021',
    /** תהילים אשכנז 22 */
    M2022: 'M2022',
    /** תהילים אשכנז 23 */
    M2023: 'M2023',
    /** תהילים אשכנז 24 */
    M2024: 'M2024',
    /** תהילים אשכנז 25 */
    M2025: 'M2025',
    /** תהילים אשכנז 26 */
    M2026: 'M2026',
    /** תהילים אשכנז 27 */
    M2027: 'M2027',
    /** תהילים אשכנז 28 */
    M2028: 'M2028',
    /** תהילים אשכנז 29 */
    M2029: 'M2029',
    /** תהילים אשכנז 30 */
    M2030: 'M2030',
    /** תהילים אשכנז 31 */
    M2031: 'M2031',
    /** תהילים אשכנז 32 */
    M2032: 'M2032',
    /** תהילים אשכנז 33 */
    M2033: 'M2033',
    /** תהילים אשכנז 34 */
    M2034: 'M2034',
    /** תהילים אשכנז 35 */
    M2035: 'M2035',
    /** תהילים אשכנז 36 */
    M2036: 'M2036',
    /** תהילים אשכנז 37 */
    M2037: 'M2037',
    /** תהילים אשכנז 38 */
    M2038: 'M2038',
    /** תהילים אשכנז 39 */
    M2039: 'M2039',
    /** תהילים אשכנז 40 */
    M2040: 'M2040',
    /** תהילים אשכנז 41 */
    M2041: 'M2041',
    /** תהילים אשכנז 42 */
    M2042: 'M2042',
    /** תהילים אשכנז 43 */
    M2043: 'M2043',
    /** תהילים אשכנז 44 */
    M2044: 'M2044',
    /** תהילים אשכנז 45 */
    M2045: 'M2045',
    /** תהילים אשכנז 46 */
    M2046: 'M2046',
    /** תהילים אשכנז 47 */
    M2047: 'M2047',
    /** תהילים אשכנז 48 */
    M2048: 'M2048',
    /** תהילים אשכנז 49 */
    M2049: 'M2049',
    /** תהילים אשכנז 50 */
    M2050: 'M2050',
    /** תהילים אשכנז 51 */
    M2051: 'M2051',
    /** תהילים אשכנז 52 */
    M2052: 'M2052',
    /** תהילים אשכנז 53 */
    M2053: 'M2053',
    /** תהילים אשכנז 54 */
    M2054: 'M2054',
    /** תהילים אשכנז 55 */
    M2055: 'M2055',
    /** תהילים אשכנז 56 */
    M2056: 'M2056',
    /** תהילים אשכנז 57 */
    M2057: 'M2057',
    /** תהילים אשכנז 58 */
    M2058: 'M2058',
    /** תהילים אשכנז 59 */
    M2059: 'M2059',
    /** תהילים אשכנז 60 */
    M2060: 'M2060',
    /** תהילים אשכנז 61 */
    M2061: 'M2061',
    /** תהילים אשכנז 62 */
    M2062: 'M2062',
    /** תהילים אשכנז 63 */
    M2063: 'M2063',
    /** תהילים אשכנז 64 */
    M2064: 'M2064',
    /** תהילים אשכנז 65 */
    M2065: 'M2065',
    /** תהילים אשכנז 66 */
    M2066: 'M2066',
    /** תהילים אשכנז 67 */
    M2067: 'M2067',
    /** תהילים אשכנז 68 */
    M2068: 'M2068',
    /** תהילים אשכנז 69 */
    M2069: 'M2069',
    /** תהילים אשכנז 70 */
    M2070: 'M2070',
    /** תהילים אשכנז 71 */
    M2071: 'M2071',
    /** תהילים אשכנז 72 */
    M2072: 'M2072',
    /** תהילים אשכנז 73 */
    M2073: 'M2073',
    /** תהילים אשכנז 74 */
    M2074: 'M2074',
    /** תהילים אשכנז 75 */
    M2075: 'M2075',
    /** תהילים אשכנז 76 */
    M2076: 'M2076',
    /** תהילים אשכנז 77 */
    M2077: 'M2077',
    /** תהילים אשכנז 78 */
    M2078: 'M2078',
    /** תהילים אשכנז 79 */
    M2079: 'M2079',
    /** תהילים אשכנז 80 */
    M2080: 'M2080',
    /** תהילים אשכנז 81 */
    M2081: 'M2081',
    /** תהילים אשכנז 82 */
    M2082: 'M2082',
    /** תהילים אשכנז 83 */
    M2083: 'M2083',
    /** תהילים אשכנז 84 */
    M2084: 'M2084',
    /** תהילים אשכנז 85 */
    M2085: 'M2085',
    /** תהילים אשכנז 86 */
    M2086: 'M2086',
    /** תהילים אשכנז 87 */
    M2087: 'M2087',
    /** תהילים אשכנז 88 */
    M2088: 'M2088',
    /** תהילים אשכנז 89 */
    M2089: 'M2089',
    /** תהילים אשכנז 90 */
    M2090: 'M2090',
    /** תהילים אשכנז 91 */
    M2091: 'M2091',
    /** תהילים אשכנז 92 */
    M2092: 'M2092',
    /** תהילים אשכנז 93 */
    M2093: 'M2093',
    /** תהילים אשכנז 94 */
    M2094: 'M2094',
    /** תהילים אשכנז 95 */
    M2095: 'M2095',
    /** תהילים אשכנז 96 */
    M2096: 'M2096',
    /** תהילים אשכנז 97 */
    M2097: 'M2097',
    /** תהילים אשכנז 98 */
    M2098: 'M2098',
    /** תהילים אשכנז 99 */
    M2099: 'M2099',
    /** תהילים אשכנז 100 */
    M2100: 'M2100',
    /** תהילים אשכנז 101 */
    M2101: 'M2101',
    /** תהילים אשכנז 102 */
    M2102: 'M2102',
    /** תהילים אשכנז 103 */
    M2103: 'M2103',
    /** תהילים אשכנז 104 */
    M2104: 'M2104',
    /** תהילים אשכנז 105 */
    M2105: 'M2105',
    /** תהילים אשכנז 106 */
    M2106: 'M2106',
    /** תהילים אשכנז 107 */
    M2107: 'M2107',
    /** תהילים אשכנז 108 */
    M2108: 'M2108',
    /** תהילים אשכנז 109 */
    M2109: 'M2109',
    /** תהילים אשכנז 110 */
    M2110: 'M2110',
    /** תהילים אשכנז 111 */
    M2111: 'M2111',
    /** תהילים אשכנז 112 */
    M2112: 'M2112',
    /** תהילים אשכנז 113 */
    M2113: 'M2113',
    /** תהילים אשכנז 114 */
    M2114: 'M2114',
    /** תהילים אשכנז 115 */
    M2115: 'M2115',
    /** תהילים אשכנז 116 */
    M2116: 'M2116',
    /** תהילים אשכנז 117 */
    M2117: 'M2117',
    /** תהילים אשכנז 118 */
    M2118: 'M2118',
    /** תהילים אשכנז 119 */
    M2119: 'M2119',
    /** תהילים אשכנז 120 */
    M2120: 'M2120',
    /** תהילים אשכנז 121 */
    M2121: 'M2121',
    /** תהילים אשכנז 122 */
    M2122: 'M2122',
    /** תהילים אשכנז 123 */
    M2123: 'M2123',
    /** תהילים אשכנז 124 */
    M2124: 'M2124',
    /** תהילים אשכנז 125 */
    M2125: 'M2125',
    /** תהילים אשכנז 126 */
    M2126: 'M2126',
    /** תהילים אשכנז 127 */
    M2127: 'M2127',
    /** תהילים אשכנז 128 */
    M2128: 'M2128',
    /** תהילים אשכנז 129 */
    M2129: 'M2129',
    /** תהילים אשכנז 130 */
    M2130: 'M2130',
    /** תהילים אשכנז 131 */
    M2131: 'M2131',
    /** תהילים אשכנז 132 */
    M2132: 'M2132',
    /** תהילים אשכנז 133 */
    M2133: 'M2133',
    /** תהילים אשכנז 134 */
    M2134: 'M2134',
    /** תהילים אשכנז 135 */
    M2135: 'M2135',
    /** תהילים אשכנז 136 */
    M2136: 'M2136',
    /** תהילים אשכנז 137 */
    M2137: 'M2137',
    /** תהילים אשכנז 138 */
    M2138: 'M2138',
    /** תהילים אשכנז 139 */
    M2139: 'M2139',
    /** תהילים אשכנז 140 */
    M2140: 'M2140',
    /** תהילים אשכנז 141 */
    M2141: 'M2141',
    /** תהילים אשכנז 142 */
    M2142: 'M2142',
    /** תהילים אשכנז 143 */
    M2143: 'M2143',
    /** תהילים אשכנז 144 */
    M2144: 'M2144',
    /** תהילים אשכנז 145 */
    M2145: 'M2145',
    /** תהילים אשכנז 146 */
    M2146: 'M2146',
    /** תהילים אשכנז 147 */
    M2147: 'M2147',
    /** תהילים אשכנז 148 */
    M2148: 'M2148',
    /** תהילים אשכנז 149 */
    M2149: 'M2149',
    /** תהילים אשכנז 150 */
    M2150: 'M2150',
    /** לקבלת מספר אישי למערכת זו, עבורכם, או עבור טלפון אחר, הקישו 1. לקבלת מספר אישי ממערכת אחרת בימות המשיח, הקישו 2. לדיווח על מספר שנחסם, הקישו 3 */
    M2151: 'M2151',
    /** אנא הקישו את מספר המערכת בימות המשיח, שברצונכם לקבל עבורה מספר אישי, ובסיום הַקישו סולמית */
    M2152: 'M2152',
    /** לצערנו המִסְפָּר שהוקש, חסום לקבלת צינתוקים ממערכת זו, ולכן לא נִיתַן לשלוח לו מספר אישי. להסרת החסימה, יש לפנות למנהל המערכת */
    M2153: 'M2153',
    /** הפקס נשלח בהצלחה */
    M2154: 'M2154',
    /** אנא הקישו את המִסְפָּר שאליו ברצונכם לשלוח את הפקס ובסיום הַקִּישו סולמית */
    M2155: 'M2155',
    /** לצערנו, קיימת שגיאה בשליחת הפקס. פרטי השגיאה הם */
    M2156: 'M2156',
    /** לצערנו, לא ניתַן לשלוח את הפקס, מפני שלא מוגדר מספר טלפון לשליחה */
    M2157: 'M2157',
    /** נבחר מספר שגוי */
    M2158: 'M2158',
    /** לדיווח על */
    M2159: 'M2159',
    /** משימתך היא */
    M2160: 'M2160',
    /** לאישור ביצוע המשימה הקש 1, לחזרה הקש כוכבית */
    M2161: 'M2161',
    /** אישור ביצוע המשימה התקבל בהצלחה */
    M2162: 'M2162',
    /** המשימות שעדיין לא בוצעו הן */
    M2163: 'M2163',
    /** מספר זה כבר דיווח היום על ביצוע המשימה */
    M2164: 'M2164',
    /** למספר זה לא הוקצו משימות */
    M2165: 'M2165',
    /** בקשתך לקבלת הדוח התקבלה */
    M2166: 'M2166',
    /** הקובץ אינו קיים */
    M2167: 'M2167',
    /** לצערנו, לא ניתַן לשלוח את הפקס, מפני שאין קובץ תקין לשליחה */
    M2168: 'M2168',
    /** בקשתך התקבלה. בדקות הקרובות תצא תזכורת לרשימת האנשים ברשימה שטרם ביצעו את משימתם */
    M2169: 'M2169',
    /** אנא הקישו את הכמות שברצונכם להזמין */
    M2170: 'M2170',
    /** הכמות נשמרה עד לסיום ההזמנה. שימו לב, אם תנתקו לפני סיום ההזמנה, הכמות לא תישמר לכם */
    M2171: 'M2171',
    /** הכמות שנבחרה גדולה מהכמות הפנויה */
    M2172: 'M2172',
    /** אין כמות פנויה */
    M2173: 'M2173',
    /** להזמנה, הקישו 1, לביטול הזמנה קודמת הקישו 2, ליציאה הקישו 3. */
    M2174: 'M2174',
    /** אנא הקישו את מספר ההזמנה שברצונכם לבטל */
    M2175: 'M2175',
    /** האם אתם בטוחים שברצונכם לבטל את ההזמנה? לביטול ההזמנה, הקישו1, ליציאה ללא שינוי, הקישו 2. */
    M2176: 'M2176',
    /** מספר ההזמנה שהוקש אינו תואם למספר הטלפון שביצע את ההזמנה. לביטול הזמנה, יש לחייג ממספר הטלפון שביצע את ההזמנה. */
    M2177: 'M2177',
    /** ההזמנה בוטלה בהצלחה */
    M2178: 'M2178',
    /** הכמות הפנויה להזמנה כעת היא */
    M2179: 'M2179',
    /** הזמנה זו כבר בוטלה */
    M2180: 'M2180',
    /** אנא הקישו את מספר המערכת או הקבוצה שנחסם, ובסיום, הַקישו סולמית */
    M2181: 'M2181',
    /** שימו לב, בשליחת דיווח, הנכם מאשרים קבלת צינתוקים ו\או שיחות מאיתנו, על מנת לעדכן אתכם במספר חדש */
    M2182: 'M2182',
    /** לאישור, הקישו 1. לביטול ויְצִיאָה, הקישו 2, או הַמְתינו. */
    M2183: 'M2183',
    /** אנא בחרו את חברת התקשורת של הפלאפון שלכם שעבורו נחסם המספר. לפלאפון, הקישו 1. לסלקום, הקישו 2. לפרטנר אורנג', הקישו 3. לגולן טלקום, הקישו 4. להוט מובייל או מירס, הקישו 5. לרמי לוי, הקישו 6. לבזק, הקישו 7. לנטויז'ן, הקישו 8, לחברות אחרות, או אם לא ידוע לכם לאיזה חברת תקשורת משוייך המכשיר שלכם, הקישו 9, או המתינו. */
    M2184: 'M2184',
    /** הדיווח התקבל בהצלחה */
    M2185: 'M2185',
    /** הקלטת הודעות מערכת */
    M2186: 'M2186',
    /** אנא הקישו את שלוחת היעד וסולמית לסיום, לשלוחה פנימיות הקישו את הכתובת המלאה כאשר בין שלוחה לשלוחה הקישו כוכבית ולסיום הכתובת המלאה הקישו סולמית, לדוגמא לשלוחה אחת בתוך שלוחה אחת בתוך שלוחה שלוש הקישו שלוש כוכבית אחת כוכבית שלוש וסולמית לשלוחת הודעות ברירת המחדל הקישו כוכבית כוכבית וסולמית. */
    M2187: 'M2187',
    /** שימו לב. ההקלטה בשלוחה זו תחליף את כל המקומות במערכת בהם מושמעת הודעה זו, אלא אם כן תשימו הודעה מיוחדת בתוך השלוחה הספציפית. לאישור והמשך הקישו 1, לביטול וחזרה הקישו 2 */
    M2188: 'M2188',
    /** אנא הקישו את מספר הודעת מערכת ב4 ספרות. לחזרה לתפריט הקודם הקישו כוכבית וסולמית */
    M2189: 'M2189',
    /** אנא הקליטו את ההודעה המיוחדת שלכם לאחר הצליל ובסיום הקישו סולמית */
    M2190: 'M2190',
    /** ההקלטה מבוטלת */
    M2191: 'M2191',
    /** שלוחה ראשית */
    M2192: 'M2192',
    /** שלוחת הודעות ברירת מחדל */
    M2193: 'M2193',
    /** יצרתם בהצלחה הודעת מערכת בשלוחה... */
    M2194: 'M2194',
    /** הודעה מספר */
    M2195: 'M2195',
    /** אנא הקליטו המשך הודעתכם לאחר הצליל ובסיום הקישו סולמית */
    M2196: 'M2196',
    /** לפי הרישומים אצלנו, מסומן שדיווחתם על מספר שנחסם או שקיבלתם או שלחתם לחבר מספר אישי בשעה זו,  ולכן אין לכם אפשרות לדווח או לקבל או לשלוח שוב מספר אישי כעת, אנא נסו שוב בעוד שעה. */
    M2197: 'M2197',
    /** המערכת מזהה כי כבר נרשמתם לא ניתן להירשם בשנית שלום ותודה */
    M2198: 'M2198',
    /** שימו לב חלוקת המשניות הינה אוטומטית והינכם מתחייבים לאמרו */
    M2199: 'M2199',
    /** השיעורים באדיבות מפעל קביעותא. ללימוד המשנה וההלכה היומית ובאדיבות מפעל המשניות */
    M2200: 'M2200',
    /** סדר זרעים ברכות */
    M2201: 'M2201',
    /** סדר זרעים פאה */
    M2202: 'M2202',
    /** סדר זרעים דמאי */
    M2203: 'M2203',
    /** סדר זרעים כלאים */
    M2204: 'M2204',
    /** סדר זרעים שביעית */
    M2205: 'M2205',
    /** סדר זרעים תרומות */
    M2206: 'M2206',
    /** סדר זרעים מעשרות */
    M2207: 'M2207',
    /** סדר זרעים מעשר שני */
    M2208: 'M2208',
    /** סדר זרעים חלה */
    M2209: 'M2209',
    /** סדר זרעים ערלה */
    M2210: 'M2210',
    /** סדר זרעים בכורים */
    M2211: 'M2211',
    /** סדר מועד שבת */
    M2212: 'M2212',
    /** סדר מועד עירובין */
    M2213: 'M2213',
    /** סדר מועד פסחים */
    M2214: 'M2214',
    /** סדר מועד שקלים */
    M2215: 'M2215',
    /** סדר מועד יומא */
    M2216: 'M2216',
    /** סדר מועד סוכה */
    M2217: 'M2217',
    /** סדר מועד ביצה */
    M2218: 'M2218',
    /** סדר מועד ראש השנה */
    M2219: 'M2219',
    /** סדר מועד תענית */
    M2220: 'M2220',
    /** סדר מועד מגילה */
    M2221: 'M2221',
    /** סדר מועד מועד קטן */
    M2222: 'M2222',
    /** סדר מועד חגיגה */
    M2223: 'M2223',
    /** סדר נשים יבמות */
    M2224: 'M2224',
    /** סדר נשים כתובות */
    M2225: 'M2225',
    /** סדר נשים נדרים */
    M2226: 'M2226',
    /** סדר נשים נזיר */
    M2227: 'M2227',
    /** סדר נשים סוטה */
    M2228: 'M2228',
    /** סדר נשים גיטין */
    M2229: 'M2229',
    /** סדר נשים קידושין */
    M2230: 'M2230',
    /** סדר נזיקין בבא קמא */
    M2231: 'M2231',
    /** סדר נזיקין בבא מציעא */
    M2232: 'M2232',
    /** סדר נזיקין בבא בתרא */
    M2233: 'M2233',
    /** סדר נזיקין סנהדרין */
    M2234: 'M2234',
    /** סדר נזיקין מכות */
    M2235: 'M2235',
    /** סדר נזיקין שבועות */
    M2236: 'M2236',
    /** סדר נזיקין עדיות */
    M2237: 'M2237',
    /** סדר נזיקין עבודה זרה */
    M2238: 'M2238',
    /** סדר נזיקין אבות** */
    M2239: 'M2239',
    /** סדר נזיקין הוריות */
    M2240: 'M2240',
    /** סדר קדשים זבחים */
    M2241: 'M2241',
    /** סדר קדשים מנחות */
    M2242: 'M2242',
    /** סדר קדשים חולין */
    M2243: 'M2243',
    /** סדר קדשים בכורות */
    M2244: 'M2244',
    /** סדר קדשים ערכין */
    M2245: 'M2245',
    /** סדר קדשים תמורה */
    M2246: 'M2246',
    /** סדר קדשים כריתות */
    M2247: 'M2247',
    /** סדר קדשים מעילה */
    M2248: 'M2248',
    /** סדר קדשים תמיד* */
    M2249: 'M2249',
    /** סדר קדשים מדות* */
    M2250: 'M2250',
    /** סדר קדשים קנים* */
    M2251: 'M2251',
    /** סדר טהרות כלים (חלק א) (א-טו) */
    M2252: 'M2252',
    /** סדר טהרות כלים (חלק ב) (טז - ל) */
    M2253: 'M2253',
    /** סדר טהרות אוהלות */
    M2254: 'M2254',
    /** סדר טהרות נגעים */
    M2255: 'M2255',
    /** סדר טהרות פרה */
    M2256: 'M2256',
    /** סדר טהרות טהרות */
    M2257: 'M2257',
    /** סדר טהרות מקואות */
    M2258: 'M2258',
    /** סדר טהרות נדה */
    M2259: 'M2259',
    /** סדר טהרות מכשירין */
    M2260: 'M2260',
    /** סדר טהרות זבים */
    M2261: 'M2261',
    /** סדר טהרות טבול יום */
    M2262: 'M2262',
    /** סדר טהרות ידים */
    M2263: 'M2263',
    /** סדר טהרות עוקצים */
    M2264: 'M2264',
    /** בחלוקת מסכתות משניות זו, הושלמו עד כה */
    M2265: 'M2265',
    /** סדרי חלוקת מסכתות משניות */
    M2266: 'M2266',
    /** המסכת אותה קיבלתם לומר היא */
    M2267: 'M2267',
    /** לקבלת מסכת נוספת הקישו 1, לחזרה לתפריט הקישו 2 */
    M2268: 'M2268',
    /** בחלוקת פרקי משניות זו, הושלמו עד כה */
    M2269: 'M2269',
    /** סדרי חלוקת פרקי משניות */
    M2270: 'M2270',
    /** פרק המשניות אותו קיבלתם ללמוד */
    M2271: 'M2271',
    /** פרק.. */
    M2272: 'M2272',
    /** לקבלת פרק משניות נוסף הקישו 1, לחזרה לתפריט הקישו 2 */
    M2273: 'M2273',
    /** לאישור התקנון וכניסה למבצע, הקישו 1, לשמיעת התקנון, הקישו 2 */
    M2274: 'M2274',
    /** אישרתם בהצלחה את תקנון המבצע */
    M2275: 'M2275',
    /** תקנון המבצע */
    M2276: 'M2276',
    /** כפי שהושמע בתקנון , ההישתתפות במבצע כרוכה בשני שלבים. 1, שליחת המלצה לחבר להאזין לפורטל התוכן, 2, חזרה של החבר למספר שקיבל משליחת ההמלצה. אם ברצונכם לשלוח המלצה, הקישו 1, אם כעת חזרתם למספר שחבר המליץ לכם עליו, הקישו 2. אם ברצונכם לשמוע את כמות הכרטיסים שצברתם עד כה, הקישו 3. */
    M2277: 'M2277',
    /** כעת, לאחר שחברך יחזור למספר ששלחת לו, ויאשר את תקנון המבצע, תקבלו שניכם כרטיס הגרלה, כל אחד */
    M2278: 'M2278',
    /** שים לב, יש להתקשר למערכת דרך המספר שהומלץ לך. */
    M2279: 'M2279',
    /** כמות כרטיסי ההגרלה שצברת היא */
    M2280: 'M2280',
    /** כל הכבוד ! זכית בכרטיס הגרלה עבורך ועבור חברך. */
    M2281: 'M2281',
    /** כדי לצבור כרטיס נוסף, המלץ לחבר על המערכת */
    M2282: 'M2282',
    /** הגדרת שפת מקלדת. לעברית הקישו 1, לאנגלית הקישו 2, להקלדת איימיל הקישו 3, להקלדת ספרות הקישו 4 */
    M2283: 'M2283',
    /** אנא הקישו את האות הבאה ולאחריה סולמית. לשינוי שפת הקלדה, לסיום ההקשות , לביטול הקשה אחרונה או לביטול כלל ההקשות הקישו כוכבית וסולמית */
    M2284: 'M2284',
    /** אנא הקישו את האות ולאחריה סולמית. לשינוי שפת הקלדה או לביטול ויציאה הקישו כוכבית וסולמית */
    M2285: 'M2285',
    /** תפריט סיום או ביטול. לשינוי שפת מקלדת הקישו 6, לסיום ההקלדה הקישו 1, לשמיעת הטקסט שהוקלד הקישו 2, לביטול של האות האחרונה הקישו 3, לביטול והקלדה מחודשת של כל הטקסט הקישו 4, ליציאה הקישו 5 */
    M2286: 'M2286',
    /** הביטול התקבל בהצלחה */
    M2287: 'M2287',
    /** הטקסט המעודכן הוא */
    M2288: 'M2288',
    /** הטקסט שהוקלד הוא */
    M2289: 'M2289',
    /** לאישור סיום הקלדה הקישו 1. לשמיעת הטקסט שהוקלד במילים או באותיות 2, להקשה מחודשת של כל הטקסט הקישו 3. */
    M2290: 'M2290',
    /** לשמוע את הטקסט שהוקלד אות אחר אות הקישו 1 או המתינו,  לשמוע את הטקסט שהוקלד באמצעות מנוע השמעת מילים הקישו 2 */
    M2291: 'M2291',
    /** לסיפרה עצמה הקישו 5 פעמים על הספרה וסולמית. לרווח הקישו 0 וסולמית. לפלוס הקישו 00 וסולמית. למינוס או מקף אמצעי הקישו 000 וסולמית. לשטורדל הקישו 0000 וסולמית. לנקודה הקישו 1 וסולמית. לסימן שאלה הקישו 11 וסולמית. לסימן קריאה הקישו 111 וסולמית. לפסיק הקישו 1111 וסולמית. לאות א הקישו 3 וסולמית. לאות ב הקישו 33 וסולמית. לאות ג הקישו 333 וסולמית. לאות ד הקישו 2 וסולמית. לאות ה הקישו 22 וסולמית. לאות ו הקישו 222 סולמית,. לאות ז הקישו 6 וסולמית. לאות ח הקישו 66 וסולמית. לאות ט הקישו 666 וסולמית. לאות י הקישו 5 וסולמית. לאות כ הקישו 55 וסולמית. לאות ך הקישו 555 וסולמית. לאות ל הקישו 5555 וסולמית. לאות מ הקישו 4 וסולמית. לאות ם הקישו 44 וסולמית. לאות נ הקישו 444 וסולמית. לאות ן הקישו 4444 וסולמית. לאות ס הקישו 9 וסולמית. לאות ע הקישו 99 וסולמית. לאות פ הקישו 999 וסולמית. לאות ף הקישו 9999 וסולמית. לאות צ הקישו 8 וסולמית. לאות ץ הקישו 88 וסולמית. לאות ק הקישו 888 וסולמית. לאות ר הקישו 7 וסולמית. לאות ש הקישו 77 וסולמית. לאות ת הקישו 777 וסולמית */
    M2292: 'M2292',
    /** לסיפרה עצמה הקישו 5 פעמים על הספרה וסולמית. לרווח הקישו 0 וסולמית. לפלוס הקישו 00 וסולמית. למינוס או מקף אמצעי הקישו 000 וסולמית. לשטורדל הקישו 0000 וסולמית. לנקודה הקישו 1 וסולמית. לסימן שאלה הקישו 11 וסולמית. לסימן קריאה הקישו 111 וסולמית. לפסיק הקישו 1111 וסולמית. לאות A הקישו 2 וסולמית. לאות B הקישו 22 וסולמית. לאות C הקישו 222 סולמית. לאות D הקישו 3 וסולמית. לאות E הקישו 33 וסולמית. לאות F הקישו 333 וסולמית. לאות G הקישו 4 וסולמית. לאות H הקישו 44 וסולמית. לאות I הקישו 444 וסולמית. לאות J הקישו 5 וסולמית. לאות K הקישו 55 וסולמית. לאות L הקישו 555 וסולמית. לאות M הקישו 6 וסולמית. לאות N הקישו 66 וסולמית. לאות O הקישו 666 וסולמית. לאות P הקישו 7 וסולמית. לאות Q הקישו 77 וסולמית. לאות R הקישו 777 וסולמית. לאות S הקישו 7777 וסולמית. לאות T הקישו 8 וסולמית. לאות U הקישו 88 וסולמית. לאות V הקישו 888 וסולמית. לאות W הקישו 9 וסולמית. לאות X הקישו 99 וסולמית. לאות Y הקישו 999 וסולמית. לאות Z הקישו 9999 וסולמית */
    M2293: 'M2293',
    /** לפי הרישום אצלנו, מופיע שכבר דיווחתם היום על מספר שנחסם, וניתן לדווח שלוש פעמים ביום. אם ברצונכם לדווח על מספר אחר, התקשרו שוב מחר. */
    M2294: 'M2294',
    /** לקבלת מספר חדש הקישו 1, לסיום, הקישו 2 או המתינו */
    M2295: 'M2295',
    /** שימו לב, במידה ולא קיבלתם את המספר, עליכם לבדוק שני דברים: 1. להפעיל את אפשרות שיחה ממתינה, דרך הגדרות הטלפון שלכם, או דרך חברת התיקשורת שלכם. 2. לוודא שאתם מדווחים על מספר שעבד לכם בעבר לפני שנחסם בטלפון זה שממנו אתם מדווחים. לאחר מכן נסו שוב, בעוד שעה, במידה ועדיין אינכם מצליחים לקבל את המספר, אנא צרו קשר עם שרות הלקוחות במספר 0773137770 */
    M2296: 'M2296',
    /** לא ניתן לצרף את מספר הטלפון שהוקש לרשימת תפוצה מספר, X */
    M2297: 'M2297',
    /** לא ניתן להסיר את מספר הטלפון שהוקש מרשימת תפוצה מספר, X */
    M2298: 'M2298',
    /** לא ניתן לחסום את מספר הטלפון שהוקש מרשימת תפוצה מספר, X */
    M2299: 'M2299',
    /** הקלטת משנה סדורה בעריכת הרב אליהו דורדק. בוצעה באולפן הספריה המרכזית לעוורים ובעלי לקויות ראיה בישראל,. קרין צבי פרומנטל */
    M2300: 'M2300',
    /** ברכות 01 */
    M2301: 'M2301',
    /** פאה 02 */
    M2302: 'M2302',
    /** דמאי 03 */
    M2303: 'M2303',
    /** כלאים 04 */
    M2304: 'M2304',
    /** שביעית 05 */
    M2305: 'M2305',
    /** תרומות 06 */
    M2306: 'M2306',
    /** מעשרות 07 */
    M2307: 'M2307',
    /** מעשר שני 08 */
    M2308: 'M2308',
    /** חלה 09 */
    M2309: 'M2309',
    /** ערלה 10 */
    M2310: 'M2310',
    /** בכורים 11 */
    M2311: 'M2311',
    /** שבת 12 */
    M2312: 'M2312',
    /** עירובין 13 */
    M2313: 'M2313',
    /** פסחים 14 */
    M2314: 'M2314',
    /** שקלים 15 */
    M2315: 'M2315',
    /** יומא 16 */
    M2316: 'M2316',
    /** סוכה 17 */
    M2317: 'M2317',
    /** ביצה 18 */
    M2318: 'M2318',
    /** ראש השנה 19 */
    M2319: 'M2319',
    /** תענית 20 */
    M2320: 'M2320',
    /** מגילה 21 */
    M2321: 'M2321',
    /** מועד קטן 22 */
    M2322: 'M2322',
    /** חגיגה 23 */
    M2323: 'M2323',
    /** יבמות 24 */
    M2324: 'M2324',
    /** כתובות 25 */
    M2325: 'M2325',
    /** נדרים 26 */
    M2326: 'M2326',
    /** נזיר 27 */
    M2327: 'M2327',
    /** סוטה 28 */
    M2328: 'M2328',
    /** גיטין 29 */
    M2329: 'M2329',
    /** קידושין 30 */
    M2330: 'M2330',
    /** בבא קמא 31 */
    M2331: 'M2331',
    /** בבא מציעא 32 */
    M2332: 'M2332',
    /** בבא בתרא 33 */
    M2333: 'M2333',
    /** סנהדרין 34 */
    M2334: 'M2334',
    /** מכות 35 */
    M2335: 'M2335',
    /** שבועות 36 */
    M2336: 'M2336',
    /** עדיות 37 */
    M2337: 'M2337',
    /** עבודה זרה 38 */
    M2338: 'M2338',
    /** אבות 39 */
    M2339: 'M2339',
    /** הוריות 40 */
    M2340: 'M2340',
    /** זבחים 41 */
    M2341: 'M2341',
    /** מנחות 42 */
    M2342: 'M2342',
    /** חולין 43 */
    M2343: 'M2343',
    /** בכורות 44 */
    M2344: 'M2344',
    /** ערכין 45 */
    M2345: 'M2345',
    /** תמורה 46 */
    M2346: 'M2346',
    /** כריתות 47 */
    M2347: 'M2347',
    /** מעילה 48 */
    M2348: 'M2348',
    /** תמיד 49 */
    M2349: 'M2349',
    /** מדות 50 */
    M2350: 'M2350',
    /** קנים 51 */
    M2351: 'M2351',
    /** כלים פרקים א עד יד 52 */
    M2352: 'M2352',
    /** כלים פרקים טו עד ל' 53 */
    M2353: 'M2353',
    /** אוהלות 54 */
    M2354: 'M2354',
    /** נגעים 55 */
    M2355: 'M2355',
    /** פרה 56 */
    M2356: 'M2356',
    /** טהרות 57 */
    M2357: 'M2357',
    /** מקואות 58 */
    M2358: 'M2358',
    /** נדה 59 */
    M2359: 'M2359',
    /** מכשירין 60 */
    M2360: 'M2360',
    /** זבים 61 */
    M2361: 'M2361',
    /** טבול יום 62 */
    M2362: 'M2362',
    /** ידים 63 */
    M2363: 'M2363',
    /** עוקצים 64 */
    M2364: 'M2364',
    /** הוספתם את מספר הטלפון שהוקש לרשימות התפוצה שמספרם, 1,2,3 */
    M2366: 'M2366',
    /** הסרתם את מספר הטלפון שהוקש מרשימות התפוצה שמספרם, 1,2,3 */
    M2367: 'M2367',
    /** חסמתם את מספר הטלפון שהוקש מרשימות התפוצה שמספרם, 1,2,3 */
    M2368: 'M2368',
    /** זרעים 1 */
    M2371: 'M2371',
    /** מועד 2 */
    M2372: 'M2372',
    /** נשים 3 */
    M2373: 'M2373',
    /** נזיקין 4 */
    M2374: 'M2374',
    /** קדשים 5 */
    M2375: 'M2375',
    /** טהרות 6 */
    M2376: 'M2376',
    /** סדר זרעים */
    M2381: 'M2381',
    /** סדר מועד */
    M2382: 'M2382',
    /** סדר נשים */
    M2383: 'M2383',
    /** סדר נזיקין */
    M2384: 'M2384',
    /** סדר קדשים */
    M2385: 'M2385',
    /** סדר טהרות */
    M2386: 'M2386',
    /** שמיעת שיעורים על המסכתות , לשיעורים מסדרזרעים 1 , מועד 2 , נשים 3 , נזיקין 4 , קדשים 5 , טהרות 6 , ליציאה הקישו כוכבית */
    M2390: 'M2390',
    /** שיעורים בסדר זרעים . למסכת ברכות הקישו 01 , 02פאה , 03דמאי , 04כלאים , 05שביעית, 06תרומות , 07מעשרות , 08מעשר שני , 09חלה , 10ערלה , 11בכורים , ליציאה הקישו כוכבית */
    M2391: 'M2391',
    /** שיעורים בסדר מועד . למסכת שבת הקישו 12 , 13עירובין , 14פסחים , 15שקלים , 16יומא , 17סוכה , 18ביצה , 19ראש השנה , 20תענית , 21מגילה , 22מועד קטן , 23חגיגה , ליציאה הקישו כוכבית */
    M2392: 'M2392',
    /** שיעורים בסדר נשים . למסכת יבמות הקישו 24 , 24יבמות , 25כתובות , 26נדרים , 27נזיר , 28סוטה , 29גיטין , 30קידושין , ליציאה הקישו כוכבית */
    M2393: 'M2393',
    /** שיעורים בסדר נזיקין. למסכת בבא קמא הקישו 31. 31בבא קמא. 32בבא מציעא. 33בבא בתרא. 34סנהדרין. 35מכות. 36שבועות. 37עדיות. 38עבודה זרה. 39אבות. 40הוריות. ליציאה הקישו כוכבית. */
    M2394: 'M2394',
    /** שיעורים בסדר קדשים. למסכת זבחים הקישו 41. 42מנחות. 43חולין. 44בכורות. 45ערכין. 46תמורה. 47כריתות. 48מעילה. 49תמיד. 50מדות. 51קנים. ליציאה הקישו כוכבית. */
    M2395: 'M2395',
    /** שיעורים במסכת טהרות. הקישו למסכת 52כלים פרקים א עד יד. 53כלים פרקים טו עד ל. 54אוהלות. 55נגעים. 56פרה. 57טהרות. 58מקואות. 59נדה. 60מכשירין. 61זבים. 62טבול יום. 63ידים. 64עוקצים. ליציאה הקישו כוכבית. */
    M2396: 'M2396',
    /** מסכת ברכות */
    M2401: 'M2401',
    /** מסכת פאה */
    M2402: 'M2402',
    /** מסכת דמאי */
    M2403: 'M2403',
    /** מסכת כלאים */
    M2404: 'M2404',
    /** מסכת שביעית */
    M2405: 'M2405',
    /** מסכת תרומות */
    M2406: 'M2406',
    /** מסכת מעשרות */
    M2407: 'M2407',
    /** מסכת מעשר שני */
    M2408: 'M2408',
    /** מסכת חלה */
    M2409: 'M2409',
    /** מסכת ערלה */
    M2410: 'M2410',
    /** מסכת בכורים */
    M2411: 'M2411',
    /** מסכת שבת */
    M2412: 'M2412',
    /** מסכת עירובין */
    M2413: 'M2413',
    /** מסכת פסחים */
    M2414: 'M2414',
    /** מסכת שקלים */
    M2415: 'M2415',
    /** מסכת יומא */
    M2416: 'M2416',
    /** מסכת סוכה */
    M2417: 'M2417',
    /** מסכת ביצה */
    M2418: 'M2418',
    /** מסכת ראש השנה */
    M2419: 'M2419',
    /** מסכת תענית */
    M2420: 'M2420',
    /** מסכת מגילה */
    M2421: 'M2421',
    /** מסכת מועד קטן */
    M2422: 'M2422',
    /** מסכת חגיגה */
    M2423: 'M2423',
    /** מסכת יבמות */
    M2424: 'M2424',
    /** מסכת כתובות */
    M2425: 'M2425',
    /** מסכת נדרים */
    M2426: 'M2426',
    /** מסכת נזיר */
    M2427: 'M2427',
    /** מסכת סוטה */
    M2428: 'M2428',
    /** מסכת גיטין */
    M2429: 'M2429',
    /** מסכת קידושין */
    M2430: 'M2430',
    /** מסכת בבא קמא */
    M2431: 'M2431',
    /** מסכת בבא מציעא */
    M2432: 'M2432',
    /** מסכת בבא בתרא */
    M2433: 'M2433',
    /** מסכת סנהדרין */
    M2434: 'M2434',
    /** מסכת מכות */
    M2435: 'M2435',
    /** מסכת שבועות */
    M2436: 'M2436',
    /** מסכת עדיות */
    M2437: 'M2437',
    /** מסכת עבודה זרה */
    M2438: 'M2438',
    /** מסכת אבות */
    M2439: 'M2439',
    /** מסכת הוריות */
    M2440: 'M2440',
    /** מסכת זבחים */
    M2441: 'M2441',
    /** מסכת מנחות */
    M2442: 'M2442',
    /** מסכת חולין */
    M2443: 'M2443',
    /** מסכת בכורות */
    M2444: 'M2444',
    /** מסכת ערכין */
    M2445: 'M2445',
    /** מסכת תמורה */
    M2446: 'M2446',
    /** מסכת כריתות */
    M2447: 'M2447',
    /** מסכת מעילה */
    M2448: 'M2448',
    /** מסכת תמיד */
    M2449: 'M2449',
    /** מסכת מדות */
    M2450: 'M2450',
    /** מסכת קנים */
    M2451: 'M2451',
    /** מסכת כלים פרקים א עד יד */
    M2452: 'M2452',
    /** מסכת כלים פרקים טו עד ל */
    M2453: 'M2453',
    /** מסכת אוהלות */
    M2454: 'M2454',
    /** מסכת נגעים */
    M2455: 'M2455',
    /** מסכת פרה */
    M2456: 'M2456',
    /** מסכת טהרות */
    M2457: 'M2457',
    /** מסכת מקואות */
    M2458: 'M2458',
    /** מסכת נדה */
    M2459: 'M2459',
    /** מסכת מכשירין */
    M2460: 'M2460',
    /** מסכת זבים */
    M2461: 'M2461',
    /** מסכת טבול יום */
    M2462: 'M2462',
    /** מסכת ידים */
    M2463: 'M2463',
    /** מסכת עוקצים */
    M2464: 'M2464',
    /** שרות זה אינו פעיל במערכת זו. אנא פנו לשרות הלקוחות */
    M2470: 'M2470',
    /** דירוג שביעות רצון מהשירות והעמידה בזמנים */
    M2471: 'M2471',
    /** דירוג שביעות רצון מהמקצועיות */
    M2472: 'M2472',
    /** דירוג שביעות רצון מהמחיר */
    M2473: 'M2473',
    /** לא הוגדר סוג זיהוי לחיפוש */
    M2474: 'M2474',
    /** אין קובץ מורשי עריכה */
    M2475: 'M2475',
    /** לא מוגדרים הרשאות עריכה עבורך */
    M2476: 'M2476',
    /** אנא הקישו את מספר הזיהוי של הלקוח וסולמית לסיום */
    M2477: 'M2477',
    /** סך הניקוד הקיים הלקוח הוא */
    M2478: 'M2478',
    /** להוספת ניקוד הקישו 1. להורדת ניקוד הקישו 2. להקשת מספר זיהוי של לקוח אחר הקישו כוכבית */
    M2479: 'M2479',
    /** הוספת ניקוד. אנא הקישו את סכום הנקודות שברצונכם להוסיף */
    M2480: 'M2480',
    /** הורדת ניקוד. אנא הקישו את סכום הנקודות שברצונכם להוריד */
    M2481: 'M2481',
    /** עדכון הנקודות התבצע בהצלחה */
    M5105: 'M5105',
    /** סך הניקוד החדש הוא.. */
    M2482: 'M2482',
    /** לביצוע פעולות נוספות הקישו 1. לחזרה לתפריט קודם הקישו 2 או המתינו */
    M2483: 'M2483',
    /** לא ניתן להכנס למינוס נקודות */
    M2484: 'M2484',
    /** אין קובץ תורמים */
    M2485: 'M2485',
    /** משוייכים אליך */
    M2486: 'M2486',
    /** תורמים */
    M2487: 'M2487',
    /** אנא הקש את מספר הזיהוי של התורם. לשמיעת כל התורמים ברצף הקישו אפס וסולמית. ליציאה הקישו כוכבית וסולמית */
    M2488: 'M2488',
    /** אין תורמים משויכיים אליך, אנא פנה למנהל הארגון */
    M2489: 'M2489',
    /** להלן הפירוט */
    M2490: 'M2490',
    /** סוף רשימה */
    M2491: 'M2491',
    /** תורם זה אינו קיים ברשימה שלך */
    M2492: 'M2492',
    /** תורם זה עדיין לא תרם */
    M2493: 'M2493',
    /** תורם זה תרם סך של */
    M2494: 'M2494',
    /** שקלים */
    M2495: 'M2495',
    /** לעדכון תרומה או סכום התרומה הקישו 1. לבדיקת מספר אחר הקישו 2 */
    M2496: 'M2496',
    /** עדכון תרומה חדש, אנא עדכן את סכום התרומה המעודכן וסולמית לסיום */
    M2497: 'M2497',
    /** העדכון התבצע בהצלחה */
    M2498: 'M2498',
    /** בכל שלב ניתן להקיש 9 ולערוך את פרטי התרומה,. או להקיש על כל מקש אחר לפרטי התורם הבא. */
    M2499: 'M2499',
    /** להוספה לרשימת תפוצה של מערכת מסויימת 1 להסרה 2 ליציאה הקישו 3 */
    M2500: 'M2500',
    /** הקישו מספר מערכת לביטול חסימת מספרכם מרשימת התפוצה */
    M2501: 'M2501',
    /** בביטול החסימה, הנכם מאשרים קבלת שיחות וצינתוקים מהמערכת לאישור הקישו 1 לביטול 2בביטול החסימה, הנכם מאשרים קבלת שיחות וצינתוקים מהמערכת. לאישור, הקישו 1. לביטול, הקישו 2 */
    M2502: 'M2502',
    /** חסימת מספרכם מקבלת הודעות וצינתוקים מהמערכת בוטלה בהצלחה */
    M2503: 'M2503',
    /** הקישו מספר מערכת להסרת מספרכם מרשימת התפוצה */
    M2504: 'M2504',
    /** בהסרת מספרכם מהרשימה, הנכם מאשרים הפסקת קבלת שיחות וצינתוקים מהמערכת. לאישור הקישו 1 לביטול 2 */
    M2505: 'M2505',
    /** המספר הוסר בהצלחה */
    M2506: 'M2506',
    /** זוהתה תקלה - הפעולה לא הושלמה - אנא נסו שוב מאוחר יותר או צרו קשר עם שירות הלקוחות */
    M2507: 'M2507',
    /** בעיסקה זו תחויבו בסך */
    M2508: 'M2508',
    /** לצורך השלמת הרכישה, יש להקיש את מספרי תעודות הזהות של המשתתפים עבורם נרכשו הכרטיסים. נרכשו */
    M2509: 'M2509',
    /** כרטיסים */
    M2510: 'M2510',
    /** אנא הקש את תעודת הזהות לכרטיס מספר */
    M2511: 'M2511',
    /** תעודת זהות אינה תקינה */
    M2512: 'M2512',
    /** בונוס! */
    M2513: 'M2513',
    /** קיבלתם */
    M2514: 'M2514',
    /** פריטים תוספת מתנה */
    M2515: 'M2515',
    /** סהכ כולל בונוס */
    M2516: 'M2516',
    /** אנא הקישו את יום החיוב וסולמית לסיום */
    M2517: 'M2517',
    /** אנא הקישו את סכום החיוב בכל חודש וסולמית לסיום */
    M2518: 'M2518',
    /** בעיסקה זו תחוייבו בכל חודש בסך */
    M2519: 'M2519',
    /** כמות החודשים לחיוב היא */
    M2520: 'M2520',
    /** אנא הקש מספר חודשים לחיוב וסולמית, לחיוב קבוע אנא הקישו אפס וסולמית */
    M2521: 'M2521',
    /** חיוב קבוע */
    M2522: 'M2522',
    /** תאריך החיוב הקרוב הוא */
    M2523: 'M2523',
    /** יצאת בהצלחה הנתונים נשמרו */
    M2524: 'M2524',
    /** יצאת בהצלחה, הנתונים נשמרו, אישור מספר */
    M2525: 'M2525',
    /** מספר המאזינים בשלוחה גדול מהמוגדר */
    M2526: 'M2526',
    /** לא מוגדר סכום תשלום עבורכם. לא ניתן להמשיך בתשלום. אנא צרו קשר עם מנהל המערכת */
    M2527: 'M2527',
    /** כבר ביצעתם בהצלחה את התשלום , לא ניתן לשלם שוב. */
    M2528: 'M2528',
    /** יום חיוב יכול להיות בין הראשון ועד ה28 לחודש בלבד */
    M2529: 'M2529',
    /** אנא בחרו את פרק התהילים אותו ברצונכם לבחור. לדוגמא לפרק א הקישו אחת וסולמית לפרק קנ הקישו 150 */
    M2530: 'M2530',
    /** הפרק אותו בחרתם הינו פרק */
    M2531: 'M2531',
    /** שמיעה הקישו 1 או המתינו, לשינוי הפרק הקישו 2 */
    M2532: 'M2532',
    /** שלום וברוכים הבאים לאזור ניהול המערכת.... ניתן להתחבר דרך האתר */
    M2533: 'M2533',
    /** תפריט אפשרויות תשלום. לתשלום בכרטיס אשראי מיידי הקש 1. לתשלום בצ'ק 2. לתשלום במזומן 3 */
    M2534: 'M2534',
    /** הגדרת אמצעי תשלום מזומן נתקבל בהצלחה, חובה לסגור את התשלום מול הנציג תוך 24 שעות */
    M2535: 'M2535',
    /** הגדרת אמצעי תשלום בהמחאה בנקאית נתקבל בהצלחה, חובה לסגור את התשלום מול הנציג תוך 24 שעות */
    M2536: 'M2536',
    /** כסא נוסף סמוך אינו זמין במצב זה */
    M2537: 'M2537',
    /** מספרכם אינו ראשיי להרשם למערכת, לבירורים, פנו לאחראי */
    M2538: 'M2538',
    /** קבלת התשלום בכרטיס אשראי נתקבל בהצלחה */
    M2539: 'M2539',
    /** הקובץ נבחר להקלטה */
    M2540: 'M2540',
    /** מספרכם אינו מזוהה, כדי לבחור קובץ להקלטה, אנא חייגו ממספר מזוהה */
    M2541: 'M2541',
    /** אין אישור לבחירת קובץ זה להקלטה */
    M2542: 'M2542',
    /** להתחלת הקלטה על הקובץ שנבחר, הקישו 1, לשמיעת הקלטות קודמות, הקישו 2 */
    M2543: 'M2543',
    /** לא נבחר קובץ להקלטה */
    M2544: 'M2544',
    /** ההקלטה תתחיל מייד אחרי הציפוף */
    M2545: 'M2545',
    /** ההקלטה הסתימה ונשמרה ברשימת ההשמעה ברירת החדל שלכם */
    M2546: 'M2546',
    /** לחזרה למיקום האחרון אליו האזנתם בשלוחה זו, הקישו 1. להאזנה רגילה הקישו 2 או הָמתינו. */
    M2550: 'M2550',
    /** אנא הקישו את מספר השלוחה בה האזנתם ויצאתם במהלך האזנה, לצורך חזרתכם למיקום האחרון, בין שלוחה לשלוחה הקישו * ובסיום הקישו # */
    M2551: 'M2551',
    /** בעיסקה זו תתפס מסגרת בסך */
    M2552: 'M2552',
    /** אנא הקישו את הסכום לתפיסת מסגרת וסולמית לסיום */
    M2553: 'M2553',
    /** לבחירת מספר קובץ להקלטה, הקישו 1, להמשך והקלטה לפי סדר השלוחה, הקישו 2 או המתינו */
    M2555: 'M2555',
    /** אנא הקישו את מספר הקובץ שברצונכם להקליט */
    M2556: 'M2556',
    /** יום החיוב החודשי הינו */
    M2557: 'M2557',
    /** לחודש */
    M2558: 'M2558',
    /** חלה שגיאה ביצירת לקוח תשלומים */
    M2559: 'M2559',
    /** אנא הקש את מספר הזיהוי של החבר אליו ברצונכם להוסיף את הנקודות */
    M2560: 'M2560',
    /** תודה רבה. העדכון התבצע בהצלחה, זיהוי מספר.. */
    M2561: 'M2561',
    /** נקודות. בהצלחה */
    M2562: 'M2562',
    /** לא ניתן להוסיף נקודות לעצמך. */
    M2563: 'M2563',
    /** הוספתם את מקסימום הפעמים שניתן להוסיף נקודות, בהצלחה */
    M2564: 'M2564',
    /** קיבל */
    M2565: 'M2565',
    /** לתהילים היומי לפי ימי החודש הקישו 1, לתהילים היומי לפי ימי השבוע הקישו 2, לפרקי התהילים שלי הקישו 3, לחזרה לתפריט קודם הקישו כוכבית */
    M2566: 'M2566',
    /** לא ניתן לעבור למערכות אחרות, לאחר מעבר לחדר ועידה,אנא התקשרו שנית, שלום ותודה */
    M2567: 'M2567',
    /** לשינוי הבחירה, הקישו 1, לשמיעת התוצאות, הקישו 2 או הָמתינו */
    M2568: 'M2568',
    /** להוספת מספר מישני לוואצפון - הקישו 1 - להוספת מספר מישני למערכת תוכן - הקישו 2 */
    M2570: 'M2570',
    /** אנא הקישו את מספר המערכת, ובסיום, הַקישו סולמית. */
    M2571: 'M2571',
    /** המספר שהוקש אינו תקין - אנא נסו שוב */
    M2572: 'M2572',
    /** הפעולה בוצעה בהצלחה */
    M2573: 'M2573',
    /** כל העמודות תפוסות. להשארת הודעה הקישו 1. להמשך המתנה הקישו 2 או המתינו */
    M2574: 'M2574',
    /** החל מעכשיו תקבלו ניקוד בהתאם לדקות האזנה שלכם */
    M2575: 'M2575',
    /** צבירת הנקודות לפי זמן האזנה הסתיימה */
    M2576: 'M2576',
    /** הטלפון שלך מזוהה במערכת כלקוח קשר קהילות,. להתחברות באמצעות הלקוח הקש את הסיסמה שלך בקשר קהילות וסולמית לסיום,. להמשך ללא התחברות הקישו כוכבית וסולמית. */
    M2577: 'M2577',
    /** שגיאה בטעינת הטוקן, הנכם מועברים להקשת כרטיס מלא */
    M2578: 'M2578',
    /** האימייל נשלח בהצלחה */
    M2580: 'M2580',
    /** לא נמצא קובץ לשליחה */
    M2581: 'M2581',
    /** הכמות שבחרתם גדולה מהכמות המקסימלית */
    M2582: 'M2582',
    /** מקסימום כמות ההזמנות האפשרית היא */
    M2583: 'M2583',
    /** אין הודעות נוספות */
    M2584: 'M2584',
    /** אין הודעות חדשות */
    M2585: 'M2585',
    /** לצורך חיבור לחדר הועידה נא להתקשר למספר החיוג הישיר לחדר. המספר לחיוג הוא */
    M2586: 'M2586',
    /** השתקתכם הופעלה */
    M2588: 'M2588',
    /** השתקתכם בוטלה */
    M2589: 'M2589',
    /** מספר היחידות במערכת שלך נמוך מהמוגדר, מומלץ שתרכשו חבילת יחידות נוספת בהקדם */
    M2590: 'M2590',
    /** מספר היחידות במערכת שלך הוא */
    M2591: 'M2591',
    /** תוקף היחידות יפוג בעוד */
    M2592: 'M2592',
    /** ימים */
    M2593: 'M2593',
    /** תוקף היחידות עומד לפוג, מומלץ שתרכשו חבילה נוספת בהקדם, ובכך להאריך את תוקף היחידות */
    M2594: 'M2594',
    /** יש לך הודעות חדשות */
    M2595: 'M2595',
    /** יש לך ... */
    M2596: 'M2596',
    /** הודעות חדשות */
    M2597: 'M2597',
    /** בשלוחה... */
    M2598: 'M2598',
    /** לשמיעת הודעות ישנות, הקישו 1. ליציאה הקישו 2 או המתינו. */
    M2599: 'M2599',
    /** כל הנציגים תפוסים כעת. להמשך המתנה הקישו 1 או המתינו. ליציאה הקישו 2 */
    M2600: 'M2600',
    /** מערכת ישיבות - ברוכים הבאים */
    M2690: 'M2690',
    /** מערכת ישיבות - מספר משתמש */
    M2691: 'M2691',
    /** מערכת ישיבות - אנא הקישו את הסיסמה */
    M2692: 'M2692',
    /** מערכת ישיבות - אחד או יותר מהנתונים שהוקשו, שגוי */
    M2693: 'M2693',
    /** מערכת ישיבות - אנא הקישו מספר לחיוג - למעבר מהיר למערכת הישיבה - הקישו 1 וסולמית */
    M2694: 'M2694',
    /** מערכת ישיבות - אין יחידות במערכת */
    M2695: 'M2695',
    /** מערכת ישיבות - אין יחידות למשתמש */
    M2696: 'M2696',
    /** מערכת ישיבות */
    M2697: 'M2697',
    /** מערכת ישיבות */
    M2698: 'M2698',
    /** מערכת ישיבות */
    M2699: 'M2699',
    /** כמות הנרשמים עד עכשיו היא */
    M2700: 'M2700',
    /** ההודעה תישלח תוך מספר רגעים */
    M2701: 'M2701',
    /** ההודעה נשלחה בהצלחה */
    M2702: 'M2702',
    /** תקלה בשליחת ההודעה - אנא פנה למנהל */
    M2703: 'M2703',
    /** שימו לב, כיוון שדיווחתם על מספר זה שנחסם, באפשרותכם לבחור כעת, שכל חברי הקבוצה יקבלו מעכשיו ולהבא, מספר אישי שדרכו יוכלו לחייג לקבוצה. בכדי להגדיר מספרים אישיים לכולם, הקישו 1, להמשך ללא שינוי, הקישו 2, או הַמתינו. */
    M2704: 'M2704',
    /** ההגדרה עודכנה בהצלחה, מעכשיו ולהבא, כל חברי הקבוצה יקבלו מספר אישי, בכל פעם שֶׁתשלחו הודעה עם צינתוק. */
    M2705: 'M2705',
    /** אנא הקישו את סיסמת הקבוצה וסולמית לסיום */
    M2706: 'M2706',
    /** הסיסמא שגויה */
    M2707: 'M2707',
    /** שימו לב, אנחנו יוצרים עבורכם כעת מערכת משוכללת במיוחד מסוג אי וי אר 2, מהמשוכללות ביותר בעולם. - אנא המתינו מספר שניות. */
    M2708: 'M2708',
    /** לשמיעת הדירוגים הקישו 1, לשינוי הדירוג הקישו 2, להמשך הקישו 3, או הָמתינו */
    M2709: 'M2709',
    /** להקשה מחדש הקישו 1 או המתינו, ליציאה הקישו 2 */
    M2710: 'M2710',
    /** אנא הקישו מספר מערכת שעבורה ברצונכם לקבל מספר אישי */
    M2711: 'M2711',
    /** בעל המקצוע שנבחר הוא */
    M2712: 'M2712',
    /** הנתונים התקבלו בהצלחה , הינך מועבר לתפריט הקודם */
    M2713: 'M2713',
    /** חלוקת שעות רצופות. עד כה קיבלו על עצמם.... */
    M2714: 'M2714',
    /** XXX שעות רצופות.... */
    M2715: 'M2715',
    /** נא הקישו את מספר שעות רצופות שקיבלתם וסולמית לסיום */
    M2716: 'M2716',
    /** תודה רבה תזכו למצוות . */
    M2717: 'M2717',
    /** שאלת סקר, הקישו את התשובה. */
    M2718: 'M2718',
    /** הצבעתכם נקלטה בהצלחה */
    M2719: 'M2719',
    /** לשמיעת תוצאות הסקר, הקישו 1, לסיום הקישו 2. */
    M2720: 'M2720',
    /** הבחירה שלך היא */
    M2721: 'M2721',
    /** כמות המשתתפים בסקר */
    M2722: 'M2722',
    /** אחוז המשתתפים שבחרו את אפשרות 0 */
    M2723: 'M2723',
    /** אחוז המשתתפים שבחרו את אפשרות 1 */
    M2724: 'M2724',
    /** אחוז המשתתפים שבחרו את אפשרות 2 */
    M2725: 'M2725',
    /** אחוז המשתתפים שבחרו את אפשרות 3 */
    M2726: 'M2726',
    /** אחוז המשתתפים שבחרו את אפשרות 4 */
    M2727: 'M2727',
    /** אחוז המשתתפים שבחרו את אפשרות 5 */
    M2728: 'M2728',
    /** אחוז המשתתפים שבחרו את אפשרות 6 */
    M2729: 'M2729',
    /** אחוז המשתתפים שבחרו את אפשרות 7 */
    M2730: 'M2730',
    /** אחוז המשתתפים שבחרו את אפשרות 8 */
    M2731: 'M2731',
    /** אחוז המשתתפים שבחרו את אפשרות 9 */
    M2732: 'M2732',
    /** הקבוצה שלך צברה עד היום */
    M2750: 'M2750',
    /** לשליחת sms הכולל את מספר אישור ההזמנה הקישו 1 להמשך הקישו 2 */
    M2751: 'M2751',
    /** sms הכולל את מספר אישור ההזמנה, נשלח בהצלחה למכשירכם */
    M2752: 'M2752',
    /** שגיאה בשליחת הsms, אנא דווחו למנהל המערכת */
    M2753: 'M2753',
    /** המערכת זיהתה שבחרתם לדלג לאישור הקישו 1 או המתינו. אם סיימתם את ההקלטה בהצלחה הקישו 2. להקלטה מחודשת הקישו 3 */
    M2754: 'M2754',
    /** לשליחה למספר ממנו חייגתם, הַקִּישׁוּ 1, להקשת מספר שאליו תִּשָּׁלַח ההודעה, הַקִּישׁוּ 2, להמשך ללא שליחת ההודעה, הַקִּישׁוּ 3 */
    M2755: 'M2755',
    /** אנא הקישו את המספר אליו אתם רוצים שההודעה תשלח ובסיום הקישו סולמית */
    M2756: 'M2756',
    /** לשליחת sms הכולל את מספר אישור ההזמנה הקישו 1 להמשך הקישו 2 */
    M2757: 'M2757',
    /** sms הכולל את מספר אישור ההזמנה, נשלח בהצלחה למכשירכם */
    M2758: 'M2758',
    /** שגיאה בשליחת הsms, אנא דווחו למנהל המערכת */
    M2759: 'M2759',
    /** לשליחה למספר ממנו חייגתם, הַקִּישׁוּ 1, להקשת מספר שאליו תִּשָּׁלַח ההודעה, הַקִּישׁוּ 2, להמשך ללא שליחת ההודעה, הַקִּישׁוּ 3 */
    M2760: 'M2760',
    /** אנא הקישו את המספר אליו אתם רוצים שההודעה תשלח ובסיום הקישו סולמית */
    M2761: 'M2761',
    /** הסכום עבור הזמנה אחת הינו */
    M2762: 'M2762',
    /** אנא הקישו את כמות ההזמנות שברצונכם להזמין */
    M2763: 'M2763',
    /** לא מוגדר מחיר הזמנה */
    M2764: 'M2764',
    /** הסכום הכולל לתשלום הינו */
    M2765: 'M2765',
    /** לא ניתן להפעיל חיוג במצב הגבלת זמן לשלוחה, הגדירו הגבלת זמן לשיחה */
    M2766: 'M2766',
    /** מתוך יעד ניקוד אישי של ... נקודות */
    M2767: 'M2767',
    /** מתוך יעד ניקוד קבוצתי של ... נקודות */
    M2768: 'M2768',
    /** יש לך... */
    M2769: 'M2769',
    /** לשמיעת מספרי הגישה שלך הקש 1. לקבלת מספר גישה חדש הקש 2. לשיתוף מספר גישה שלך עם חבר הקש 3. לחזרה הקישו כוכבית */
    M2771: 'M2771',
    /** מספר הגישה החדש שקיבלת הוא */
    M2772: 'M2772',
    /** לשמיעה חוזרת הקישו 1. לסיום הקישו 2 */
    M2773: 'M2773',
    /** אין מספר גישה חדש עבורך */
    M2774: 'M2774',
    /** מספרי הגישה שלך הם */
    M2775: 'M2775',
    /** אין כרגע מספרי גישה לחלוקה, אנא נסה שוב במועד מאוחר יותר */
    M2776: 'M2776',
    /** . אנא הקש את מספר הגישה שלך שברצונך לצרף אליו גם את החבר */
    M2777: 'M2777',
    /** הקש את מספר הטלפון של החבר שברצונך לשלוח אליו שיחה ולשתף את מספר הגישה */
    M2778: 'M2778',
    /** עדיין אין לך מספר גישה, אנא קח מספר ואז תוכל לשתפו */
    M2779: 'M2779',
    /** נציגנו עוסקים כרגע בפניות קודמות אנא המתן ותענה לפי התור */
    M2780: 'M2780',
    /** תודה על סבלותכם */
    M2781: 'M2781',
    /** הנך ראשון בתור */
    M2782: 'M2782',
    /** מיקומך בתור הוא */
    M2783: 'M2783',
    /** מחכה לשיחה עם נציג */
    M2784: 'M2784',
    /** זמן ההמתנה הממצוע הוא כ.. */
    M2785: 'M2785',
    /** דקות */
    M2786: 'M2786',
    /** שניות */
    M2787: 'M2787',
    /** פחות מ... */
    M2788: 'M2788',
    /** זמן ההמתנה */
    M2789: 'M2789',
    /** מספר זה אינו מוגדר במספר הגישה שלך */
    M2790: 'M2790',
    /** שלום. זוהי הודעה שנשלחה אליך לבקשתו של המאזין שמספרו מופיע על הצג. לקבלת מספר גישה ששותף עבורך הקש 1. לניתוק הקש 2 או המתן */
    M2791: 'M2791',
    /** מספר הגישה נשלח בהצלחה */
    M2792: 'M2792',
    /** לא הוקשה תשובה */
    M2793: 'M2793',
    /** חדר ועידה בשלוחה */
    M2794: 'M2794',
    /** פעיל כעת */
    M2795: 'M2795',
    /** אין מספר פתוח לשיתוף, הנך מועבר לתפריט הראשי, לצורך הוספת מספר. לאחר הוספת המספר תוכל לשתפו */
    M2796: 'M2796',
    /** שידור חי בשלוחה */
    M2797: 'M2797',
    /** פעיל כעת */
    M2798: 'M2798',
    /** יחל בעוד זמן קצר */
    M2799: 'M2799',
    /** הקלטתם בהצלחה את הסיפור שלכם */
    M2800: 'M2800',
    /** להפעלת השמעות אנא הקישו את השלוחה המבוקשת. להפעלת השמעות מתתי תיקיות הקישו את הכתובת המלאה, כאשר בין תיקייה לתיקייה הקישו כוכבית. בסיום הכתובת המלאה הקישו סולמית,. להפעלת השלוחה הראשית הקישו סולמית. לחזרה לתפריט קודם הקישו כוכבית וסולמית */
    M2801: 'M2801',
    /** שלוחה זו אינה קיימת */
    M2802: 'M2802',
    /** הדרישות בהקראת הסיפור הינו */
    M2803: 'M2803',
    /** מילים לדקה */
    M2804: 'M2804',
    /** הנכם הולכים להקליט סיפור באורך */
    M2805: 'M2805',
    /** מילים */
    M2806: 'M2806',
    /** אורך ההקלטה בשניות הוא */
    M2807: 'M2807',
    /** ממוצע מילים לדקה שלכם הוא */
    M2808: 'M2808',
    /** הציון שלכם הוא */
    M2809: 'M2809',
    /** יום עברי */
    M2810: 'M2810',
    /** חודש עברי */
    M2811: 'M2811',
    /** שנה עברית */
    M2812: 'M2812',
    /** יום לועזי */
    M2813: 'M2813',
    /** חודש לועזי */
    M2814: 'M2814',
    /** שנה לועזית */
    M2815: 'M2815',
    /** סיימת לענות על כל השאלות */
    M2816: 'M2816',
    /** המערכת מזהה כי כבר סיימת את עדכון המבחן שלך */
    M2817: 'M2817',
    /** הודעות חדשות */
    M2818: 'M2818',
    /** בשלוחה... */
    M2819: 'M2819',
    /** עד כה נתרמו */
    M2820: 'M2820',
    /** שאחרי ההכפלה הם */
    M2821: 'M2821',
    /** מתוך היעד הכללי בסך */
    M2822: 'M2822',
    /** שהם */
    M2823: 'M2823',
    /** אחוזים מהיעד הכללי */
    M2824: 'M2824',
    /** הסכום נתרם על ידי */
    M2825: 'M2825',
    /** תורמים */
    M2826: 'M2826',
    /** עדיין חסרים */
    M2827: 'M2827',
    /** בכדי להגיע ליעד */
    M2828: 'M2828',
    /** ברוך השם הגענו ליעד,והצלחנו לגייס */
    M2829: 'M2829',
    /** בעקבות הצלחת הקמפיין הוגדר יעד בונוס בסך */
    M2830: 'M2830',
    /** בכדי להגיע ליעד הבונוס */
    M2831: 'M2831',
    /** ברוך השם הגענו גם ליעד הבונוס, והצלחנו לגייס */
    M2832: 'M2832',
    /** אחוזים מהיעד הבונוס */
    M2833: 'M2833',
    /** הזמן שנשאר עד לסיום הקמפיין הוא */
    M2834: 'M2834',
    /** מספרך האישי אינו נמצא ברשימת המתרימים או שכבר הוגדר יעד, שלום ותודה */
    M2835: 'M2835',
    /** שקלים */
    M2836: 'M2836',
    /** הינכם מועברים להגדרת יעד למספר אישי... */
    M2837: 'M2837',
    /** ימים */
    M2838: 'M2838',
    /** שעות */
    M2839: 'M2839',
    /** דקות */
    M2840: 'M2840',
    /** שניות */
    M2841: 'M2841',
    /** ו... */
    M2842: 'M2842',
    /** ההתרמה הסתיימה כבר */
    M2843: 'M2843',
    /** אנא הקישו את סכום התרומה, ובסיום הקישו סולמית */
    M2844: 'M2844',
    /** לתרומה בכרטיס אשראי הקישו 1, לתרומה במזומן הקישו 2, לתרומה בקבלת נתונים הקישו 3. */
    M2845: 'M2845',
    /** הנך מועבר לתשלום באשראי */
    M2846: 'M2846',
    /** התרומה התקבלה הצלחה, תזכו למצוות */
    M2847: 'M2847',
    /** אך עדיין ניתן לתרום למטרה נעלית זו */
    M2848: 'M2848',
    /** וכבר לא ניתן לתרום למטרה זו */
    M2849: 'M2849',
    /** במהלך ההתרמה נתרמו */
    M2850: 'M2850',
    /** מתוך יעד הבונוס בסך */
    M2851: 'M2851',
    /** התרומה שלכם בסך */
    M2852: 'M2852',
    /** תוכפל במצי'נג לסך */
    M2853: 'M2853',
    /** הנך מועבר לתשלום בקבלת נתונים */
    M2854: 'M2854',
    /** להקלטת שם התורם הקישו 1, לתרומה בעילום שם הקישו 2 */
    M2855: 'M2855',
    /** בחרתם לתרום בעילום שם */
    M2856: 'M2856',
    /** נא הקליטו את שם התורם ולסיום הקישו סולמית */
    M2857: 'M2857',
    /** לאישור הקישו 1, להקלטה מחדש הקישו 2 לשמיעה חוזרת הקישו 3 */
    M2858: 'M2858',
    /** אם ברצונכם להקליט הערה לתרומה הקישו 1, לדילוג הקישו 2 */
    M2859: 'M2859',
    /** נא הקליטו את ההערה ולסיום הקישו סולמית */
    M2860: 'M2860',
    /** הקלטת שם התורם הסתיימה בהצלחה */
    M2861: 'M2861',
    /** הקלטת ההערה הסתיימה בהצלחה */
    M2862: 'M2862',
    /** זוהתה במערכת כמתרים, לתרומה על החשבון שלך הקישו 1, לתרומה על חשבון מתרים אחר הקישו 2, לתרומה כללית הקישו 3 */
    M2863: 'M2863',
    /** לתרומה על חשבון של מתרים הקישו את מספר המתרים ולסיום הקישו #, לתרומה כללית הקישו # ליציאה הקישו * וסולמית */
    M2864: 'M2864',
    /** מספר המתרים לא נמצא ברשימת המתרימים */
    M2865: 'M2865',
    /** סך כל התרומות שהצלחת לגייס הוא */
    M2866: 'M2866',
    /** מתוך היעד האישי בסך */
    M2867: 'M2867',
    /** אחוזים מהיעד האישי */
    M2868: 'M2868',
    /** אשריך!, הגעת ליעד שלך, והצלחת לגייס סך */
    M2869: 'M2869',
    /** סך התרומות שהמתרים הצליח לגייס הוא */
    M2870: 'M2870',
    /** אין קובץ מתרימים בשלוחה */
    M2871: 'M2871',
    /** לתרומה כללית הקישו 1, ליציאה הקישו 2 */
    M2872: 'M2872',
    /** המתרים שייך לקבוצה */
    M2873: 'M2873',
    /** סך כל התרומות שהקבוצה הכניסה הוא */
    M2874: 'M2874',
    /** אשריכם! הקבוצה הגיעה ליעד והצליחה לגייס סך */
    M2875: 'M2875',
    /** מתוך היעד הקבוצתי בסך */
    M2876: 'M2876',
    /** אחוזים מהיעד הקבוצתי */
    M2877: 'M2877',
    /** מספר המתרים */
    M2878: 'M2878',
    /** לא הוגדר סוג שלוחת התרמה חיצונית */
    M2879: 'M2879',
    /** לא הוגדר באיזה שלוחה מתבצעת ההתרמה */
    M2880: 'M2880',
    /** ההגדרות בשלוחת ההתרמה לא הושלמו */
    M2881: 'M2881',
    /** אין קובץ קבוצות בשלוחת ההתרמה */
    M2882: 'M2882',
    /** זוהתה במערכת כמתרים, לשמיעת המצב שלך הקישו 1, לשמיעת מצב של מתרים אחר הקישו 2, ליציאה הקישו 3. */
    M2883: 'M2883',
    /** נא הקישו את מספר המתרים שברצונך לשמוע את מצב ההתרמה שלו ולסיום הקישו #, ליציאה הקישו כוכבית וסולמית */
    M2884: 'M2884',
    /** זוהתה במערכת כקבוצה לתרומה על שם הקבוצה הקישו 1 לתרומה כללית הקש 2 ליציאה הקש כוכבית וסולמית */
    M2885: 'M2885',
    /** לתרומה על חשבון קבוצה הקישו את מספר הקבוצה ולסיום הקישו #, לתרומה כללית הקישו #, ליצאה הקישו * וסולמית */
    M2886: 'M2886',
    /** מספר הקבוצה שהקשת לא נמצא ברשימת הקבוצות נסו שנית */
    M2887: 'M2887',
    /** מספר קבוצה */
    M2888: 'M2888',
    /** זוהתה במערכת כקבוצה לשמיעת המצב של הקבוצה שלך הקישו 1 לשמיעת המצב של קבוצה אחרת הקישו 2 ליציאה הקש כוכבית וסולמית */
    M2889: 'M2889',
    /** לשמיעת מצב ההתרמה של קבוצה הקישו את מספר הקבוצה ולסיום הקישו #, ליצאה הקישו * וסולמית */
    M2890: 'M2890',
    /** נא הקישו את הסכום שהינך מתחייב להשיג בלי נדר ובסיום הקישו סולמית */
    M2891: 'M2891',
    /** הגדרת בהצלחה את היעד ל... */
    M2892: 'M2892',
    /** מספרך האישי אינו נמצא ברשימת הקבוצות או שכבר הוגדר יעד, שלום ותודה */
    M2893: 'M2893',
    /** הינכם מועברים להגדרות שיוך מתרימים לקבוצה..... */
    M2894: 'M2894',
    /** לשמיעת המתרימים המשויכים לקבוצה זו הקישו 1 להוספת מתרים לקבוצה הקישו 2 למחיקת מתרים מהקבוצה הקישו 3 ליציאה הקישו כוכבית וסולמית */
    M2895: 'M2895',
    /** מספרך האישי אינו נמצא ברשימת הקבוצות המתחלקות, שלום ותודה */
    M2896: 'M2896',
    /** נא הקישו את מספר המתרים להוספה ולסיום הקישו סולמית ליציאה הקישו כוכבית וסולמית */
    M2897: 'M2897',
    /** ההוספה התבצעה להוספת מספר נוסף הקישו 1 לסיום הקישו 2 */
    M2898: 'M2898',
    /** המספר שהקשת כבר נמצא ברשימת המתרימים של הקבוצה, נא הקישו שוב */
    M2899: 'M2899',
    /** ברוכים הבאים למערכת מידע משפחתי מאושרת ווצאפון מנהלים של ימות המשיח */
    M2900: 'M2900',
    /** לשמיעת ההודעות הקישו 1 , להשארת הודעה למנהל המערכת 2 , להגדרות אישיות 3 */
    M2901: 'M2901',
    /** ההודעה נשלחה למנהלים */
    M2902: 'M2902',
    /** מספר הטלפון שלכם אינו מורשה כניסה למערכת זו אנא פנו למנהל המערכת. שלום ותודה. */
    M2903: 'M2903',
    /** לניהול המערכת הקישו 4 */
    M2904: 'M2904',
    /** להפסקת או חידוש קבלת צינטוקים מהמערכת 1 , למחיקת המספר שלכם מהמערכת 2 , לפרטים ומידע נוסף על המערכת 3 */
    M2905: 'M2905',
    /** המספר שלך מוגדר שלא יקבל צנטוקים מהמערכת */
    M2906: 'M2906',
    /** המספר שלך מקבל את כל הצנטוקים וההודעות מהמערכת */
    M2907: 'M2907',
    /** המספר שלך מוגדר בהשתקה לזמן מוגבל מקבלת צנטוקים */
    M2908: 'M2908',
    /** להפסקת קבלת צנטוקים מהמערכת הקישו 1. להשתקה הצנטוקים מהמערכת זלמן מוגדר הקישו 2. לקבלת כל הצנטוקים וההודעות מהמערכת הקישו 3 */
    M2909: 'M2909',
    /** מהיום לא תקבלו צנטוקים מהמערכת */
    M2910: 'M2910',
    /** מהיום תקבלו את כל המצנטוקים וההודעות שישלחו מהמערכת */
    M2911: 'M2911',
    /** נא הקישו את מספר השעות להשתקה וסולמית לסיום, לדוגמה להשתקה לשעה הקישו 1 וסולמית להשתקה ליממה הקישו 24 וסולמית */
    M2912: 'M2912',
    /** השתקת התראות התקבלה בהצלחה */
    M2913: 'M2913',
    /** שימו לב פעולה זו תנתק את מספר הטלפון שלכם לגמרי מהמערכת ולא תוכלו יותר להכנס מטלפון זה עד שהאחראי יוסיף שוב את מספר הטלפון שוב בחזרה. אם אתם מעונינים להתנתק מהמערכת לגמרי הקישו 1. אם לא הקישו כוכבית. אם ברצונכם רק להפסיק את הצנטוקים הקישו כעת כוכבית ולאחר מכן 1 להגדרת מצב צנטוקים. */
    M2914: 'M2914',
    /** הפעולה בוטלה הנכם מוחזרים אוטומטית לתפריט קודם */
    M2915: 'M2915',
    /** המערכת ניתקה בהצלחה את הטלפון שלכם מקבוצה זו, אם ברצונכם להתחבר מחדש פנו למנהל הקבוצה . שלום ותודה. */
    M2916: 'M2916',
    /** המערכת מיודעת להעברת הודעות בין קבוצת מנויים, לכל מנוי ניתנת האפשרות להשאיר הודעה למנהלי מערכת דרך בשלוחה 2 בתפריט הראשי. לאחר השארת הודעה על ידי המנויים, מנהלי המערכת מקבלים מיידית צינטוק, וכך יודעים שעליהם להתקשר למערכת לשמוע את ההודעה שהתקבלה, ולהחליט אם להקליט מחדש את תוכן ההודעה למנוים,. אחרי שהמנהל הקליט מחדש את תוכן ההודעה, ההודעה המוקלטת על ידי המנהל תכנס לשלוחה אחת בתפריט הראשי, והמנויים יקבלו צנטוק על כך. לשמיעת אפשרויות הצינטוקים הקישו שלוש בתפריט הראשי להגדרות אישיות. מנהלי המערכת יכולים גם להקליט הודעה ישירות למערכת ולאשרה אוטומטי,. במקש ארבע בתפריט הראשי */
    M2917: 'M2917',
    /** ההודעה נוספה בהצלחה למערכת. לשליחת צנטוק לכל המנויים הקישו 1. להמשיך ללא שליחת צנטוק הקישו 2 */
    M2918: 'M2918',
    /** לאישור הודעות שהושארו עבורכם ושליחת צינטוק מיד לאחר האישור 1. להשארת הודעה וצינטוק מידי 2. לעריכת רשימת טלפונים מורשים ולקבלת צינטוק 3. לשינוי פתיחה של התפריט הראשי 4. להוספה והסרת מנהל 5 */
    M2919: 'M2919',
    /** לשמיעת הפתיח הנוכחי הקישו 1 , להקלטה מחדש הקישו 2 , לחזרה לתפריט קודם הקישו כוכבית */
    M2920: 'M2920',
    /** בהשמע האות אנא הקליטו את הפתיח של המערכת ולסיום הקישו סולמית */
    M2921: 'M2921',
    /** עדיין אין פתיח אישי למערכת */
    M2922: 'M2922',
    /** ההודעה התווספה ללא צנטוק הנכם מועברים להודעה הבאה */
    M2923: 'M2923',
    /** צנטוק נשלח למנויים. הנכם מועברים להודעה הבאה */
    M2924: 'M2924',
    /** להוספת מנהל הקישו1, להסרת מנהל הקישו 2, לשמיעת רשימת המנהלים הקישו 3, לחזרה לתפריט קודם הקישו כוכבית */
    M2925: 'M2925',
    /** סוף רשימת מנהלים */
    M2926: 'M2926',
    /** רשימת המנהלים */
    M2927: 'M2927',
    /** בנוסף יש */
    M2928: 'M2928',
    /** מנהלים */
    M2929: 'M2929',
    /** המספר אינו מוגדר כמנהל */
    M2930: 'M2930',
    /** מספר זה הוסר מהניהול, שימו לב המספר נותר מאושר לכניסה למערכת, במידת הצורך הסירו את המספר מרשימת החברים בקבוצה. */
    M2931: 'M2931',
    /** המספר כבר מוגדר כמנהל */
    M2932: 'M2932',
    /** מספר זה הוגדר כמנהל בהצלחה */
    M2933: 'M2933',
    /** לא ניתן להוסיף עוד מנהל כמות המנהלים המרבית המוגדרת עבורך היא */
    M2934: 'M2934',
    /** מנהלים שימו לב ניתן להסיר מנהל בשלוחה 2 . להגשת בקשה להחרגת כמות המנהלים ניתן , להגשת בקשה אנא צרו קשר עם שרות הלקוחות */
    M2935: 'M2935',
    /** להוספת מספר הקישו 1 , למחיקת מספר הקישו 2 , לשמיעת כל הרשימה הקישו 3 , לחזרה לתפריט קודם הקישו כוכבית */
    M2936: 'M2936',
    /** הקישו את מספר הטלפון שברצונכם להוסיף , כולל אזור חיוג וסולמית לסיום , לחזרה לתפריט קודם הקישו אפס סולמית */
    M2937: 'M2937',
    /** מספר הטלפון שהקשתם כבר קיים ברשימה , הנכם מוחזרים לתפריט קודם */
    M2938: 'M2938',
    /** אנא הקישו את מספר הטלפון שברצונכם להסיר כולל אזור חיוג וסולמית לסיום, לחזרה לתפריט קודם הקישו אפס סולמית */
    M2939: 'M2939',
    /** מספר הטלפון שהקשתם אינו קיים ברשימה , הנכם מוחזרים לתפריט קודם */
    M2940: 'M2940',
    /** חברים */
    M2941: 'M2941',
    /** סוף רשימת חברים */
    M2942: 'M2942',
    /** המספר שהקשתם לא תקין */
    M2943: 'M2943',
    /** מספר הטלפון הוסר בהצלחה מרשימת החברים בקבוצה */
    M2944: 'M2944',
    /** מספר הטלפון נוסף בהצלחה לרשימת החברים בקבוצה */
    M2945: 'M2945',
    /** אנא הקישו את מספר הטלפון של המנהל שברצונכם להוסיף כולל אזור חיוג וסולמית לסיום , לחזרה לתפריט קודם הקישו אפס סולמית */
    M2946: 'M2946',
    /** אנא הקישו את מספר הטלפון של המנהל שברצונכם להסיר כולל אזור חיוג וסולמית לסיום, לחזרה לתפריט קודם הקישו אפס סולמית */
    M2947: 'M2947',
    /** מנהל ראשי יוצר הקו */
    M2948: 'M2948',
    /** ברוכים הבאים למערכת מידע משפחתי מאושרת ווצאפון מנהלים של ימות המשיח. שימו לב לאישור ההצטרפות כחבר במערכת וקבלת צנטוקים כשיש תוכן חדש הקישו 9, תמיד תוכלו להשתיק או לבטל קבלת צנטוקים בתפריט הגדרות אישיות, כל עוד שלא אישרתם הצטרפות כחבר במערכת וקבלת צנטוקים לא תקבלו צנטוקים מהמערכת. לאישור ההצטרפות הקישו 9 */
    M2949: 'M2949',
    /** השלמתם בהצלחה את תהליך הרישום למערכת מהיום תקבלו צנטוקים בעת הוספת הודעות למערכת. תמיד תוכלו להשתיק או לבטל קבלת צנטוקים בתפריט הגדרות אישיות */
    M2950: 'M2950',
    /** מספר הטלפון שלכם כבר נרשם בהצלחה כחבר במערכת, לשינוי ההגדרות צנטוקים הכנסו לתפריט הגדרות אישיות, הנכם מוחזרים אוטומטית לתפריט הראשי */
    M2951: 'M2951',
    /** שלום, קיבלתם הזמנה להצטרפות למערכת מידע משפחתי ווצאפון מנהלים, אם ברצונכם לאשר את הצטרפותכם למערכת , חזרו למספר המופיע על הצג. המספר של המערכת הינו: */
    M2952: 'M2952',
    /** צורפתם על ידי מנהל הקבוצה שמספרו: */
    M2953: 'M2953',
    /** אם אינכם מעונינים להצטרף, אל תתיחסו להודעה זו. להצטרפות חזרו למספר. */
    M2954: 'M2954',
    /** שלום, קיבלתם הזמנה להצטרפות ולניהול מערכת מידע משפחתי ווצאפון מנהלים. אם ברצונכם לאשר את הצטרפותכם למערכת ולניהול המערכת, חזרו למספר המופיע על הצג. המספר של המערכת הינו: */
    M2955: 'M2955',
    /** יש הודעות חדשות מחכות לאישורך כמנהל */
    M2956: 'M2956',
    /** לשליחת הודעה טלפונית למספר שהוספתם על הזמנתם להצטרפות לקבוצה הקישו 1, לחזרה לתפריט קודם הקישו כוכבית */
    M2957: 'M2957',
    /** מספר הטלפון שלכם שקיבל את הזמנת ההצטרפות הינו: */
    M2958: 'M2958',
    /** ההודעה נשלחה הנכם מוחזרים לתפריט קודם */
    M2959: 'M2959',
    /** לשליחת הודעה טלפונית למספר שהוספתם על הזמנתכם להצטרפות לניהול הקבוצה הקישו 1, לחזרה לתפריט קודם הקישו כוכבית */
    M2960: 'M2960',
    /** השלמתם בהצלחה את רישומכם כמנהלים במערכת מהיום תקבלו צנטוק על כל הודעה שממתינה לאישור */
    M2961: 'M2961',
    /** להשלמת רישומכם כמנהל הקישו 8 */
    M2962: 'M2962',
    /** יש לך */
    M2963: 'M2963',
    /** הודעות ממאזינים הממתינות לאישור */
    M2964: 'M2964',
    /** . לשמיעה חוזרת הקישו 0. לאישור ההודעה הקישו 1. למחיקת ההודעה הקישו 2. לפרטי ההודעה הקישו 3. לדילוג והחלטה במועד מאוחר יותר הקישו 4. ליציאה הקישו כוכבית. */
    M2965: 'M2965',
    /** ההודעה נמחקה בהצלחה, הנכם מועברים להודעה הבאה */
    M2966: 'M2966',
    /** אין הודעות הממתינות לאישור מנהל */
    M2967: 'M2967',
    /** אין קובץ הגדרות שאלות ותשובות */
    M2968: 'M2968',
    /** אין שאלה ראשונה בקובץ הגדרות שאלות ותשובות */
    M2969: 'M2969',
    /** שאלה מספר */
    M2970: 'M2970',
    /** אנא הקש את מספר התשובה הנכונה */
    M2971: 'M2971',
    /** השאלה היא */
    M2972: 'M2972',
    /** לא הוגדר תשובה נכונה עבור שאלה זו */
    M2973: 'M2973',
    /** סיימת לענות על כל השאלות. הציון שלך הוא */
    M2974: 'M2974',
    /** לשמיעה חוזרת הקש1. לשמיעת פירוט הנקודות הקש 2. לסיום הקש 3. */
    M2975: 'M2975',
    /** קיבלת */
    M2976: 'M2976',
    /** התשובה שסימנת היא */
    M2977: 'M2977',
    /** התשובה הנכונה היא */
    M2978: 'M2978',
    /** כבר סיימת את עדכון המבחן שלך. הציון שלך הוא */
    M2979: 'M2979',
    /** סך הנקודות שקיבלת עבור המבחן */
    M2980: 'M2980',
    /** לשמיעה חוזרת הקש1 לסיום הקש 2 */
    M2981: 'M2981',
    /** לבחירתך X */
    M2982: 'M2982',
    /** תוצאות */
    M2983: 'M2983',
    /** לתוצאה */
    M2984: 'M2984',
    /** הקישו */
    M2985: 'M2985',
    /** זהו תפריט בחירת עמודה - אנא הקישו את מספר העמודה שברצונכם לשמוע בשורה שנבחרה */
    M2986: 'M2986',
    /** אירעה שגיאה בזיהוי הדיבור, אנא נסו שוב */
    M2987: 'M2987',
    /** אנא אימרו משהו לחיפוש */
    M2988: 'M2988',
    /** ביפ */
    M2989: 'M2989',
    /** שם הקובץ שהוקש, כבר קיים בשלוחה, אנא הקישו שם קובץ אחר. אם ברצונכם שהקובץ הקיים יוחלף בקובץ החדש, הקישו שוב את מספר הקובץ הקיים */
    M2990: 'M2990',
    /** אנא הקישו את מספר ההקלטה כפי שברצונכם שתשמר, ובסיום הקישו סולמית */
    M2991: 'M2991',
    /** זהו תפריט נוסף לבחירת עמודה - אנא הקישו את מספר העמודה שברצונכם לשמוע בשורה שנבחרה */
    M2992: 'M2992',
    /** מספר רשימת התפוצה שהוגדר שגוי */
    M2993: 'M2993',
    /** לתשומת לבכם כבר קיימת הקלטה לשידור ברשימת תפוצה זו, המשך יביא להחלפת ההודעה הקיימת */
    M2994: 'M2994',
    /** המערכת מבצעת חיפוש, אנא המתינו */
    M2995: 'M2995',
    /** לא נמצאו תוצאות, אנא נסו שוב */
    M2996: 'M2996',
    /** נא הקישו את קוד כתובת המייל שלכם, בסיום הקישו סולמית */
    M2997: 'M2997',
    /** נא הקישו את מספר הטלפון איתו נרשמתם המשוייך לכתובת המייל שלכם. בסיום הקישו סולמית */
    M2998: 'M2998',
    /** אנא הקישו את מספר הטלפון שאליו המערכת תחייג במקרה שהתינוק יבכה */
    M2999: 'M2999',
    /** תהילים ספרד 1 */
    M3000: 'M3000',
    /** תהילים ספרד 2 */
    M3001: 'M3001',
    /** תהילים ספרד 3 */
    M3002: 'M3002',
    /** תהילים ספרד 4 */
    M3003: 'M3003',
    /** תהילים ספרד 5 */
    M3004: 'M3004',
    /** תהילים ספרד 6 */
    M3005: 'M3005',
    /** תהילים ספרד 7 */
    M3006: 'M3006',
    /** תהילים ספרד 8 */
    M3007: 'M3007',
    /** תהילים ספרד 9 */
    M3008: 'M3008',
    /** תהילים ספרד 10 */
    M3009: 'M3009',
    /** תהילים ספרד 11 */
    M3010: 'M3010',
    /** תהילים ספרד 12 */
    M3011: 'M3011',
    /** תהילים ספרד 13 */
    M3012: 'M3012',
    /** תהילים ספרד 14 */
    M3013: 'M3013',
    /** תהילים ספרד 15 */
    M3014: 'M3014',
    /** תהילים ספרד 16 */
    M3015: 'M3015',
    /** תהילים ספרד 17 */
    M3016: 'M3016',
    /** תהילים ספרד 18 */
    M3017: 'M3017',
    /** תהילים ספרד 19 */
    M3018: 'M3018',
    /** תהילים ספרד 20 */
    M3019: 'M3019',
    /** תהילים ספרד 21 */
    M3020: 'M3020',
    /** תהילים ספרד 22 */
    M3021: 'M3021',
    /** תהילים ספרד 23 */
    M3022: 'M3022',
    /** תהילים ספרד 24 */
    M3023: 'M3023',
    /** תהילים ספרד 25 */
    M3024: 'M3024',
    /** תהילים ספרד 26 */
    M3025: 'M3025',
    /** תהילים ספרד 27 */
    M3026: 'M3026',
    /** תהילים ספרד 28 */
    M3027: 'M3027',
    /** תהילים ספרד 29 */
    M3028: 'M3028',
    /** תהילים ספרד 30 */
    M3029: 'M3029',
    /** תהילים ספרד 31 */
    M3030: 'M3030',
    /** תהילים ספרד 32 */
    M3031: 'M3031',
    /** תהילים ספרד 33 */
    M3032: 'M3032',
    /** תהילים ספרד 34 */
    M3033: 'M3033',
    /** תהילים ספרד 35 */
    M3034: 'M3034',
    /** תהילים ספרד 36 */
    M3035: 'M3035',
    /** תהילים ספרד 37 */
    M3036: 'M3036',
    /** תהילים ספרד 38 */
    M3037: 'M3037',
    /** תהילים ספרד 39 */
    M3038: 'M3038',
    /** תהילים ספרד 40 */
    M3039: 'M3039',
    /** תהילים ספרד 41 */
    M3040: 'M3040',
    /** תהילים ספרד 42 */
    M3041: 'M3041',
    /** תהילים ספרד 43 */
    M3042: 'M3042',
    /** תהילים ספרד 44 */
    M3043: 'M3043',
    /** תהילים ספרד 45 */
    M3044: 'M3044',
    /** תהילים ספרד 46 */
    M3045: 'M3045',
    /** תהילים ספרד 47 */
    M3046: 'M3046',
    /** תהילים ספרד 48 */
    M3047: 'M3047',
    /** תהילים ספרד 49 */
    M3048: 'M3048',
    /** תהילים ספרד 50 */
    M3049: 'M3049',
    /** תהילים ספרד 51 */
    M3050: 'M3050',
    /** תהילים ספרד 52 */
    M3051: 'M3051',
    /** תהילים ספרד 53 */
    M3052: 'M3052',
    /** תהילים ספרד 54 */
    M3053: 'M3053',
    /** תהילים ספרד 55 */
    M3054: 'M3054',
    /** תהילים ספרד 56 */
    M3055: 'M3055',
    /** תהילים ספרד 57 */
    M3056: 'M3056',
    /** תהילים ספרד 58 */
    M3057: 'M3057',
    /** תהילים ספרד 59 */
    M3058: 'M3058',
    /** תהילים ספרד 60 */
    M3059: 'M3059',
    /** תהילים ספרד 61 */
    M3060: 'M3060',
    /** תהילים ספרד 62 */
    M3061: 'M3061',
    /** תהילים ספרד 63 */
    M3062: 'M3062',
    /** תהילים ספרד 64 */
    M3063: 'M3063',
    /** תהילים ספרד 65 */
    M3064: 'M3064',
    /** תהילים ספרד 66 */
    M3065: 'M3065',
    /** תהילים ספרד 67 */
    M3066: 'M3066',
    /** תהילים ספרד 68 */
    M3067: 'M3067',
    /** תהילים ספרד 69 */
    M3068: 'M3068',
    /** תהילים ספרד 70 */
    M3069: 'M3069',
    /** תהילים ספרד 71 */
    M3070: 'M3070',
    /** תהילים ספרד 72 */
    M3071: 'M3071',
    /** תהילים ספרד 73 */
    M3072: 'M3072',
    /** תהילים ספרד 74 */
    M3073: 'M3073',
    /** תהילים ספרד 75 */
    M3074: 'M3074',
    /** תהילים ספרד 76 */
    M3075: 'M3075',
    /** תהילים ספרד 77 */
    M3076: 'M3076',
    /** תהילים ספרד 78 */
    M3077: 'M3077',
    /** תהילים ספרד 79 */
    M3078: 'M3078',
    /** תהילים ספרד 80 */
    M3079: 'M3079',
    /** תהילים ספרד 81 */
    M3080: 'M3080',
    /** תהילים ספרד 82 */
    M3081: 'M3081',
    /** תהילים ספרד 83 */
    M3082: 'M3082',
    /** תהילים ספרד 84 */
    M3083: 'M3083',
    /** תהילים ספרד 85 */
    M3084: 'M3084',
    /** תהילים ספרד 86 */
    M3085: 'M3085',
    /** תהילים ספרד 87 */
    M3086: 'M3086',
    /** תהילים ספרד 88 */
    M3087: 'M3087',
    /** תהילים ספרד 89 */
    M3088: 'M3088',
    /** תהילים ספרד 90 */
    M3089: 'M3089',
    /** תהילים ספרד 91 */
    M3090: 'M3090',
    /** תהילים ספרד 92 */
    M3091: 'M3091',
    /** תהילים ספרד 93 */
    M3092: 'M3092',
    /** תהילים ספרד 94 */
    M3093: 'M3093',
    /** תהילים ספרד 95 */
    M3094: 'M3094',
    /** תהילים ספרד 96 */
    M3095: 'M3095',
    /** תהילים ספרד 97 */
    M3096: 'M3096',
    /** תהילים ספרד 98 */
    M3097: 'M3097',
    /** תהילים ספרד 99 */
    M3098: 'M3098',
    /** תהילים ספרד 100 */
    M3099: 'M3099',
    /** תהילים ספרד 101 */
    M3100: 'M3100',
    /** תהילים ספרד 102 */
    M3101: 'M3101',
    /** תהילים ספרד 103 */
    M3102: 'M3102',
    /** תהילים ספרד 104 */
    M3103: 'M3103',
    /** תהילים ספרד 105 */
    M3104: 'M3104',
    /** תהילים ספרד 106 */
    M3105: 'M3105',
    /** תהילים ספרד 107 */
    M3106: 'M3106',
    /** תהילים ספרד 108 */
    M3107: 'M3107',
    /** תהילים ספרד 109 */
    M3108: 'M3108',
    /** תהילים ספרד 110 */
    M3109: 'M3109',
    /** תהילים ספרד 111 */
    M3110: 'M3110',
    /** תהילים ספרד 112 */
    M3111: 'M3111',
    /** תהילים ספרד 113 */
    M3112: 'M3112',
    /** תהילים ספרד 114 */
    M3113: 'M3113',
    /** תהילים ספרד 115 */
    M3114: 'M3114',
    /** תהילים ספרד 116 */
    M3115: 'M3115',
    /** תהילים ספרד 117 */
    M3116: 'M3116',
    /** תהילים ספרד 118 */
    M3117: 'M3117',
    /** תהילים ספרד 119 */
    M3118: 'M3118',
    /** תהילים ספרד 120 */
    M3119: 'M3119',
    /** תהילים ספרד 121 */
    M3120: 'M3120',
    /** תהילים ספרד 122 */
    M3121: 'M3121',
    /** תהילים ספרד 123 */
    M3122: 'M3122',
    /** תהילים ספרד 124 */
    M3123: 'M3123',
    /** תהילים ספרד 125 */
    M3124: 'M3124',
    /** תהילים ספרד 126 */
    M3125: 'M3125',
    /** תהילים ספרד 127 */
    M3126: 'M3126',
    /** תהילים ספרד 128 */
    M3127: 'M3127',
    /** תהילים ספרד 129 */
    M3128: 'M3128',
    /** תהילים ספרד 130 */
    M3129: 'M3129',
    /** תהילים ספרד 131 */
    M3130: 'M3130',
    /** תהילים ספרד 132 */
    M3131: 'M3131',
    /** תהילים ספרד 133 */
    M3132: 'M3132',
    /** תהילים ספרד 134 */
    M3133: 'M3133',
    /** תהילים ספרד 135 */
    M3134: 'M3134',
    /** תהילים ספרד 136 */
    M3135: 'M3135',
    /** תהילים ספרד 137 */
    M3136: 'M3136',
    /** תהילים ספרד 138 */
    M3137: 'M3137',
    /** תהילים ספרד 139 */
    M3138: 'M3138',
    /** תהילים ספרד 140 */
    M3139: 'M3139',
    /** תהילים ספרד 141 */
    M3140: 'M3140',
    /** תהילים ספרד 142 */
    M3141: 'M3141',
    /** תהילים ספרד 143 */
    M3142: 'M3142',
    /** תהילים ספרד 144 */
    M3143: 'M3143',
    /** תהילים ספרד 145 */
    M3144: 'M3144',
    /** תהילים ספרד 146 */
    M3145: 'M3145',
    /** תהילים ספרד 147 */
    M3146: 'M3146',
    /** תהילים ספרד 148 */
    M3147: 'M3147',
    /** תהילים ספרד 149 */
    M3148: 'M3148',
    /** תהילים ספרד 150 */
    M3149: 'M3149',
    /** תהילים ספרד 150 */
    M3150: 'M3150',
    /** פיטום הקטורת */
    M3151: 'M3151',
    /** עד כה השתתפו בחלוקת פיטום הקטורת */
    M3152: 'M3152',
    /** משתתפים */
    M3153: 'M3153',
    /** תזכו למצוות */
    M3154: 'M3154',
    /** אנא בחרו את כמות פרקי התהילים אותם ברצונכם לקרא, ולסיום הָקישו סולמית */
    M3155: 'M3155',
    /** אנא הקישו את כמות הפרקים וסולמית לסיום */
    M3156: 'M3156',
    /** . לשינוי סוג המערכת. כך שכולם יוכלו להכנס הקישו 1. לשינוי שהכניסה תהיה למורשים בלבד הקישו 2. להשארת המצב הקיים וחזרה לתפריט הקישו 3 */
    M3157: 'M3157',
    /** שינוי סוג הכניסה בוצע בהצלחה */
    M3158: 'M3158',
    /** נא הקישו את מספר המתרים למחיקה ולסיום הקישו סולמית ליציאה הקישו כוכבית וסולמית */
    M3160: 'M3160',
    /** המספר שהקשת לא נמצא ברשימת המתרימים של הקבוצה נא הקישו שנית */
    M3161: 'M3161',
    /** מחיקת המתרים הסתיימה בהצלחה */
    M3162: 'M3162',
    /** לא הוגדר סוג מעקב לימוד */
    M3200: 'M3200',
    /** למעבר כעת לעדכון על הדפים שמחכים לעדכון הקישו 1, למעבר לעדכון על הדף של היום הקישו 2, לבחירת דפים אחרים לעדכון הקישו 3 לשמיעת היסטורייה וסטטיסטיקות הקישו 4 */
    M3201: 'M3201',
    /** מספר הדפים שלא למדת ממתי שהצטרפת למעקב הוא */
    M3202: 'M3202',
    /** למעבר לעדכון לדף הבא הקישו 1, לסיום הקישו 2 */
    M3203: 'M3203',
    /** להקלטת תזכרות הערה וכדו', הקישו 1, לסיום הקישו 2 */
    M3204: 'M3204',
    /** עודכן בהצלחה שלמדתם את עמוד א בדף... */
    M3205: 'M3205',
    /** עודכן בהצלחה שלמדתם את עמוד ב בדף... */
    M3206: 'M3206',
    /** מעודכן שלמדתם את כל הדף, לאישור ויציאה הקישו 1 לשינוי העדכון הקישו 2 להוספת תזכורת הקישו 3 ליציאה הקישו 4 */
    M3207: 'M3207',
    /** מעודכן שלמדתם רק את עמוד א לאישור והמשך הקישו 1, לשינוי העדכון הקישו 2 להוספת תזכורת הקישו 3 ליציאה הקישו כוכבית וסולמית */
    M3208: 'M3208',
    /** מעודכן שלמדתם רק את עמוד ב לאישור והמשך הקישו 1, לשינוי העדכון הקישו 2 להוספת תזכורת הקישו 3 ליציאה הקישו כוכבית וסולמית */
    M3209: 'M3209',
    /** לעדכון שלמדתם גם את עמוד ב הקישו 1 לעדכון שלא למדתם את עמוד א הקישו 2, למחיקת עדכון הלימוד של עמוד א הקישו 3 להוספת תזכורת הקישו 4 להמשך ללא עדכון הקישו 5 ליציאה הקישו כוכבית וסולמית */
    M3210: 'M3210',
    /** לעדכון שלמדתם גם את עמוד א הקישו 1 לעדכון שלא למדתם את עמוד ב הקישו 2, למחיקת עדכון הלימוד של עמוד ב הקישו 3 להוספת תזכורת הקישו 4 להמשך ללא עדכון הקישו 5 ליציאה הקישו כוכבית וסולמית */
    M3211: 'M3211',
    /** מחקתם בהצלחה את עדכון לימוד עמוד א בדף... */
    M3212: 'M3212',
    /** מחקתם בהצלחה את עדכון לימוד עמוד ב בדף... */
    M3213: 'M3213',
    /** נא הקליטו את התזכורת ולסיום הקישו סולמית */
    M3214: 'M3214',
    /** להוספת תזכורת מוקלטת הקישו 1 לעדכון שלא למדתם את כל דף זה הקישו 2 למחיקת עדכון הלימוד לכל דף זה הקישו 3, לעדכון שלא למדתם רק את עמוד א הקישו 4, לעדכון שלא למדתם רק את עמוד ב הקישו 5, למחיקת עדכון הלימוד של עמוד א הקישו 6 למחיקת עדכון הלימוד של עמוד ב הקישו 7 להמשך ללא שינוי הקישו 8 ליציאה הקישו כוכבית וסולמית */
    M3215: 'M3215',
    /** מחקתם בהצלחה את עדכון הלימוד של עמוד א ועמוד ב בדף... */
    M3216: 'M3216',
    /** הקלטת התזכורת הסתיימה בהצלחה */
    M3217: 'M3217',
    /** יש כבר תזכורת מוקלטת על הדף, לשמיעת התזכורת המוקלטת הקישו 1 להמשך הקישו 2 להקלטה מחדש הקישו 3 למחיקת התזכורת הקישו 4 ליציאה הקישו כוכבית וסולמית */
    M3218: 'M3218',
    /** הדף היומי של היום הוא */
    M3219: 'M3219',
    /** התזכורת נמחקה בהצלחה */
    M3220: 'M3220',
    /** הינכם מועברים לעדכון על דף... */
    M3221: 'M3221',
    /** במחזור זה נלמדו עד היום */
    M3222: 'M3222',
    /** דפים */
    M3223: 'M3223',
    /** מספר הדפים שלמדת ממתי שהצטרפת למעקב הוא */
    M3224: 'M3224',
    /** מספר הדפים שעדיין לא מעודכנים שלמדת הוא */
    M3225: 'M3225',
    /** אין דפים חסרים */
    M3226: 'M3226',
    /** עדיין לא הגדרת ממתי המערכת תעקוב אחרי הלימוד שלך להגדיר שיעקוב מהדף הראשון של המחזור הקישו 1 להגדיר שיעקוב מהדף של היום הקישו 2 להגדיר שיעקוב מתחילת המסכת הנוכחית הקישו 3, לבחירת דף על פי מסכת הקישו 4, לבחירת דף על פי תאריך הקישו 5, ליציאה הקישו כוכבית וסולמית */
    M3227: 'M3227',
    /** הגדרת בהצלחה שהמערכת תעקוב מהדף הראשון במחזור */
    M3228: 'M3228',
    /** הגדרת בהצלחה שהמערכת תעקוב מהדף של היום */
    M3229: 'M3229',
    /** לאישור הקישו 1, לתיקון הקישו 2 */
    M3230: 'M3230',
    /** לעדכון על הדף של היום הקישו 1 לעדכון על הימים האחרונים הקישו 2 לשמיעת הדפים מתחילת המחזור הקישו 3 לבחירת דף לעדכון הקישו 4 ליצאה הקישו כוכבית וסולמית */
    M3231: 'M3231',
    /** היסטורייה מלאה עדיין לא קיים נא לבחור שוב */
    M3232: 'M3232',
    /** לבחירת דף מהמסכת הנוכחית הקישו 1 לבחירת דף על פי התאריך הקישו 2 לבחירת דף ממסכת אחרת הקישו 3 ליצאה הקישו כוכבית וסולמית */
    M3233: 'M3233',
    /** עמודים */
    M3234: 'M3234',
    /** שהם */
    M3235: 'M3235',
    /** נא הקישו את התאריך בשמונה ספרות שני ספרות ליום שני ספרות לחודש וארבע ספרות לשנה ולסיום הקישו סולמית לדוגמה לתאריך ג תשרי תשעט הקישו 03015779 לחודש אדר א הקישו 13 לחודש אדר ב הקישו 14 */
    M3236: 'M3236',
    /** הדף היומי שבחרת נמצא במחזור אחר מהמחזור הנוכחי נא בחר שוב */
    M3237: 'M3237',
    /** נא הקישו את מספר המסכת בשלוש ספרות ספרות ולסיום הקישו סולמית, הספרה הראשונה מסמלת את הסדר והשניה את המסכת, לדוגמה למסכת שבת הקישו 201 */
    M3238: 'M3238',
    /** מספר המסכת שהוקש שגוי נסו שנית */
    M3239: 'M3239',
    /** נא הקישו את מספר הדף ולסיום הקישו סולמית, לדוגמה לדף ב הקישו 2 וסולמית */
    M3240: 'M3240',
    /** מספר הדף שהוקש שגוי נסו שנית */
    M3241: 'M3241',
    /** עודכן בהצלחה שלא למדתם את עמוד א' ועמוד ב' בדף */
    M3242: 'M3242',
    /** עודכן בהצלחה שלא למדתם עמוד א' בדף */
    M3243: 'M3243',
    /** עודכן בהצלחה שלא למדתם עמוד ב' בדף */
    M3244: 'M3244',
    /** מעודכן שלא למדתם את כל הדף, לאישור והמשך הקישו 1 לשינוי העדכון הקישו 2 להוספת תזכורת הקישו 3 ליציאה הקישו כוכבית וסולמית */
    M3245: 'M3245',
    /** לעדכון שלמדתם את כל הדף הקישו 1 למחיקת העדכון מכל הדף הקישו 2, */
    M3246: 'M3246',
    /** מחקתם בהצלחה את העדכון שלא למדתם את עמוד א בדף */
    M3247: 'M3247',
    /** מחקתם בהצלחה את העדכון שלא למדתם את עמוד ב בדף */
    M3248: 'M3248',
    /** מעקב לימוד */
    M3249: 'M3249',
    /** במערכת מעודכן ש */
    M3250: 'M3250',
    /** עמוד א */
    M3251: 'M3251',
    /** עמוד ב */
    M3252: 'M3252',
    /** מעודכן שלמדתם */
    M3253: 'M3253',
    /** מעודכן שלא למדתם */
    M3254: 'M3254',
    /** לא מעודכן כלום */
    M3255: 'M3255',
    /** לאישור והמשך הקישו 1, למעבר לתזכורת הקישו 2, לשינוי עמוד א' הקישו 3, לשינוי עמוד ב' הקישו 4, ליציאה הקישו כוכבית וסולמית */
    M3256: 'M3256',
    /** לעדכון שלא למדתם את עמוד א הקישו 1, למחיקת העדכון הלימוד בלבד הקישו 2, להמשך לעמוד ב ללא עדכון הקישו 3, למעבר לתזכורת על הדף הקישו 4, להמשך ללא כל עדכון הקישו 5, ליציאה הקישו כוכבית וסולמית */
    M3257: 'M3257',
    /** לעדכון שלמדתם את עמוד א הקישו 1, לעדכון שלא למדתם הקישו 2, להמשך לעמוד ב ללא עדכון הקישו 3, למעבר לתזכורת על הדף הקישו 4, להמשך ללא עדכון הקישו 5, ליציאה הקישו כוכבית וסולמית */
    M3258: 'M3258',
    /** לעדכון שכן למדתם את עמוד א הקישו 1, למחיקת העדכון שלא למדתם בלבד הקישו 2, להמשך לעמוד ב ללא עדכון הקישו 3, למעבר לתזכורת על הדף הקישו 4, להמשך ללא כל עדכון הקישו 5, ליציאה הקישו כוכבית וסולמית */
    M3259: 'M3259',
    /** לעדכון שלא למדתם את עמוד ב הקישו 1, למחיקת העדכון הלימוד בלבד הקישו 2, למעבר לעמוד א ללא עדכון הקישו 3, למעבר לתזכורת על הדף הקישו 4, להמשך ללא כל עדכון הקישו 5, ליציאה הקישו כוכבית וסולמית */
    M3260: 'M3260',
    /** לעדכון שלמדתם את עמוד ב הקישו 1, לעדכון שלא למדתם הקישו 2, למעבר לעמוד א ללא עדכון הקישו 3, למעבר לתזכורת על הדף הקישו 4, להמשך ללא עדכון הקישו 5, ליציאה הקישו כוכבית וסולמית */
    M3261: 'M3261',
    /** לעדכון שכן למדתם את עמוד ב הקישו 1, למחיקת העדכון שלא למדתם בלבד הקישו 2, למעבר לעמוד א ללא עדכון הקישו 3, למעבר לתזכורת על הדף הקישו 4, להמשך ללא כל עדכון הקישו 5, ליציאה הקישו כוכבית וסולמית */
    M3262: 'M3262',
    /** הגדרת בהצלחה שהמערכת תעקוב אחריך מדף ב' במסכת */
    M3263: 'M3263',
    /** אנא הקישו את המספר המופיע במונה */
    M3300: 'M3300',
    /** הנתונים נקלטו בהצלחה, צריכתך החודש היא, - */
    M3301: 'M3301',
    /** יחידות, הסכום לתשלום הוא, - */
    M3302: 'M3302',
    /** שקלים, תודה רבה */
    M3303: 'M3303',
    /** יחידות, התשלום הקבוע הוא - */
    M3304: 'M3304',
    /** הסכום לתשלום הוא */
    M3305: 'M3305',
    /** שקלים, הסכום הכולל לתשלום הוא, - */
    M3306: 'M3306',
    /** אין שיוך לקבוצה מזיהוי זה */
    M3307: 'M3307',
    /** מספר הקבוצה שלך הוא */
    M3308: 'M3308',
    /** שם הקבוצה שלך הוא */
    M3309: 'M3309',
    /** כמות החברים בקבוצה שלך */
    M3310: 'M3310',
    /** בקבוצה שלך עדיין */
    M3311: 'M3311',
    /** חברים שעדיין לא עודכנו כפעילים */
    M3312: 'M3312',
    /** החברים שאינם פעילים הם */
    M3313: 'M3313',
    /** החברים הפעילים הם */
    M3314: 'M3314',
    /** כל החברים בקבוצה שלך פעילים */
    M3315: 'M3315',
    /** סוף רשימת חברים */
    M3316: 'M3316',
    /** לא נִיתַּן לעדכן מספר נמוך מהמספר האחרון שעודכן. */
    M3318: 'M3318',
    /** הסכום לתשלום הוא */
    M3319: 'M3319',
    /** לחזרה למיקום האחרון אליו האזנתם בתפריט זה, הקישו 1, להמשך ומעבר לתפריט, הקישו 2 או המתינו */
    M3320: 'M3320',
    /** לכתיבת הודעה, הקישו 1. לאמירת ההודעה, הקישו 2 */
    M3321: 'M3321',
    /** כבר עדכנתם בחודש זה */
    M3322: 'M3322',
    /** אנא הקישו את השעה הרצויה ב-4 ספרות. שעה ב2 ספרות ודקה ב2 ספרות. לדוגמה לשעה שתיים וחצי אחר הצהריים יש להקיש 1430 */
    M3323: 'M3323',
    /** אנא הקישו את התאריך הרצוי ב-8 ספרות. יום ב-2 ספרות, חודש ב-2 ספרות ושנה ב-4 ספרות. לדוגמה, לתאריך א אלול תשפב יש להקיש 01125782 לתאריך הראשון לינואר 2022 יש להקיש 01012022. */
    M3324: 'M3324',
    /** מספרכם נוסף בהצלחה לרשימת הצנתוקים למשך הזמן שהגדרתם */
    M3325: 'M3325',
    /** אנא הקישו את כמות הימים הרצויה וסולמית לסיום */
    M3326: 'M3326',
    /** אנא הקישו מספר השעות הרצוי וסולמית לסיום */
    M3327: 'M3327',
    /** לבחירת זמן לפי שעות הקישו 1, לבחירת זמן לפי ימים הקישו 2, לבחירת זמן מסוים הקישו 3 */
    M3328: 'M3328',
    /** להוספת מספרכם לקבלת צנתוקים ליום הנוכחי הקישו 1, להוספה לשבוע הנוכחי הקישו 2, לבחירת זמן אחר הקישו 3 */
    M3329: 'M3329',
    /** מספר הטלפון לא מזוהה במערכת, נא התקשרו ממספר מזוהה */
    M3330: 'M3330',
    /** לא הוגדרה רשימת צינטוקים */
    M3331: 'M3331',
    /** להצטרפות לרשימת הצינתוקים הקישו 1 להסרה מרשימת הצינתוקים הקישו 2 להשתקת צינתוקים עד לזמן מסוים הקישו 3, ליציאה הקישו כוכבית וסולמית */
    M3332: 'M3332',
    /** מספרכם כבר מופיע ברשימת הצינתוקים */
    M3333: 'M3333',
    /** מספר הטלפון שלכם נוסף בהצלחה לרשימת הצינתוקים */
    M3334: 'M3334',
    /** מספרכם לא מופיע ברשימת הצינתוקים */
    M3335: 'M3335',
    /** מספר הטלפון שלכם נמחק בהצלחה מרשימת הצינתוקים */
    M3336: 'M3336',
    /** להפעלת צינתוק הקישו 1, למחיקת מספר מרשימת הצינתוקים הקישו 2, לחסימת מספר מרשימת הצינתוקים הקישו 3, לאיפוס כל רשימת הצינתוקים הקישו 4, ליציאה הקישו כוכבית וסולמית */
    M3337: 'M3337',
    /** הצינתוק הופעל בהצלחה */
    M3338: 'M3338',
    /** נא הקישו את המספר למחיקה ובסיום הקישו סולמית */
    M3339: 'M3339',
    /** המספר נמחק בהצלחה מרשימת הצינתוקים */
    M3340: 'M3340',
    /** המספר שהקשתם לא מופיע ברשימת הצינתוקים */
    M3341: 'M3341',
    /** שימו לב לאחר האיפוס לא ניתן יהיה לשחזר את המספרים האם הינכם בטוחים? לאישור האיפוס הקישו 1 לביטול ויציאה הקישו 2 */
    M3342: 'M3342',
    /** איפוס רשימת הצינתוקים הסתיים בהצלחה */
    M3343: 'M3343',
    /** לא מוגדר שלוחה להעברה */
    M3344: 'M3344',
    /** לשמיעת ההודעה הקישו אחת. לאישור הקישו שתיים או סולמית. להקלטה מחדש הקישו שלוש. להמשך הקלטה הקישו ארבע */
    M3345: 'M3345',
    /** אנא הקישו את התאריך הלועזי של השידור שהנכם הולכים להקליט. להיום הקישו 00 וסולמית,למחר הקישו 99 וסולמית. לתאריך מחודש זה הקישו את התאריך בחודש וסולמית. לדוגמא לראשון בחודש הנוכחי הקישו 01 וסולמית, ל29 בחודש הנוכחי הקישו 29 וסולמית. לתאריך מחודש אחר הקישו יום וחודש ב4 ספרות לדוגמא לראשון לינואר הקישו 0101 וסולמית. לתאריך משנה אחרת הקישו יום חודש ושנה ב6 ספרות לדוגמא לראשון בינואר 2021 הקישו 010121. ליציאה הקישו כוכבית וסולמית */
    M3350: 'M3350',
    /** כמות הספרות שהקשתם אינה תואמת */
    M3351: 'M3351',
    /** התאריך לא חוקי */
    M3352: 'M3352',
    /** לאישור הקישו 1. לתיקון הקישו 2 */
    M3353: 'M3353',
    /** אנא הקישו את זמן השידור ב4 ספרות לדוגמא לשעה 8 וחצי בערב הקישו 2030 */
    M3354: 'M3354',
    /** בשעה */
    M3355: 'M3355',
    /** ו... */
    M3356: 'M3356',
    /** דקות */
    M3357: 'M3357',
    /** אם ברצונכם להגדיר כי ההקלטה תשמר ותכנס גם במידה ותנתקו את השיחה באמצע הקישו 1. אם ברצונכם להגדיר כי ההקלטה תשמר רק לאחר סיום ההקלטה ואישורה על ידכם הקישו 2 */
    M3358: 'M3358',
    /** ההקלטה תשמר ותכנס גם במידה ותנתקו את השיחה באמצע */
    M3359: 'M3359',
    /** ההקלטה תשמר רק לאחר סיום ההקלטה ואישורה על ידכם */
    M3360: 'M3360',
    /** אנא הקליטו את השידור שלכם לאחר השמע הצליל. לסיום או עצירה הקישו סולמית */
    M3361: 'M3361',
    /** . ההקלטה נעצרה. להמשך ההקלטה הקישו 1. לשמיעת ההקלטה שהוקלטה עד עכשיו הקישו 2. לאישור ההקלטה הקישו 3. להקלטת הכל מחדש הקישו 4. לבטול ההקלטה ויציאה הקישו 5 */
    M3362: 'M3362',
    /** ההקלטה ממשיכה מיד לאחר השמע הצליל */
    M3363: 'M3363',
    /** ההקלטה מבוטלת */
    M3364: 'M3364',
    /** שימו לב אפשרות השמעה כאן הינה מקובץ 199 ומטה בלבד */
    M3365: 'M3365',
    /** לשמיעת השיר הבא בגרסא ווקאלית, הקישו אחת או המתינו. להמשך לשיר הבא בגרסא רגילה, הקישו 2 . */
    M3366: 'M3366',
    /** השידור נקלט בהצלחה, אורך השידור */
    M3367: 'M3367',
    /** שעות */
    M3368: 'M3368',
    /** ו... */
    M3369: 'M3369',
    /** דקות */
    M3370: 'M3370',
    /** זמן הפעלת השידור */
    M3371: 'M3371',
    /** ביום */
    M3372: 'M3372',
    /** היום */
    M3373: 'M3373',
    /** בהצלחה */
    M3374: 'M3374',
    /** הנכם מועברים להפעלת השיעור האחרון, עד זמן השיעור הבא */
    M3375: 'M3375',
    /** השידור חי מתחיל, מיד מתחברים */
    M3376: 'M3376',
    /** להרמת אצבע הקישו 1. לביטול הרמת אצבע הקישו 2 */
    M3377: 'M3377',
    /** הרמת אצבע דווחה */
    M3378: 'M3378',
    /** ביטול הרמת האצבע דווחה */
    M3379: 'M3379',
    /** יש לך... */
    M3380: 'M3380',
    /** קבצים להמרה לטקסט */
    M3381: 'M3381',
    /** להפעלה הקישו 1. לביטול הקישו 2 */
    M3382: 'M3382',
    /** השידור יחל מיד לאחר השמע הצליל */
    M3383: 'M3383',
    /** להפעלת קובץ משלוחת קבצי ניהול חדר ועידה הקישו אחת. להפעלת קובץ אחר מהמערכת הקישו שתים */
    M3384: 'M3384',
    /** שלוחת קבצי ניהול המערכת, נמצאת בתיקיית DialConfAdminFiles, מתחת לשלוחה הראשית. אנא הקישו את מספר הקובץ וסולמית לסיום */
    M3385: 'M3385',
    /** אנא הקישו את כתובות המלאה של הקובץ כאשר בין תיקיה לתיקיה הקיש כוכבית, בסיום הקש סולמית. לדוגמא לקובץ 000 משלוחה 1/1. הקישו 1 כוכבית 1 כוכבית 000 וסולמית */
    M3386: 'M3386',
    /** הקובץ לא קיים */
    M3387: 'M3387',
    /** הוחזרתם לחדר הועידה */
    M3388: 'M3388',
    /** אנא המתינו */
    M3389: 'M3389',
    /** כל המקומות בחדרי הועידה תפוסים כעת. אנא נסו שנית בעוד כמה דקות */
    M3390: 'M3390',
    /** אנא הקישו את מספר הטלפון שברצונכם לשתף */
    M3391: 'M3391',
    /** השיתוף בוצע בהצלחה */
    M3392: 'M3392',
    /** הקשת תשובה מספר */
    M3393: 'M3393',
    /** לאישור התשובה הקישו 7. לתיקון התשובה הקישו 9 */
    M3394: 'M3394',
    /** הנך ממשיך את המבחן מהנקודה בה עצרת */
    M3395: 'M3395',
    /** סיימת לענות על כל השאלות */
    M3396: 'M3396',
    /** המערכת זיהתה כי לא הוקשה בחירה פעמים רבות. ולכן, הנכם מתבקשים להקיש על מקש כל שהוא, בכדי לאמת שהשיחה עדיין פעילה. אם לא תקישו על מקש כל שהוא, השיחה תנותק אוטומטית. אנא הקישו כעת על מקש כל שהוא, בכדי להמשיך בשיחה */
    M3397: 'M3397',
    /** שימו לב, לבקשתכם, לאחר הודעה זו שיר זה ישלח להמרה. לדילוג על ההודעה ושליחת השיר כעת, הקישו על כל מקש. מפני שזו הפעם הראשונה שמתבצעת בקשת המרה לשיר זה, הפעולה צפויה לארוך כמה דקות, תוכלו להמתין על הקו ובסיום הפעולה לשמוע מיד את השיר בגרסא ווקאלית, או לחילופין, תוכלו לנתק ולחייג שוב בעוד כמה דקות */
    M3398: 'M3398',
    /** המרת השיר לואקרי הסתיימה בהצלחה. מייד תשמעו את השיר בגירסא וואקאלית */
    M3399: 'M3399',
    /** אין שיוך קמפיין */
    M3400: 'M3400',
    /** נתרמו עד עכשיו */
    M3401: 'M3401',
    /** מתוך יעד של */
    M3402: 'M3402',
    /** מתוך יעד בונוס של */
    M3403: 'M3403',
    /** על ידי */
    M3404: 'M3404',
    /** תורמים שונים */
    M3405: 'M3405',
    /** שקלים */
    M3406: 'M3406',
    /** יורו */
    M3407: 'M3407',
    /** דולר */
    M3408: 'M3408',
    /** שגיאה בקבלת תשובה מהשרת */
    M3409: 'M3409',
    /** מספרכם אינו ראשיי להרשם, לבירורים, פנו לאחראי */
    M3410: 'M3410',
    /** נרשמתם בהצלחה - שלום ותודה */
    M3411: 'M3411',
    /** תת קמפיין - נתרמו עד עכשיו */
    M3412: 'M3412',
    /** מתוך תת יעד של */
    M3413: 'M3413',
    /** בקמפיין הראשי נתרמו */
    M3414: 'M3414',
    /** אנא הקישו את מספר המתרים וסולמית לסיום, לשמיעת מצב קמפיין ראשי ומתרימים הקישו סולמית , ליציאה הקישו כוכבית וסולמית */
    M3415: 'M3415',
    /** בקמפיין של */
    M3416: 'M3416',
    /** מספר מתרים: */
    M3417: 'M3417',
    /** אנא בחר סיסמת מנהל, אותה תצטרכו להקיש כאשר תרצו להפעיל את חדר הועידה בנוסף לקוד החדר */
    M3500: 'M3500',
    /** נא בחרו את סוג חדר הועידה, לברירת המחדל - שבו כל התלמידים נכנסים בהשתק, ויכולים להקיש במהלך השידור על כוכבית אחת עמ לדבר ושוב כוכבית אחת עמ להשתיק הקישו 1, לחדר ועידה שהתלמידים נכנסים במצב דיבור ויכולים להשתיק בהקשה על כוכבית 1, הקישו 2, לחדר ועידה שכולם נכנסים בהשתקה והמנהל יכול לבטל את ההשתקה ולעשות השתקה עי הקשה על כוכבית 0, הקישו 3, לחדר ועידה שהתלמידים נמצאים על השתק ואין אפשרות לשנות, הקישו 4. */
    M3501: 'M3501',
    /** החדר נפתח בהצלחה, מייד תקבלו קוד חדר ועידה, את הקוד הזה, אתם מקישים בכדי להינס לחדר שלכם, וכן התלמידים מקישים את הקוד הזה */
    M3502: 'M3502',
    /** הקוד שלכם הוא */
    M3503: 'M3503',
    /** לשמיעת הקוד פעם נוספת הקישו 1, להמשך הקישו 2 */
    M3504: 'M3504',
    /** להקלטה כעת פתיח אותו ישמעו התלמידים לפני הכניסה לחדר הועידה הקישו 1, ליציאה הקישו 2 */
    M3505: 'M3505',
    /** לאחר הצליל נא הקליטו את הפתיח ולסיום הקישו סולמית */
    M3506: 'M3506',
    /** הקלטת הפתיח הסתיימה בהצלחה */
    M3507: 'M3507',
    /** פתיחת חדר ועידה */
    M3508: 'M3508',
    /** להפעלת צינתוק על פתיחת חדר הוועידה, הקישו 1, להמשך ללא צינתוק, הקישו 2 או המתינו */
    M3509: 'M3509',
    /** הצינתוק ישלח לרישימה המוגדרת מייד בכניסתכם לחדר הוועידה */
    M3510: 'M3510',
    /** הצינתוק על הפעלת חדר הוועידה נשלח כעת */
    M3511: 'M3511',
    /** שליחת הצינתוק על הפעלת חדר הוועידה, נכשלה, אנא בדקו את הגדרות המערכת */
    M3512: 'M3512',
    /** אנא הקישו את המספר הרצוי ובסיום סולמית */
    M3513: 'M3513',
    /** המספר שהוקש אינו קיים במערכת. */
    M3514: 'M3514',
    /** להקשה מחדש הקישו אחת או המתינו, להגרלת מספר אקראי הקישו שתיים ליציאה הקישו שלוש. */
    M3515: 'M3515',
    /** הקוד שהוגרל הוא */
    M3516: 'M3516',
    /** לא הוגדר מספר חנות */
    M3520: 'M3520',
    /** מספר החנות שהוגדר לא קיים */
    M3521: 'M3521',
    /** סיסמת המוכר לחנות שהוגדרה בשלוחה אינה תקינה */
    M3522: 'M3522',
    /** נא הקישו את סיסמת הכניסה לחנות ולסיום הקישו סולמית */
    M3523: 'M3523',
    /** סיסמת החנות שהקשתם אינה תקינה */
    M3524: 'M3524',
    /** החנות סגורה כעת, שלום ותודה */
    M3525: 'M3525',
    /** נראה שעדיין לא נרשמתם למערכת המכירות, כדי לרכוש באחד מכל החניות של המערכת יש להירשם בהרשמה חד פעמית, תוכלו להירשם כאן בטלפון והטלפון שממנו התקשרתם ייכנס למערכת בתור הטלפון של החשבון, להרשמה כעת הקישו 1, ליציאה הקישו 2 */
    M3526: 'M3526',
    /** ההרשמה נכשלה, יכול להיות שמספר הטלפון כבר רשום כשם משתמש, או שמספר הטלפון כבר נמצא במערכת על שם משתמש אחר, נא בדקו את הפרטים ונסו שוב */
    M3527: 'M3527',
    /** שגיאה כללית */
    M3528: 'M3528',
    /** נא הקישו את סיסמתכם האישית ולסיום הקישו סולמית, אם שכחתם את הסיסמה הקישו 0 וסולמית על מנת לשחזר את הסיסמה */
    M3529: 'M3529',
    /** ניכר שזוהי הפעם הראשונה שהינכם נכנסים לחנות זו, מייד תעברו תהליך רישום קצר, ולאחמכ כבר תהיו לקוחות רשומים של החנות */
    M3530: 'M3530',
    /** האם הינכם מעוניינים לקבל בדואל עדכונים ומבצעים וכדו' מהחנות, להצטרפות הקישו 1, להמשך ללא הצטרפות הקישו 2. */
    M3531: 'M3531',
    /** האם הינכם מעוניינים לקבל הודעות קוליות מעדכונים ומבצעים וכדו' מהחנות, להצטרפות הקישו 1, להמשך ללא הצטרפות הקישו 2. */
    M3532: 'M3532',
    /** האם הינכם מעוניינים לקבל הודעות סמס מעדכונים ומבצעים וכדו' מהחנות, להצטרפות הקישו 1, להמשך ללא הצטרפות הקישו 2. */
    M3533: 'M3533',
    /** הרשמתכם לחנות הסתיימה בהצלחה, מייד תעברו לחנות */
    M3534: 'M3534',
    /** ההרשמה לחנות נכשלה שלום ותודה */
    M3535: 'M3535',
    /** אינכם מורשים להיכנס לחנות זו, נא פנו למנהל החנות */
    M3536: 'M3536',
    /** ברוכים הבאים לחנות */
    M3537: 'M3537',
    /** בעגלת הקניות שלכם ישנם כרגע */
    M3538: 'M3538',
    /** מוצרים */
    M3539: 'M3539',
    /** שהם */
    M3540: 'M3540',
    /** פריטים */
    M3541: 'M3541',
    /** לעריכת המוצרים בעגלת הקניות הקישו 1, לרכישת מוצרים הקישו 2, למעבר לתשלום הקישו 3, ליציאה הקישו 4 */
    M3542: 'M3542',
    /** לשמיעת כל המוצרים שיש כעת בעגלת הקניות ברצף הקישו 1, לבחירת מוצר מעגלת הקניות עפ המקט הקישו 2, למחיקת ואיפוס כל עגלת הקניות הקישו 3 לחזרה הקישו 4 */
    M3543: 'M3543',
    /** כעת יושמעו כל המוצרים בעגלת הקניות ברצף, בסיום שמיעת פרטי מוצר תועברו למוצר הבא, תוכלו להקיש בכל מוצר 1 לעריכת המוצר, 2 למוצר הבא, 3 למוצר הקודם, 4 ליציאה מהקראת עגלת הקניות, 5 למעבר לרכישת מוצרים נוספים, 6 למעבר לתשלום */
    M3544: 'M3544',
    /** שם המוצר */
    M3545: 'M3545',
    /** מחיר ליחידה */
    M3546: 'M3546',
    /** שקלים */
    M3547: 'M3547',
    /** הכמות שהוזמנה ממוצר זה */
    M3548: 'M3548',
    /** סך התשלום למוצר זה */
    M3549: 'M3549',
    /** לעריכת המוצר הקישו 1, למוצר הבא הקישו 2 או המתינו, למוצר הקודם הקישו 3, ליציאה מהקראת עגלת הקניות הקישו 4, למעבר לרכישת מוצרים נוספים הקישו 5, למעבר לתשלום הקישו 6. */
    M3550: 'M3550',
    /** לשינוי הכמות שהוזמנה ממוצר זה הקישו 1, למחיקת המוצר מעגלת הקניות הקישו 2, לחזרה לרשימת המוצרים בעגלת הקניות הקישו 3, ליציאה מהקראת המוצרים בעגלת הקניות הקישו 4 */
    M3551: 'M3551',
    /** הכמות המעודכנת הוא */
    M3552: 'M3552',
    /** נא הקישו את הכמות החדשה שהינכם רוצים להזמין ממוצר זה ולסיום הקישו סולמית, לביטול הקישו אפס וסולמית */
    M3553: 'M3553',
    /** השינוי נקלט בהצלחה */
    M3554: 'M3554',
    /** השינוי נכשל */
    M3555: 'M3555',
    /** הינכם מבקשים למחוק את המוצר */
    M3556: 'M3556',
    /** לאישור הקישו 1, לביטול הקישו 2 */
    M3557: 'M3557',
    /** המוצר נמחק בהצלחה מעגלת הקניות */
    M3558: 'M3558',
    /** מחיקת המוצר נכשלה */
    M3559: 'M3559',
    /** נא הקישו את מספר הקטלוגי של המוצר לסיום הקישו סולמית */
    M3560: 'M3560',
    /** מספר הקטלוגי של המוצר שגוי או שאינו מופיע בעגלת הקניות שלכם */
    M3561: 'M3561',
    /** לשינוי הכמות שהוזמנה ממוצר זה הקישו 1, למחיקת המוצר מהסל הקישו 2, להקשת מספר מקט אחר הקישו 3, לחזרה הקישו 4 */
    M3562: 'M3562',
    /** בחנות מוצעים כרגע */
    M3563: 'M3563',
    /** מחולקים ב */
    M3564: 'M3564',
    /** קטגוריות */
    M3565: 'M3565',
    /** לבחירת מוצר עפ מקט הקישו 1, לבחירת קטגוריית מוצרים הקישו 2, לשמיעת כל המוצרים ברצף הקישו 3, לשמיעת כל מוצרים ברצף מסודרים לפי הקטגוריות הקישו 4, למעבר לתשלום הקישו 5, לחזרה הקישו 6. */
    M3566: 'M3566',
    /** מספר המקט שהוקש שגוי */
    M3567: 'M3567',
    /** המוצר שבחרתם אינו זמין לרכישה נא פנו למנהל החנות */
    M3568: 'M3568',
    /** משקל המוצר בגרמים */
    M3569: 'M3569',
    /** הכמות במלאי */
    M3570: 'M3570',
    /** להזמנה ממוצר זה הקישו את הכמות הרצויה ולסיום הקישו סולמית, להקשת מספר מקט אחר הקישו 0 וסולמית, לחזרה הקישו סולמית */
    M3571: 'M3571',
    /** בחרת */
    M3572: 'M3572',
    /** סך התשלום למוצר זה כפול הכמות שבחרת הוא */
    M3573: 'M3573',
    /** שגיאה בהזמנת המוצר, הינכם מוחזרים */
    M3574: 'M3574',
    /** לא ניתן להזמין את הכמות הרצויה, נא בחרו כמות בשנית */
    M3575: 'M3575',
    /** המוצר נוסף בהצלחה לעגלת הקניות */
    M3576: 'M3576',
    /** להקשת מקט נוסף הקישו 1, למעבר לתשלום הקישו 2, לחזרה הקישו 3 */
    M3577: 'M3577',
    /** היכנם מועברים לסיכום הקניה ושמירתה */
    M3578: 'M3578',
    /** עגלת הקניות שלכם ריקה ולא ניתן לעבור לתשלום בעגלה ריקה, הינכם מועברים לרכישת מוצרים */
    M3579: 'M3579',
    /** סך התשלום לקנייה זו הינה */
    M3580: 'M3580',
    /** לאישור ומעבר לתשלום הקישו 1, לחזרה לשמיעת סיכום הקנייה הקישו 2, לחזרה למוצרים הקישו 3 */
    M3581: 'M3581',
    /** לתשלום באשראי הקישו 1, לתשלום בקבלת נתונים הקישו 2, לתשלום במזומן הקישו 3, לתשלום בנקודות הקישו 4, לחזרה הקישו 5 */
    M3582: 'M3582',
    /** הינכם מועברים לתשלום באשראי */
    M3583: 'M3583',
    /** הינכם מועברים לתשלום בקבלת נתונים */
    M3584: 'M3584',
    /** הינכם מועברים לתשלום במזומן */
    M3585: 'M3585',
    /** התשלום התקבל בהצלחה, נא המתינו לשמירת הקנייה שלכם */
    M3586: 'M3586',
    /** הקנייה נשמרה בהצלחה */
    M3587: 'M3587',
    /** הקנייה נשמרה ושולמה בהצלחה */
    M3588: 'M3588',
    /** שגיאה בשמירת הקנייה, נא פנו למנהל החנות */
    M3589: 'M3589',
    /** שגיאה בקבלת התשלום, הינכם מוחזרים לאפשריות תשלום */
    M3590: 'M3590',
    /** המוצר שבחרתם כבר נמצא בעגלת הקניות שלכם, הזמנה חדשה ממוצר זה, רק יוסיף על הכמות */
    M3591: 'M3591',
    /** להמשך לבחירת תוספת כמות ממוצר זה הקישו 1, לבחירת מקט אחר הקישו 2 */
    M3592: 'M3592',
    /** אנא המתינו, המערכת בודקת את תקינות עגלת הקניות שלכם. */
    M3593: 'M3593',
    /** המערכת מצאה כי יש אי תקינות בעגלת הקניות שלכם, יכול להיות שיש לכם מוצרים שנגמרו מהמלאי וכדו', תוכלו להמשיך לתשלום, המערכת יעדכן את המוצרים ואת הכמויות בעגלת הקניות לפי הכמות התקינה בלבד, והתשלום יהיה על המוצרים שיוזמנו בפועל בלבד, להמשך לתשלום ותיקון אוטומטי של עגלת הקניות הקישו 1, לשמיעת המוצרים שאינם תקינים, ותיקון שלהם הקישו 2 */
    M3594: 'M3594',
    /** לאישור הזמנת הכמות הקישו 1, לתיקון הכמות הקישו 2, לבחירת מקט אחר הקישו 3 */
    M3595: 'M3595',
    /** מספר המקט שהקשתם לא קיים בעגלת הקניות שלכם */
    M3596: 'M3596',
    /** הינכם עוברים כעת לתהליך הרשמה למרכז הקניות של חברת ימות המשיח פתרונות תקשורת, בהרשמתכם היכנם מסכימים להסכם ולתנאים, לאישור והמשך ההרשמה הקישו 1, לשמיעת ההסכם הקישו 2, ליציאה הקישו 3. */
    M3597: 'M3597',
    /** וכעת נבחר סיסמה, הסיסמה ישמש אותכם בכל פעם שתיכנסו לרכישת מוצרים גם באתר, וגם בטלפון, יש לבחור סיסמה של לפחות 6 מספרים, נא הקישו את הסיסמה, ולסיום הקישו סולמית */
    M3598: 'M3598',
    /** ההרשמה הסתיימה בהצלחה, ומעתה תוכל לרכוש במגוון החנויות של מרכז הקניות */
    M3599: 'M3599',
    /** הקלטה עצמית שם החנות */
    M3600: 'M3600',
    /** סוג השגיאה במוצר */
    M3601: 'M3601',
    /** מוצר לא תקין */
    M3602: 'M3602',
    /** הזמנה של כמות גדולה מהמלאי או מהמותר */
    M3603: 'M3603',
    /** פירוט השגיאה */
    M3604: 'M3604',
    /** המוצר לא זמין לרכישה */
    M3605: 'M3605',
    /** הכמות המותרת להזמנה ממוצר זה הוא */
    M3606: 'M3606',
    /** אם תשאירו את המוצר כך, המערכת יתקן אוטומטי בעת התשלום, לדילוג על תיקון המוצר ומעבר למוצר הבא הקישו 1, למחיקת המוצר מעגלת הקניות הקישו 2, לשינוי הכמות ממוצר זה הקישו 3, ליציאה מהקראת השגיאות הקישו 4 */
    M3607: 'M3607',
    /** שגיאה בקבלת פרטי השגיאה של המוצר הינכם מועברים למוצר הבא */
    M3608: 'M3608',
    /** להזמנה ממוצר זה הקישו 1, למעבר למוצר הבא הקישו 2 או המתינו, למוצר הקודם הקישו 3, למעבר לתשלום הקישו 4, ליציאה מהקראת המוצרים הקישו 5 */
    M3609: 'M3609',
    /** קוד המוצר - מקט */
    M3610: 'M3610',
    /** נא הקישו את הכמות שברצונכם לרכוש ולסיום הקישו סולמית, למעבר למוצר הבא הקישו 0 וסולמית, לחזרה הקישו סולמית */
    M3611: 'M3611',
    /** לאישור הזמנת המוצר הקישו 1, לבחירת הכמות מחדש הקישו 2, למעבר למוצר הבא ללא הזמנה מהמוצר הזה הקישו 3 */
    M3612: 'M3612',
    /** המוצר כבר נמצא בעגלת הקניות שלכם, הזמנה נוספת ממוצר זה רק יוסיף על הכמות הקיימת, להמשך הקישו 1, למעבר למוצר הבא הקישו 2 */
    M3613: 'M3613',
    /** אין יותר קטגוריות להשמעה */
    M3614: 'M3614',
    /** מספר קטגורייה */
    M3615: 'M3615',
    /** שם הקטגורייה */
    M3616: 'M3616',
    /** לכניסה לקטגורייה זו הקישו 1, למעבר לקטגורייה הבאה הקישו 2 או המתינו, לחזרה לקטגורייה הקודמת הקישו 3, לחזרה הקישו 4 */
    M3617: 'M3617',
    /** בקטגורייה זו ישנם כרגע */
    M3618: 'M3618',
    /** תתי קטגורייה */
    M3619: 'M3619',
    /** לשמיעת כל המוצרים מקטגורייה זו ברצף הקישו 1 או המתינו, לשמיעת המוצרים לפי תתי קטגוריות הקישו 2, למעבר לקטגורייה הבאה הקישו 3, לקטגורייה הקודמת הקישו 4, ליציאה מהקטגוריות הקישו 5 */
    M3620: 'M3620',
    /** אין יותר תתי קטגוריות להשמעה */
    M3621: 'M3621',
    /** מספר תת הקטגורייה */
    M3622: 'M3622',
    /** שם תת הקטגורייה */
    M3623: 'M3623',
    /** לכניסה לתת קטגורייה זו הקישו 1, למעבר לתת קטגורייה הבאה הקישו 2 או המתינו, לחזרה לתת קטגורייה הקודמת הקישו 3, לחזרה הקישו 4 */
    M3624: 'M3624',
    /** בתת קטגורייה זו ישנם כרגע */
    M3625: 'M3625',
    /** אין יותר מוצרים להשמעה בתת קטגורייה זו */
    M3626: 'M3626',
    /** אין יותר מוצרים להשמעה בחנות, הינכם מוחזרים */
    M3627: 'M3627',
    /** בחנות זו צריך לרכוש במינימום של */
    M3628: 'M3628',
    /** בחנות זו יש תוספת תשלום לכל רכישה בסך */
    M3629: 'M3629',
    /** בחנות זו אין שירות משלוחים */
    M3630: 'M3630',
    /** בחנות זו מוצע שירות משלוחים */
    M3631: 'M3631',
    /** בחנות זו מסופקים המוצרים במשלוח בלבד */
    M3632: 'M3632',
    /** מחיר המשלוח נקבע לפי משקל המוצרים שהוזמנו */
    M3633: 'M3633',
    /** המשלוח ניתן ללא עלות */
    M3634: 'M3634',
    /** מחיר המשלוח הוא */
    M3635: 'M3635',
    /** מחיר משלוח לכל קילו הוא */
    M3636: 'M3636',
    /** אין יותר מוצרים להשמעה בקטגורייה זו */
    M3637: 'M3637',
    /** אין יותר מוצרים בעגלת הקניות שלכם */
    M3638: 'M3638',
    /** אין יותר מוצרים עם שגיאה בעגלת הקניות, הינכם מועברים לבדיקת עגלת הקניות שלכם */
    M3639: 'M3639',
    /** להוספת משלוח הקישו 1, להמשך ללא משלוח הקישו 2 */
    M3640: 'M3640',
    /** לרכישה שלכם נוספה משלוח בסך */
    M3641: 'M3641',
    /** נוסף משלוח לכתובת המעודכנת בחשבון שלכם */
    M3642: 'M3642',
    /** עלות תוספת התשלום לכל קנייה הינה בסך */
    M3643: 'M3643',
    /** עלות המשלוח */
    M3644: 'M3644',
    /** סך הכל לתשלום */
    M3645: 'M3645',
    /** עגלת הקניות שלכם נמצא תקין */
    M3646: 'M3646',
    /** לסיום קטגורייה זו הקישו 1 או המתינו, לשמיעה חוזרת של קטגורייה זו הקישו 2, למעבר לתשלום הקישו 3, לחזרה הקישו 4 */
    M3647: 'M3647',
    /** הינכם מועברים לעריכת עגלת הקניות שלכם */
    M3648: 'M3648',
    /** לסיום תת קטגורייה זו הקישו 1 או המתינו, לשמיעה חוזרת של המוצרים מתת קטגורייה זו הקישו 2, לסיום בקטגורייה זו הקישו 3 למעבר לתשלום הקישו 4, לחזרה הקישו 5 */
    M3649: 'M3649',
    /** שימו לב לאחר מחיקת עגלת הקניות, לא ניתן יהיה לשחזר אותה, לאישור המחיקה הקישו 1, לביטול הקישו 2 */
    M3650: 'M3650',
    /** עגלת הקניות נמחקה בהצלחה */
    M3651: 'M3651',
    /** מחיקת עגלת הקניות נכשלה */
    M3652: 'M3652',
    /** הסניף המוגדר בשלוחה אינו תקין, נא פנו למנהל החנות */
    M3653: 'M3653',
    /** בחנות ישנם */
    M3654: 'M3654',
    /** סניפים */
    M3655: 'M3655',
    /** לסניף */
    M3656: 'M3656',
    /** הקישו */
    M3657: 'M3657',
    /** לא ניתן לשנות לכמות שהזנתם, נא בחרו כמות אחרת */
    M3658: 'M3658',
    /** סכום הקניה נמוך מהמינימום בחנות */
    M3659: 'M3659',
    /** הינך חורג ממספר הקניות המאושר לכל לקוח */
    M3660: 'M3660',
    /** סכום הקניה, חורג מהמקסימום שניתן לרכוש בקנייה */
    M3661: 'M3661',
    /** עברת את סכום המקסימום המותר לכל לקוח */
    M3662: 'M3662',
    /** מספר המוצרים בעגלת הקניות גבוה ממקסימום המוצרים הניתן לרכוש בכל קנייה */
    M3663: 'M3663',
    /** עברת את מקסימום המוצרים שכל לקוח יכול לרכוש מכלל הרכישות */
    M3664: 'M3664',
    /** מספר הפריטים בעגלת הקניות גבוה ממקסימום הפריטים הניתן לרכוש בכל קנייה */
    M3665: 'M3665',
    /** עברת את מקסימום הפריטים שכל לקוח יכול לרכוש מכל הרכישות */
    M3666: 'M3666',
    /** מספר המוצרים בעגלת הקניות נמוך מהמינימום שיש לרכוש */
    M3667: 'M3667',
    /** מספר הפריטים בעגלת הקניות נמוך מהמינימום שיש לרכוש */
    M3668: 'M3668',
    /** מינימום הסכום שיש לרכוש בקניה הוא */
    M3669: 'M3669',
    /** ואילו סכום הרכישה שלך הוא */
    M3670: 'M3670',
    /** מספר הקניות המאושר לכל לקוח הוא */
    M3671: 'M3671',
    /** בקנייה זו הינך מגיע לקנייה מספר */
    M3672: 'M3672',
    /** מקסימום הסכום שניתן לרכוש בקנייה הוא */
    M3673: 'M3673',
    /** מקסימום הסכום שכל לקוח יכול לרכוש בכל רכישותיו בחנות זו הוא */
    M3674: 'M3674',
    /** ואילו סכום הקניות שלכם כולל קנייה זו הוא */
    M3675: 'M3675',
    /** מקסימום המוצרים שניתן לרכוש בקנייה הוא */
    M3676: 'M3676',
    /** ואילו מספר המוצרים בקנייה שלכם הוא */
    M3677: 'M3677',
    /** מקסימום המוצרים שכל לקוח יכול לרכוש בכל הרכישות בחנות זו הוא */
    M3678: 'M3678',
    /** ואילו מספר המוצרים שלכם כולל קנייה זו הוא */
    M3679: 'M3679',
    /** מקסימום הפריטים שניתן לרכוש בקנייה הוא */
    M3680: 'M3680',
    /** ואילו מספר הפריטים בקנייה שלכם הוא */
    M3681: 'M3681',
    /** מקסימום הפריטים שכל לקוח יכול לרכוש בכל הרכישות בחנות זו הוא */
    M3682: 'M3682',
    /** ואילו מספר הפריטים שלכם כולל קנייה זו הוא */
    M3683: 'M3683',
    /** מספר המוצרים המינימלי שיש לרכוש בחנות הוא */
    M3684: 'M3684',
    /** מספר הפריטים המינימלי שיש לרכוש בחנות הוא */
    M3685: 'M3685',
    /** לחזרה לעריכת הקניה הקישו 1, לאיפוס ומחיקת כל הסל הקישו 2, ליציאה הקישו 3 */
    M3686: 'M3686',
    /** לאיפוס ומחיקת כל הסל הקישו 1, ליציאה הקישו 2 */
    M3687: 'M3687',
    /** סך הנחה לקנייה זו */
    M3688: 'M3688',
    /** המערכת מצאה כי יש קניות שעדיין לא שולמו, למעבר לפירוט ולתשלום הקישו 1, להמשך לחנות הקישו 2 */
    M3689: 'M3689',
    /** המערכת מצאה כי יש קניות שעדיין לא שולמו, הינכם מועברים לשמיעת פירוט הקניות ותשלום עליהם */
    M3690: 'M3690',
    /** מספר קנייה */
    M3691: 'M3691',
    /** לתשלום על הקנייה הקישו 1, למעבר לקניה הבאה הקישו 2 או המתינו, לקנייה הקודמת הקישו 3, ליציאה הקישו 4 */
    M3692: 'M3692',
    /** לתשלום באשראי הקישו 1, לתשלום בקבלת נתונים הקישו 2 */
    M3693: 'M3693',
    /** אין יותר קניות שעדיין לא שולמו */
    M3694: 'M3694',
    /** בחנות מוצעת הנחה של */
    M3695: 'M3695',
    /** אחוזים */
    M3696: 'M3696',
    /** ההנחה מותנית בקנייה של מעל */
    M3697: 'M3697',
    /** הכמות שהוזמנה ממוצר זה קטנה מהמינימום שניתן להזמין */
    M3698: 'M3698',
    /** הכמות המינימלית למוצר זה הוא */
    M3699: 'M3699',
    /** תיבת ההודעות מלאה. לא ניתן להקליט כעת הודעות, אנא נסו ביום אחר */
    M3700: 'M3700',
    /** למענה על הסקר פעם נוספת הקישו 1. למעבר לתוצאות הקישו 2 */
    M3701: 'M3701',
    /** הקשה זו לא זמינה */
    M3702: 'M3702',
    /** הצבעתכם היא */
    M3703: 'M3703',
    /** לאישור ההצבעה הקישו 1. להצבעה מחדש הקישו 2 */
    M3704: 'M3704',
    /** מספר השאלות הפעילות בסקר */
    M3705: 'M3705',
    /** שאלה מספר */
    M3706: 'M3706',
    /** כמות המשתמשים שבחרו את אפשרות */
    M3707: 'M3707',
    /** היא */
    M3708: 'M3708',
    /** אחוז המשתתפים שבחרו את אפשרות */
    M3709: 'M3709',
    /** הוא */
    M3710: 'M3710',
    /** למעבר לשאלה הבאה הקישו כוכבית */
    M3711: 'M3711',
    /** הסקר יסתיים ב */
    M3712: 'M3712',
    /** מיקום שלוחת הסקר לא הוגדר */
    M3713: 'M3713',
    /** שאלת הסקר היא */
    M3714: 'M3714',
    /** שים לב. הפעולה תגרום למחיקת השאלה והתוצאות שנצברו עד כך. לאישור הקישו 1 לביטול 2 */
    M3715: 'M3715',
    /** תפריט ראשי ניהול מודול סקר. לבחירת ניהול עפ שאלה, יצירה או עריכה של שאלות קיימות הקישו 1. להגדרות גלובאליות הקישו 2 */
    M3716: 'M3716',
    /** אנא הקש את מספר השאלה לעריכה או יצירה */
    M3717: 'M3717',
    /** השאלה שנבחרה היא */
    M3718: 'M3718',
    /** שאלה זו לא קיימת. ליצירת השאלה הקישו 1, לחזרה הקישו כוכבית או המתינו */
    M3719: 'M3719',
    /** להקלטת הודעות התשובות בנפרד הקישו 1. אחרת המתינו */
    M3720: 'M3720',
    /** תפריט ניהול שאלה. לחזרה לתפריט הקודם הקישו כוכבית. להקלטת הודעות השאלה הקישו 1 להגדרת המקשים המאופשרים הקישו 2 להקלטת הודעות לפי תשובות הקישו 3 להגדרת צורת שמיעת התוצאות הקישו 4 להגדרההאם להשתמיע את כמות המשתפים הקישו 5 לסגירה או פתיחת השאלה הקישו 6 לאיפוס נתוני התשובות הקישו 7 */
    M3721: 'M3721',
    /** אנא הקליטו את שאלה הסקר. בסיום הקישו סולמית */
    M3722: 'M3722',
    /** לא ניתן לחזור ביצירת שאלה */
    M3723: 'M3723',
    /** שאלה זו מוגדרת להיסתיים בתום זמן מסויים */
    M3724: 'M3724',
    /** לבחירת זמן מסויים לסיום השאלה הקישו 1 להפעלת השאלה הקישו 2 לסגירת השאלה הקישו 3 */
    M3725: 'M3725',
    /** אנא הקישו את הזמן לסגירת הסקר בצורה הבאה על פי תאריך לועזי. שנה כוכבית חודש כוכבית יום כוכבית שעה כוכבית דקה כוכבית ושניה כוכבית */
    M3726: 'M3726',
    /** הסבר על צורת ההקשה */
    M3727: 'M3727',
    /** בשאלה זו המערכת אומרת את מספר השאלה */
    M3728: 'M3728',
    /** בשאלה זו המערכת לא אומרת את מספר השאלה */
    M3729: 'M3729',
    /** כדי להגדיר שבשאלה זו המערכת תגיד את מספר השאלה הקישו 1. כדי להגדיר שבשאלה זו המערכת לא תגיד את מספר השאלה הקישו 32 */
    M3730: 'M3730',
    /** המקשים המאופשרים כעת לשאלה זו הם */
    M3731: 'M3731',
    /** לבחירה מחדש של המקשים לשאלה זו הקישו 1 לחזרה הקישו 2 */
    M3732: 'M3732',
    /** הקישו את המקשים שברצונכם שיהיו אפשרייים לשאלה זו */
    M3733: 'M3733',
    /** הקלטת הודעות התשובה בשאלה... */
    M3734: 'M3734',
    /** אנא הקש את מספר ההקשה שהנך רוצה להקיש עבורה את התשובה */
    M3735: 'M3735',
    /** אנא הקליטו את התשובה ובסיום הקישו סולמית */
    M3736: 'M3736',
    /** צורת ההשמעה כעת היא */
    M3737: 'M3737',
    /** השמעת כל הפרטים. כמות המשתתפים ואחוז המשתתפים לכל שאלה */
    M3738: 'M3738',
    /** להגיד רק את כמות המשתתפים הכללית בסקר ללא חלוקה לפי שאלות */
    M3739: 'M3739',
    /** להגיד רק כמה אחוזים כל בחירה בלי כמות מצביעים */
    M3740: 'M3740',
    /** להגיד רק כמה הצביעו לכל בחירה בלי חישוב אחוזים */
    M3741: 'M3741',
    /** לא להגיד שום דבר. ממשיך מייד לשאלה הבאה ואם אין אחד כזו ממשיך לשאלה הקודמת */
    M3742: 'M3742',
    /** לחזרה הקישו כוכבית. כדי להגדיר שבשאלה זו המערכת תגיד את כמות המשתפים הכללית וגם כמות לכל שאלה ואחוזים הקישו 1. כדי להגדיר שבשאלה זו המערכת תגיד רק כמה הצביעו לכל שאלה הקישו 2 כדי להגדיר שבשאלה זו המערכת תגיד כמה אחוזים כל תשובה קיבלה בלי כמות המשתמשים הקישו 3 כדי להגדיר שבשאלה זו המערכת תגיד כמה הצביעו לכל בחירה בלי חישוב האחוזים הקישו 4. כדי להגדיר שבשאלה זו המערכת לא תגיד את התוצאות אלא תעבור לשאלה הבאה באם יש אחת כזו הקישו 5 */
    M3743: 'M3743',
    /** כרגע מוגדר שבשאלה זו המערכת תשמיע את כמות המשתתפים הכללית */
    M3744: 'M3744',
    /** כרגע מוגדר שבשאלה זו המערכת לא תשמיע את כמות המשתתפים הכללית */
    M3745: 'M3745',
    /** לחזרה הקישו כוכבית. כדי להגדיר בשאלה זו המערכת תשמיע את כמות המשתתפים הכללית הקישו 1. כדי להגדיר בשאלה זו המערכת לא תשמיע את כמות המשתמשים הכללית הקישו 2 */
    M3746: 'M3746',
    /** כרגע השאלה פעילה */
    M3747: 'M3747',
    /** כרגע השאלה לא פעילה */
    M3748: 'M3748',
    /** אזהרה! איפוס נתוני הסקר יוביל למחיקת תוצאות הסקר ולהתחלתו מחדש */
    M3749: 'M3749',
    /** בשלוחה זו הוגבלה האפשרות לאפשר סיסמה */
    M3750: 'M3750',
    /** סך הנקודות שהקשתם הינו מעל סך הניקוד המקסימלי */
    M3751: 'M3751',
    /** סך הכניסות לשלוחה זו עבר את המותר */
    M3752: 'M3752',
    /** ההודעה נקלטה בהצלחה */
    M3753: 'M3753',
    /** שרת זה אינו תומך במודול זה */
    M3754: 'M3754',
    /** אין כעת שאלות, אנא נסו במועד מאוחר יותר */
    M3755: 'M3755',
    /** שלום הגעתם למשימת מאה ברכות בכל יום */
    M3756: 'M3756',
    /** שלוחה זו נעולה באמצעות סיסמה קולית, אנא אימרו את הסיסמה הקולית שלכם. */
    M3757: 'M3757',
    /** בחירתם כבר נקלטה */
    M3758: 'M3758',
    /** המקש שהקשתם הוא */
    M3759: 'M3759',
    /** תשובתכם נכונה */
    M3760: 'M3760',
    /** קיבלתם */
    M3761: 'M3761',
    /** נקודות */
    M3762: 'M3762',
    /** תשובתכם שגויה */
    M3763: 'M3763',
    /** הנכם מועברים להאזנה לשידור המוקלט, בשידור המוקלט לא ניתן לענות על התשובות שנשאלו בשידור. */
    M3764: 'M3764',
    /** סך הנקודות שצברתם במהלך השידור */
    M3765: 'M3765',
    /** סך הזמן בשניות בו עניתם על התשובות הנכונות */
    M3766: 'M3766',
    /** לשמיעה חוזרת הקישו 1. לסיום הקישו 2 */
    M3767: 'M3767',
    /** הנקודות הצטרפו לניקוד הכללי שלכם המערכת */
    M3768: 'M3768',
    /** לא הוגדר תשובה נכונה עבור שאלה זו */
    M3769: 'M3769',
    /** שיר - מסתובב הסביבון - הסביבון מתחיל מסתובב, לעצירת הסביבון הקישו על כל מקש או המתינו עד לסיום סיבוב הסביבון */
    M3770: 'M3770',
    /** הסביבון נפל על האות נ, אם תענו נכון לא תצברו נקודות, אך אם לא תענו נכון הניקוד שלכם ירד ב10 נקודות */
    M3771: 'M3771',
    /** הסביבון נפל על האות ג, אם תענו נכון תצברו 30 נקודות */
    M3772: 'M3772',
    /** הסביבון נפל על האות ה, אם תענו נכון תצברו 20 נקודות */
    M3773: 'M3773',
    /** הסביבון נפל על האות פ, אם תענו נכון תצברו 10 נקודות */
    M3774: 'M3774',
    /** חנוכונים */
    M3777: 'M3777',
    /** המשחק מתחיל */
    M3778: 'M3778',
    /** הסביבון מסתובב והשיר מתנגן, לעצירת הסיבון בכל עת, הקישו על כל מקש שתבחרו, במידה ולא תקישו עד סיום השי, הסביבון יפול בסיום השיר */
    M3779: 'M3779',
    /** המערכת טוענת את התשובות והנקודות מהשיחה הקודמת שלך בשידור זה */
    M3780: 'M3780',
    /** כבר השתתפת במשחק, בשידור תוכל להשתתף כמאזין, אבל לא כשחקן */
    M3781: 'M3781',
    /** הפעולה בוצעה בהצלחה. בכל עת ניתן להקיש כוכָבִית כוכָבִית ולחזור לשיחה עם הלקוח. */
    M3782: 'M3782',
    /** הקישו את השלוחה להעברת הלקוח, וסולמית לסיום, כאשר באם זה שלוחה בתוך שלוחה, הקישו * בין השלוחות */
    M3783: 'M3783',
    /** השלוחה לא קיימת, אנא נסו שוב, או הקישו ** לחזרה לשיחה עם הלקוח */
    M3784: 'M3784',
    /** אנו מזהים כי קיים בקשה לשיחה חוזרת למספרכם, לביטול הפנייה ומעבר לתור הקישו 1, להמשך המתנה לשיחה החוזרת וסיום השיחה הנוכחית הקישו 2 */
    M3785: 'M3785',
    /** הפנייה בוטלה הינכם מועברים לתור */
    M3786: 'M3786',
    /** הזמנת שיחה חוזרת נכשלה הינכם מוחזרים לתור */
    M3787: 'M3787',
    /** זוהי שיחה חוזרת הינכם מועברים למענה */
    M3788: 'M3788',
    /** זוהי שיחה חוזרת, למעבר כעת לנציג הקישו 1, אם אינכם זמינים כרגע לשיחה, ואתם רוצים שנחזור מאוחר יותר הקישו 2, לביטול הפנייה וניתוק הקישו 3 */
    M3789: 'M3789',
    /** התור סגור כעת, אנא נסה שנית בשעות הפעילות */
    M3790: 'M3790',
    /** שיחה זו מועברת אליכם באמצעות הפלטפורמה הטכנולגית של ימות המשיח, לקבלת השיחה הקישו 1, להחזרת המתקשר להמתנה לנציג הבא שיתפנה הקישו 2 , להוצאת המתקשר מהתור הקישו 3 */
    M3791: 'M3791',
    /** לשיחה חוזרת למספר שאיתו התקשרתם הקישו 1 למספר אחר הקישו 2 לחזרה לתור הקישו 3 לניתוק וסיום הקישו 4 או נתקו */
    M3792: 'M3792',
    /** בקשתכם לשיחה חוזרת נקלטה בהצלחה */
    M3793: 'M3793',
    /** נא הקישו את המספר לשיחה החוזרת ולסיום הקישו סולמית */
    M3794: 'M3794',
    /** לשיחה חוזרת למספר איתו התקשרתם */
    M3795: 'M3795',
    /** למספר אחר */
    M3796: 'M3796',
    /** לחזרת לתור */
    M3797: 'M3797',
    /** לניתוק וסיום */
    M3798: 'M3798',
    /** שגיאה בהגדרת התפריט האישי לשיחה חוזרת, נא פנו למנהל המערכת */
    M3799: 'M3799',
    /** מספר המקט שהוגדר בשלוחה שגוי */
    M3800: 'M3800',
    /** המקט המוגדר בשלוחה, אינו זמין לרכישה, נא פנו למנהל החנות */
    M3801: 'M3801',
    /** להמשך לבחירת תוספת כמות ממוצר זה הקישו 1, ליציאה הקישו 2 */
    M3802: 'M3802',
    /** לאישור הזמנת הכמות הקישו 1, לתיקון הכמות הקישו 2, לחזרה הקישו 3 */
    M3803: 'M3803',
    /** שגיאה בהזמנת המוצר, הינכם מוחזרים */
    M3804: 'M3804',
    /** למעבר לתשלום הקישו 1, ליציאה הקישו 2 */
    M3805: 'M3805',
    /** שגיאה בשמירת הקנייה, נא פנו למנהל המערכת, הינכם מועברים לקנייה הבאה */
    M3806: 'M3806',
    /** קודם נבחר שם משתמש, שם המשתמש ישמש אותכם לזיהוי במערכת, וכן בעת כניסתכם באתר האינטרנט, אם זה לא משנה לכם, תוכלו לדלג על זה ושם המשתמש יהיה מספר הטלפון ממנו אתם מחייגים (ותוכלו לשנות את שם המשתמש באתר האינטרנט במועד מאוחר יותר), להקלטת שם משתמש הקישו 1, להקשת שם משתמש במספרים, הקישו 2, לדילוג על הכנסת שם המשתמש הקישו 3 */
    M3807: 'M3807',
    /** נא הקליטו את שם המשתמש ובסיום הקישו סולמית */
    M3808: 'M3808',
    /** הקלטת שם המשתמש הסתיים בהצלחה */
    M3809: 'M3809',
    /** נא הקישו את שם המשתמש במספרים ולסיום הקישו סולמית */
    M3810: 'M3810',
    /** בחרתם לדלג על הקלטת שם משתמש, ושם המשתמש יהיה מספר הטלפון ממנו אתם מחייגים */
    M3811: 'M3811',
    /** כעת תוכלו להוסיף מייל לחשבון שלכם, כך תוכלו לקבל פירוטי קניות ישירות למייל ומידע חשוב, למעבר כעת להקשת מייל הקישו 1, לדילוג על הכנסת המייל הקישו 2 */
    M3812: 'M3812',
    /** הינכם מועברים להקשת מייל */
    M3813: 'M3813',
    /** כתובת המייל נקלטה בהצלחה */
    M3814: 'M3814',
    /** מודול קניות */
    M3815: 'M3815',
    /** להקלטת שם פרטי הקישו 1, לדילוג הקישו 2 */
    M3816: 'M3816',
    /** נא הקליטו את שם הפרטי ולסיום הקישו סולמית */
    M3817: 'M3817',
    /** שם הפרטי שהוקלט נקלט בהצלחה */
    M3818: 'M3818',
    /** להקלטת שם משפחה הקישו 1, לדילוג הקישו 2 */
    M3819: 'M3819',
    /** נא הקליטו את שם המשפחה ולסיום הקישו סולמית */
    M3820: 'M3820',
    /** שם המשפחה נקלט בהצלחה */
    M3821: 'M3821',
    /** כעת תוכלו להוסיף פרטי כתובת מגורים, למקרה של משלוח, וכדו', להכנסת פרטי כתובת הקישו 1, לדילוג הקישו 2 */
    M3822: 'M3822',
    /** נא הקליטו את עיר המגורים ולסיום הקישו סולמית */
    M3823: 'M3823',
    /** נא הקליטו את שם הרחוב ולסיום הקישו סולמית */
    M3824: 'M3824',
    /** נא הקישו את מספר הבית ולסיום סולמית */
    M3825: 'M3825',
    /** באם למספר הבית יש כמה כניסות הקישו את הכניסה במספרים ולסיום סולמית, לדוגמה לכניסה א הקישו 1 וסולמית, באם אין כניסות הקישו סולמית */
    M3826: 'M3826',
    /** נא הקישו מספר דירה ולסיום סולמית, לדילוג הקישו סולמית */
    M3827: 'M3827',
    /** נא הקישו מיקוד ולסיום סולמית, לדילוג הקישו סולמית */
    M3828: 'M3828',
    /** מספר הטלפון אינו מזוהה, לא ניתן להמשיך במערכת המכירות בצורה טלפונית ללא מספר טלפון, נא התקשרו מטלפון מזוהה, או לחילופין היכנסו דרך אתר האינטרנט באמצעות שם משתמש וסיסמה */
    M3829: 'M3829',
    /** לקבלת משלוח לכתובת המעודכנת בחשבון שלכם הקישו 1, לקבלת המשלוח לכתובת אחרת הקישו 2, לשמיעת הכתובת המעודכנת בחשבון שלכם הקישו 3 */
    M3830: 'M3830',
    /** להקלטת פרטי הכתובת האחרת הקישו 1, להקשת הפרטים במקשי הטלפון הקישו 2 לחזרה לבחירת הכתובת הקישו 3 */
    M3831: 'M3831',
    /** נא הקישו את שם העיר */
    M3832: 'M3832',
    /** נא הקישו את שם הרחוב */
    M3833: 'M3833',
    /** באם איש הקשר לקבלת המשלוח הוא בעל החשבון תוכלו לדלג עי הקשת 1, באם יש איש קשר אחר לקבלת המשלוח הקישו 2 להזנת פרטיו */
    M3834: 'M3834',
    /** נא הקישו את שם איש הקשר למשלוח */
    M3835: 'M3835',
    /** נא הקישו את מספר הטלפון של איש הקשר */
    M3836: 'M3836',
    /** נא הקליטו את שם איש הקשר למשלוח */
    M3837: 'M3837',
    /** אם הפרטים נכונים הקישו 1, להכנסת פרטי המשלוח מחדש הקישו 2, לשמיעה חוזרת של הפרטים הקישו 3 */
    M3838: 'M3838',
    /** אם יש לך הערה מיוחדת למשלוח הקישו 1, לדילוג הקישו 2 */
    M3839: 'M3839',
    /** נא הקישו את ההערה */
    M3840: 'M3840',
    /** נא הקליטו את ההערה ולסיום סולמית */
    M3841: 'M3841',
    /** שגיאה בהקלדת האותיות, הינכם מוחזרים */
    M3842: 'M3842',
    /** הפרטים שנקלטו */
    M3843: 'M3843',
    /** שם העיר */
    M3844: 'M3844',
    /** שם הרחוב */
    M3845: 'M3845',
    /** מספר בית */
    M3846: 'M3846',
    /** כניסה */
    M3847: 'M3847',
    /** מיקוד */
    M3848: 'M3848',
    /** מספר דירה */
    M3849: 'M3849',
    /** שם איש הקשר למשלוח */
    M3850: 'M3850',
    /** טלפון איש הקשר */
    M3851: 'M3851',
    /** הערה למשלוח */
    M3852: 'M3852',
    /** משלוח נוסף בהצלחה לכתובת שהכנסתם */
    M3853: 'M3853',
    /** המערכת זיהתה שמספר הטלפון איתו התקשרתם רשום בכמה חשבונות במרכז הקניות, הינכם מועברים לבחירת שם המשתמש איתו אתם רוצים להיכנס */
    M3854: 'M3854',
    /** למשתמש */
    M3855: 'M3855',
    /** אין פרטי כתובת בחשבונך, שלום ותודה */
    M3856: 'M3856',
    /** לכניסה לחנות הקישו 1, לשמיעת היסטוריית 10 קניות אחרונות שלך הקישו 2, לעריכת הפרטים בחשבונך הקישו 3, ליציאה הקישו 4 */
    M3857: 'M3857',
    /** תשלום כולל בסך */
    M3858: 'M3858',
    /** לשמיעת פירוט הקנייה המלאה הקישו 1, למעבר לקנייה הבאה הקישו 2 או המתינו, לקנייה הקודמת הקישו 3, לחזרה הקישו 4 */
    M3859: 'M3859',
    /** סוף רשימת הקניות */
    M3860: 'M3860',
    /** בקנייה זו רכשתם */
    M3861: 'M3861',
    /** סך התשלום על המוצרים היה */
    M3862: 'M3862',
    /** נוסף תוספת תשלום בסך */
    M3863: 'M3863',
    /** עלות המשלוח היה */
    M3864: 'M3864',
    /** קיבלתם הנחה בסך */
    M3865: 'M3865',
    /** פירוט הקנייה */
    M3866: 'M3866',
    /** סך הכל למוצר זה */
    M3867: 'M3867',
    /** סוף רשימת המוצרים */
    M3868: 'M3868',
    /** שם המשתמש שלך הוא */
    M3869: 'M3869',
    /** לשמיעת הפרטים המעודכנים היום בחשבון הקישו 1, לשינוי סיסמת החשבון והגדרות אבטחה הקישו 2, לשינוי פרטים הקישו 3, לשמיעת 10 קניות אחרונות הקישו 4, לחזרה הקישו 5 */
    M3870: 'M3870',
    /** שם פרטי */
    M3871: 'M3871',
    /** שם משפחה או שם העסק */
    M3872: 'M3872',
    /** כתובת אימייל */
    M3873: 'M3873',
    /** מספר טלפון */
    M3874: 'M3874',
    /** מספר טלפון בבית */
    M3875: 'M3875',
    /** מספר טלפון נוסף */
    M3876: 'M3876',
    /** מוגדר לבקש סיסמה לפני ביצוע קנייה */
    M3877: 'M3877',
    /** מוגדר לא לבקש סיסמה לפני ביצוע קניה */
    M3878: 'M3878',
    /** לשינוי הסיסמה הקישו 1, לשינוי הגדרת בקשת סיסמה לפני ביצוע קניייה הקישו 2, לשינוי הגדרת אימות טלפוני לפני ביצוע קנייה הקישו 3, לחזרה הקישו 4 */
    M3879: 'M3879',
    /** נא בחרו סיסמה חדשה, הסיסמה צריכה להיות לפחות 6 ספרות, ולסיום הקישו סולמית, לביטול הקישו כוכבית וסולמית */
    M3880: 'M3880',
    /** שינוי הפרטים נקלט בהצלחה */
    M3881: 'M3881',
    /** שגיאה בשינוי הפרטים הינכם מוחזרים */
    M3882: 'M3882',
    /** להגדרה שלא יבקש סיסמה לפני ביצוע קנייה הקישו 1, להגדרה שכן יבקש סיסמה הקישו 2 לחזרה הקישו 3 */
    M3883: 'M3883',
    /** לשינוי שם הפרטי הקישו 1, לשינוי שם המשפחה או שם העסק הקישו 2, לשינוי מספר הטלפון הקישו 3, לשינוי מספר הטלפון בבית הקישו 4, לשינוי מספר הטלפון הנוסף הקישו 5 לשינוי דואר אלקטרוני - אימייל הקישו 6, לשינוי כתובת מגורים הקישו 7, לחזרה הקישו 8 */
    M3884: 'M3884',
    /** האם תרצו שבכל קניה בטלפון תצטרכו להקיש את הסיסמה שבחרת, להגדרה שיבקש סיסמה הקישו 1, להגדרה שלא יבקש סיסמה הקישו 2 */
    M3885: 'M3885',
    /** משלוח לכתובת המעודכנת */
    M3886: 'M3886',
    /** בעיסקה זו תחויבו בסך */
    M3887: 'M3887',
    /** נקודות */
    M3888: 'M3888',
    /** לאישור הקישו 1 לחזרה הקישו 2 */
    M3889: 'M3889',
    /** לסיום הקנייה ומעבר לתשלום ושמירה הקישו 1 או המתינו, לשמיעה חוזרת של המוצרים הקישו 2, לחזרה לתחילת החנות הקישו 3, ליציאה הקישו 4 */
    M3890: 'M3890',
    /** לתשלום ב */
    M3891: 'M3891',
    /** כרטיס אשראי */
    M3892: 'M3892',
    /** קבלת נתונים */
    M3893: 'M3893',
    /** מזומן */
    M3894: 'M3894',
    /** הקישו */
    M3895: 'M3895',
    /** שגיאה בהגדרות אמצעי התשלום */
    M3896: 'M3896',
    /** הינכם מועברים לתשלום בנקודות */
    M3897: 'M3897',
    /** האופצייה עדיין בבנייה נסו שוב מאוחר יותר */
    M3898: 'M3898',
    /** בכדי להיכנס לחנות נא הקישו את מספר החנות ובסיום סולמית */
    M3899: 'M3899',
    /** לא ניתן לחייג חיוג לIP לא לכתובת IP. אנא תקנו את ההגדות בשלוחה */
    M3900: 'M3900',
    /** שימו לב, חשוב שאת הליך פתיחת המערכת תבצעו מטלפון שלכם. איפוס סיסמה של המערכת ואימות מלא של בעל הקו יהיה מול הטלפון שפתח את המערכת. */
    M3901: 'M3901',
    /** אם שחכתם את הסיסמה הקישו # בלבד */
    M3902: 'M3902',
    /** עדכון אחרון ביום */
    M3903: 'M3903',
    /** שעה */
    M3904: 'M3904',
    /** ערך הפעולה חסר */
    M3915: 'M3915',
    /** אין שלוחה להפניה לפעולה זו */
    M3916: 'M3916',
    /** שלום, הגעתם למשימת 100 ברכות בכל יום */
    M3917: 'M3917',
    /** בירכתם */
    M3918: 'M3918',
    /** נותרו לך */
    M3919: 'M3919',
    /** ברכות */
    M3920: 'M3920',
    /** לסימון שברכת ברכה הקישו 1, לביטול סימון ברכה הקישו 2, לשמיעת כמות הברכות שבירכתם הקישו 3, לאיפוס המונה של היום הקישו 4, ליציאה הקישו כוכבית */
    M3921: 'M3921',
    /** אנא הקישו את כמות הברכות, ובסיום הקישו סולמית */
    M3922: 'M3922',
    /** תודה רבה! אשריכם שזכיתם */
    M3923: 'M3923',
    /** ביטול הסימון בוצע בהצלחה */
    M3924: 'M3924',
    /** האיפוס בוצע בהצלחה */
    M3925: 'M3925',
    /** מקום מספר */
    M3926: 'M3926',
    /** צבר בסך */
    M3927: 'M3927',
    /** שם הצובר הוא */
    M3928: 'M3928',
    /** קובץ שקט כשמגדירים שלא משמיע קיבלת.. נקודות */
    M3929: 'M3929',
    /** אין מספיק נקודות לרכישה */
    M3930: 'M3930',
    /** מינוס */
    M3931: 'M3931',
    /** פלוס */
    M3932: 'M3932',
    /** לשמיעה חוזרת, הקישו 1. להמשך הקישו 2, או המתינו. */
    M3933: 'M3933',
    /** להוספה למספר דקות, הקישו 1, למספר שעות, הקישו 2, למספר ימים הקישו 3, למספר חודשים, הקישו 4. */
    M3935: 'M3935',
    /** הקישו את כמות מספר הדקות שברצונכם להיות מחוברים לקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3936: 'M3936',
    /** הקישו את כמות מספר השעות שברצונכם להיות מחוברים לקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3937: 'M3937',
    /** הקישו את כמות מספר הימים שברצונכם להיות מחוברים לקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3938: 'M3938',
    /** הקישו את כמות מספר החודשים שברצונכם להיות מחוברים לקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3939: 'M3939',
    /** להשתקה למספר דקות, הקישו 1, למספר שעות, הקישו 2, למספר ימים הקישו 3, למספר חודשים, הקישו 4. */
    M3940: 'M3940',
    /** הקישו את כמות מספר הדקות שברצונכם להיות מנותקים מקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3941: 'M3941',
    /** הקישו את כמות מספר השעות שברצונכם להיות מנותקים מקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3942: 'M3942',
    /** הקישו את כמות מספר הימים שברצונכם להיות מנותקים מקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3943: 'M3943',
    /** הקישו את כמות מספר החודשים שברצונכם להיות מנותקים מקבלת הצינתוקים, ולסיום, הקישו סולמית */
    M3944: 'M3944',
    /** מספר הטלפון שלכם נוסף בהצלחה לרשימת הצנתוקים למשך הזמן שהגדרתם */
    M3945: 'M3945',
    /** מספר הטלפון שלכם הוסר בהצלחה מרשימת הצנתוקים למשך הזמן שהגדרתם */
    M3946: 'M3946',
    /** תפריט בחירת קמפיין, אנא הקישו את מספר הקמפיין אליו ברצונכם להקליט את ההודעה ובסיום הקישו סולמית */
    M3948: 'M3948',
    /** אנא הקישו את המפתח הרצוי ובסיום סולמית */
    M3949: 'M3949',
    /** לשמיעת סכום המעשרות הקישו 1, לעדכון הכנסה, וחישוב מחדש של סכום המעשרות, הקישו 2, לעדכון הוצאה מהמעשרות, הקישו 3, לאיפוס המונה, הקישו 4, ליציאה, הקישו כוכבית */
    M3950: 'M3950',
    /** נתת מעשרות יותר מההכנסות, הסכום הוא */
    M3951: 'M3951',
    /** סכום המעשרות שנצבר הוא */
    M3952: 'M3952',
    /** אנא הקישו סכום, לנקודה, הקישו כוכבית, לסיום, סולמית. ליציאה הקישו כוכבית */
    M3953: 'M3953',
    /** לחישוב מעשר רגיל, הקישו 1, לחישוב בתוספת חומש, הקישו 2 , לחזרה הקישו כוכבית */
    M3954: 'M3954',
    /** סכום המעשר מתוך הסכום שהוקש הוא */
    M3955: 'M3955',
    /** לאישור והכנסת הסכום לסכום המעשרות הכולל, הקישו 1, לשינוי החישוב, הקישו 2, לביטול וחזרה, הקישו כוכבית */
    M3956: 'M3956',
    /** סכום המעשרות שהיה עד כה הוא */
    M3957: 'M3957',
    /** הסכום שהתווסף הוא */
    M3958: 'M3958',
    /** סכום המעשרות הכולל כעת הוא */
    M3959: 'M3959',
    /** אנא הקישו סכום להפחתה מסכום המעשרות הכולל, לנקודה, הַקישו כוכבית, לסיום, סולמית. ליציאה הַקישו כוכבית */
    M3960: 'M3960',
    /** הסכום שהופחת הוא */
    M3961: 'M3961',
    /** לאישור איפוס מונה המעשרות, הקישו 1, לביטול וחזרה לתפריט, הקישו 2 */
    M3962: 'M3962',
    /** איפסתם בהצלחה את מונה המעשרות שלכם */
    M3963: 'M3963',
    /** מספר התשלומים המינימלי לרכישה זו הינו.. */
    M3966: 'M3966',
    /** מספר החודשים המינימלי לחיוב הינו.. */
    M3967: 'M3967',
    /** חודשים */
    M3968: 'M3968',
    /** אנא הקישו את מספר השלוחה אליה תירצו להכניס את המלל, ובסיום הקישו סולמית */
    M3969: 'M3969',
    /** אנא הקישו את מספר ההודעה לשמירה ובסיום הקישו סולמית, לבחירת הודעת מערכת הקישו כוכבית ולאחר מכן את מספר ההודעה ובסיום הקישו סולמית */
    M3970: 'M3970',
    /** לכתיבת ההודעה הקישו 1, להקלטת הודעה והמרתה לטקסט הקישו 2 */
    M3971: 'M3971',
    /** הקליטו את הודעתכם לאחר הצליל ובסיום הקישו סולמית */
    M3972: 'M3972',
    /** המלל שנקלט הוא.. */
    M3973: 'M3973',
    /** לאישור המלל הקישו 1, לשמיעת חוזרת של המלל הקישו 2, להקלטה מחדש הקישו 3 */
    M3974: 'M3974',
    /** ההודעה נקלטה בהצלחה! */
    M3975: 'M3975',
    /** אנא בחרו את סוג הקריין הרצוי. לאליק הקישו 1, ליעקב הקישו 2, לאסנת הקישו 3, לסיוון הקישו 4 */
    M3976: 'M3976',
    /** כך המלל נשמע לפי הקריין שבחרתם */
    M3977: 'M3977',
    /** לאישור הקישו 1, לבחירת קריין אחר הקישו 2, להחלפת המלל הקישו 3 */
    M3978: 'M3978',
    /** אנא הֳקישו את המספר לחיוג וסולמית לסיום */
    M3980: 'M3980',
    /** מספר הטלפון שהוּקַש אינו תקין, אנא נסו שוב, או הַקישו כוכָבית כוכָבית, לחזרה לשיחה עם הלקוׁח */
    M3981: 'M3981',
    /** המספר שהוקש הוא */
    M3983: 'M3983',
    /** לאישור הקישו 1 - לשינוי הקישו 2 */
    M3984: 'M3984',
    /** השלוחה לא.. יש להגדיר מייל או סמס */
    M3987: 'M3987',
    /** יש להגדיר עבור מי השירות */
    M3988: 'M3988',
    /** מספר הטלפון שהוכנס לקבלת סמס לא תקין */
    M3989: 'M3989',
    /** אנא הקישו את הסיסמה החדשה. בסיום הקישו סולמית ליציאה הקישו כוכבית */
    M3990: 'M3990',
    /** לשלוחה זו אין סיסמה. כדי ליצור סיסמה אנא הקישו סיסמה כעת, ליציאה הקישו כוכבית */
    M3991: 'M3991',
    /** הפעולה בוצעה בהצלחה */
    M3992: 'M3992',
    /** אנא הקישו את השלוחה בה תרצו לשנות את הסיסמה, כאשר לשלוחה פנימית הקישו כוכבית, לסיום הקישו סולמית */
    M3993: 'M3993',
    /** לזיהוי זה אין סיסמה */
    M3994: 'M3994',
    /** לזיהוי זה יש סיסמה */
    M3995: 'M3995',
    /** תוכל לענות שוב על הסקר */
    M3996: 'M3996',
    /** לאישור החלפת הסיסמה הקש 1. להקשה מחודשת של הסיסמה הקש 2. לביטול החלפת הסיסמה הקש 3 */
    M3997: 'M3997',
    /** כל תור הוא עד */
    M4001: 'M4001',
    /** דקות */
    M4002: 'M4002',
    /** ניתן לקבוע תור בין השעות */
    M4003: 'M4003',
    /** ועד */
    M4004: 'M4004',
    /** לקביעת תור להיום הקישו 1, לקביעת תור למחר הקישו 2, לתור הבא הפנוי הקישו 3, לקביעת תור לתאריך אחר הקישו 4 */
    M4005: 'M4005',
    /** לשמיעת כל התורים הפנויים במשך היום הקישו 1, לבחירת שעה רצויה לקביעת תור הקישו 2 */
    M4006: 'M4006',
    /** השעה שהוגדרה בשלוחה כשעת ההתחלה גדולה משעת הסיום שלום ותודה */
    M4007: 'M4007',
    /** בשעה */
    M4008: 'M4008',
    /** ו */
    M4009: 'M4009',
    /** לקביעת התור הקישו 1, לתור הבא הקישו 2, לחזרה הקישו 3 */
    M4010: 'M4010',
    /** אין יותר תורים ליום שנבחר */
    M4011: 'M4011',
    /** התור נקבע בהצלחה לתאריך */
    M4012: 'M4012',
    /** נא הקליטו את שמכם ולסיום הקישו סולמית */
    M4013: 'M4013',
    /** הקלטת השם הסתיים בהצלחה */
    M4014: 'M4014',
    /** אין קבלת קהל ביום הנבחר */
    M4015: 'M4015',
    /** נא הקישו את התאריך הרצוי לקביעת התור בשמונה ספרות שני ספרות ליום שני ספרות לחודש וארבע ספרות לשנה, לדוגמא לתאריך העשירי לראשון 2020 הקישו 10012020 ולסיום הקישו סולמית */
    M4016: 'M4016',
    /** התאריך שהוקש שגוי או שהוקשה תאריך שכבר עבר */
    M4017: 'M4017',
    /** בתאריך */
    M4018: 'M4018',
    /** לא נמצאו יותר תורים בטווח הימים שניתן להזמין תורים, שלום ותודה */
    M4019: 'M4019',
    /** המערכת תחפש את התורים הפנויים שאחרי השעה שהזנתם, נא בחרו את השעה הרצויה בארבע ספרות ולסיום הקישו סולמית, לדוגמה לשעה 1 בצהריים הקישו 1300 */
    M4020: 'M4020',
    /** רק שניה, המערכת בודקת האם השעה תקינה */
    M4021: 'M4021',
    /** השעה שנבחרה לא תואמת את ההגדרות שהוגדרו לקביעת פגישות, ניתן לקבוע פגישות בין השעות */
    M4022: 'M4022',
    /** התור הראשון שנמצא פנוי אחרי השעה שהקשתם הוא, בשעה */
    M4023: 'M4023',
    /** לתשלום באשראי הקישו 1, לתשלום בקבלת נתונים הקישו 2 */
    M4024: 'M4024',
    /** הינכם מועברים לתשלום באשראי */
    M4025: 'M4025',
    /** הינכם מועברים לתשלום בקבלת נתונים */
    M4026: 'M4026',
    /** שגיאה בקבלת התשלום הינכם מוחזרים */
    M4027: 'M4027',
    /** התשלום התקבל בהצלחה */
    M4028: 'M4028',
    /** להזמנת תור הקישו 1, לשמיעת התורים שהזמנתם הקישו 2 */
    M4029: 'M4029',
    /** לשמיעה חוזרת הקישו 1, לביטול התור הקישו 2 לחזרה הקישו 3 */
    M4030: 'M4030',
    /** הינכם מבקשים לבטל את התור שנקבע לתאריך */
    M4031: 'M4031',
    /** לאישור הקישו 1, לביטול הקישו 2 */
    M4032: 'M4032',
    /** לא נמצאו תורים שנקבעו על ידכם */
    M4033: 'M4033',
    /** התור נמחק בהצלחה */
    M4034: 'M4034',
    /** המערכת מזהה שיש לכם כבר תור שמור לא ניתן להזמין תור נוסף, תוכלו לבטל את התור הקודם, ולאחמכ להזמין תור חדש */
    M4035: 'M4035',
    /** בתור זה נותרו * */
    M4036: 'M4036',
    /** מקומות פנויים. מתוך * */
    M4037: 'M4037',
    /** מקומות שבכל תור */
    M4038: 'M4038',
    /** אנא הקישו את מספר הנפשות שבאים איתכם לתור זה */
    M4039: 'M4039',
    /** התאריך שהוגדר להזמנת תורים לא תקין */
    M4040: 'M4040',
    /** לא הוגדר קובץ לשליחה */
    M4080: 'M4080',
    /** הקובץ שהוגדר לא נמצא בשלוחה */
    M4081: 'M4081',
    /** המערכת לא מצאה כתובת מייל למספר הטלפון איתו התקשרתם, ניתן לעדכן את הכתובת במרכז הקניות של ימות המשיח בצורה אוטומטית באתר, או להתקשר לשירות הלקוחות ולבקש לעדכן לכם את המייל */
    M4082: 'M4082',
    /** מספר הטלפון שלכם לא מזוהה, לא ניתן לשלוח מייל */
    M4083: 'M4083',
    /** השליחה הועברה לביצוע שלום ותודה */
    M4084: 'M4084',
    /** שגיאה בשליחת המייל נא פנו לשירות הלקוחות */
    M4085: 'M4085',
    /** מודול קובץ למייל */
    M4086: 'M4086',
    /** מודול קובץ למייל */
    M4087: 'M4087',
    /** מודול קובץ למייל */
    M4088: 'M4088',
    /** מודול קובץ למייל */
    M4089: 'M4089',
    /** פנייתכם נשלחה בהצלחה */
    M4090: 'M4090',
    /** שגיאה בשליחת פנייתכם נא פנו למנהל המערכת */
    M4091: 'M4091',
    /** שגיאה בחיוב בשביל מעבר למענה, נא פנו למנהל המערכת */
    M4092: 'M4092',
    /** סך כלל הנרשמים לרשימה זו */
    M4101: 'M4101',
    /** רשימה זו ריקה */
    M4102: 'M4102',
    /** כמות המשתתפים בזמן אמת בחדר הועידה הוא */
    M4103: 'M4103',
    /** אחוזים מתוך יעד של */
    M4104: 'M4104',
    /** שהוא */
    M4105: 'M4105',
    /** הסכום הנותר להשלמת יעד הקמפיין הוא */
    M4106: 'M4106',
    /** לא ניתן לפתוח מערכת טלפונית ממספר שהוא עצמו מערכת בימות המשיח */
    M4107: 'M4107',
    /** מתוכם, כמות המספרים הפעילים היא */
    M4108: 'M4108',
    /** וכמות המספרים המושתקים היא */
    M4109: 'M4109',
    /** אנא הקליטו את המידע לתמלול לאחר השמע הצליל */
    M4110: 'M4110',
    /** תוצאה */
    M4120: 'M4120',
    /** מפתח נתון ראשון */
    M4121: 'M4121',
    /** מפתח נתון שני */
    M4122: 'M4122',
    /** מפתח נתון שלישי */
    M4123: 'M4123',
    /** אנא הקישו מפתח נתון ראשון וסולמית לסיום. לחיפוש לפי מפתח נתון שני ושלישי הקישו כוכבית וסולמית . ליציאה הקישו סולמית. */
    M4131: 'M4131',
    /** אנא הקישו מפתח נתון שני וסולמית לסיום. ליציאה הקישו סולמית. */
    M4132: 'M4132',
    /** אנא הקישו מפתח נתון שלישי וסולמית לסיום. ליציאה הקישו סולמית. */
    M4133: 'M4133',
    /** אנא אמרו מפתח נתון ראשון ולסיום הקישו סולמית. לחיפוש לפי מפתח נתון שני ושלישי אמרו כוכבית ולסיום הקישו סולמית. ליציאה אמרו סולמית ואז הקישו סולמית */
    M4141: 'M4141',
    /** אנא אמרו מפתח נתון שני ולסיום הקישו סולמית. ליציאה אמרו סולמית ואז הקישו סולמית */
    M4142: 'M4142',
    /** אנא אמרו מפתח נתון שלישי ולסיום הקישו סולמית. ליציאה אמרו סולמית ואז הקישו סולמית */
    M4143: 'M4143',
    /** אין תוצאות למפתח נתון ראשון שהקשת */
    M4151: 'M4151',
    /** אין תוצאות למפתח נתון שני שהקשת */
    M4152: 'M4152',
    /** אין תוצאות למפתח נתון שלישי שהקשת */
    M4153: 'M4153',
    /** יש כיסאות שמורים על שמך */
    M4154: 'M4154',
    /** לשמיעת הכיסאות השמורים ומעבר לרכישה הקישו 1 */
    M4155: 'M4155',
    /** לרכישת כיסאות אחרים הקישו 2 */
    M4156: 'M4156',
    /** אנא בחרו את הכסא לרכישה */
    M4157: 'M4157',
    /** לרכישת כסא מספר.. */
    M4158: 'M4158',
    /** הנמצא בשורה.. */
    M4159: 'M4159',
    /** במחיר של... */
    M4160: 'M4160',
    /** הקישו.. */
    M4161: 'M4161',
    /** שימו לב, הכסא שמור עד */
    M4162: 'M4162',
    /** לסיום ומעבר לתשלום הקישו 1 לבחירת מקום נוסף הקישו 2 */
    M4163: 'M4163',
    /** אין מקום נוסף שמור על שמך */
    M4164: 'M4164',
    /** מצב הקלדה עברית - עודכן */
    M4170: 'M4170',
    /** מצב הקלדה אנגלית - עודכן */
    M4171: 'M4171',
    /** מצב הקלדה איימיל - עודכן */
    M4172: 'M4172',
    /** מצב הקלדה ספרות - עודכן */
    M4173: 'M4173',
    /** לא הקשתם כתובת מייל, איימיל לא יכול להתחיל בשטורדל, הנכם מועברים לביטול והקלדה מחודשת של האיימיל */
    M4180: 'M4180',
    /** האיימיל שהוקלד הוא */
    M4181: 'M4181',
    /** האיימיל שהקשתם אינו תקין - לא קיים ספק, אנא המשיכו בהקלדה או הקלידו מחדש */
    M4182: 'M4182',
    /** לגימיל נקודה קום הקישו 1. לוואלה נקודה קום הקישו 2. לוואלה נקוד CO נקודה IL הקישו 3. לאוטלוק נקודה קום הקישו 4. לאוטלוק נקודה CO נקודה IL הקישו 5. ליאהו נקודה קום הקישו 6. להמשך הקלדה בצורה עצמאית הקישו 9. */
    M4183: 'M4183',
    /** אנא הקישו את הסיפרה הבאה. לשינוי שפת הקלדה, לסיום ההקשות, לביטול הקשה אחרונה או לביטול כלל ההקשות הקישו כוכבית */
    M4184: 'M4184',
    /** אנא הקישו את הסיפרה. לשינוי שפת הקלדה או לביטול ויציאה הקישו כוכבית */
    M4185: 'M4185',
    /** שינוי שפת הקלדה חסום בכתיבה זו. */
    M4186: 'M4186',
    /** לסיפרה עצמה הקישו 5 פעמים על הספרה וסולמית. לשטורדל הקישו 0 וסולמית. לפלוס הקישו 00 וסולמית. למינוס או מקף אמצעי הקישו 000 וסולמית. לנקודה הקישו 1 וסולמית. לאות A הקישו 2 וסולמית. לאות B הקישו 22 וסולמית. לאות C הקישו 222 סולמית. לאות D הקישו 3 וסולמית. לאות E הקישו 33 וסולמית. לאות F הקישו 333 וסולמית. לאות G הקישו 4 וסולמית. לאות H הקישו 44 וסולמית. לאות I הקישו 444 וסולמית. לאות J הקישו 5 וסולמית. לאות K הקישו 55 וסולמית. לאות L הקישו 555 וסולמית. לאות M הקישו 6 וסולמית. לאות N הקישו 66 וסולמית. לאות O הקישו 666 וסולמית. לאות P הקישו 7 וסולמית. לאות Q הקישו 77 וסולמית. לאות R הקישו 777 וסולמית. לאות S הקישו 7777 וסולמית. לאות T הקישו 8 וסולמית. לאות U הקישו 88 וסולמית. לאות V הקישו 888 וסולמית. לאות W הקישו 9 וסולמית. לאות X הקישו 99 וסולמית. לאות Y הקישו 999 וסולמית. לאות Z הקישו 9999 וסולמית */
    M4187: 'M4187',
    /** התהילים שלי. לשמיעת הפרקים שלי הקישו 1. לבחירת כל פרק אחר הקישו 2. לעריכת הרשימה האישית הקישו 3 */
    M4200: 'M4200',
    /** עריכת והגדרת הרשימה האישית:. אנא הקישו את מיקום השמעת הפרק אותו ברצונכם לערוך. לעריכת הפרק הראשון בתהילים שלי הקישו 1 וסולמית. לעריכת הפרק השני הקישו 2 וסולמית. רשימת הפרקים שלי הינו בין ספרה אחד ועד 3 ספרות. המערכת תשמיע את כל הפרקים מהרשימה הנמוכה ועד הרשימה הגבוהה. ליציאה הקישו סולמית. לשמיעת כלל ההגדרות הקישו אפס וסולמית */
    M4201: 'M4201',
    /** אין פרקים מוגדרים */
    M4202: 'M4202',
    /** הגדרת תהילים מיקום */
    M4203: 'M4203',
    /** יום הולדת עברי */
    M4204: 'M4204',
    /** יום הולדת לועזי */
    M4205: 'M4205',
    /** פרק קבוע */
    M4206: 'M4206',
    /** שגיאה בסוג הפרק */
    M4207: 'M4207',
    /** פרק.. */
    M4208: 'M4208',
    /** שגיאה בהמרת תאריך לועזי */
    M4209: 'M4209',
    /** יום */
    M4210: 'M4210',
    /** חודש */
    M4211: 'M4211',
    /** שנה */
    M4212: 'M4212',
    /** מיקומי התהילים יכולים להכיל מקשים מ0 ועד 9 ולא יכולים לכלול את מקש הכוכבית */
    M4213: 'M4213',
    /** הגדרת מיקום השמעת תהילים מספר */
    M4214: 'M4214',
    /** להגדרת פרק קבוע הקישו 1. להגדרת תאריך לידה עברי הקישו 2. להגדרת תאריך לידה לועזי הקישו 3. לביטול וחזרה הקישו כוכבית */
    M4215: 'M4215',
    /** אנא הקישו את הפרק התהילים הקבוע. בסיום הקישו סולמית */
    M4216: 'M4216',
    /** הפרק נקבע בהצלחה */
    M4217: 'M4217',
    /** נא הקישו את תאריך יום ההולדת העברי בשמונה ספרות. שני ספרות ליום. שני ספרות לחודש. וארבע ספרות לשנה. ולסיום הקישו סולמית. לדוגמה לתאריך ג תשרי תשעט. הקישו 03015779 וסולמית. לחודש אדר א הקישו 13 לחודש אדר ב הקישו 14 */
    M4218: 'M4218',
    /** נא הקישו את תאריך יום ההולדת הלועזי בשמונה ספרות. שני ספרות ליום. שני ספרות לחודש. וארבע ספרות לשנה. ולסיום הקישו סולמית. לדוגמא לתאריך העשירי לראשון 2020 הקישו 10012020 וסולמית */
    M4219: 'M4219',
    /** באם ברצונכם בהוספת כותרת לפרק בהקלטה קולית הקישו 1. להוספת כותרת בהקלדת אותיות הקישו 2. לדילוג על כותרת הקישו 3 */
    M4220: 'M4220',
    /** הפרק להיום הוא פרק */
    M4221: 'M4221',
    /** יום ההולדת נקבע בהצלחה */
    M4222: 'M4222',
    /** הקלדת כותרת לפרק תהילים */
    M4223: 'M4223',
    /** הכותרת לפרק הוקלדה בהצלחה */
    M4224: 'M4224',
    /** אנא הקליטו את כותרת הפרק תהילים וסולמית לסיום */
    M4225: 'M4225',
    /** לאישור ההקלטה הקישו 1. לשמיעה הקישו 2. להקלטה מחדש 3. לביטול ההקלטה הקישו כוכבית */
    M4226: 'M4226',
    /** הכותרת לפרק הוקלטה בהצלחה */
    M4227: 'M4227',
    /** לאישור הקישו 1 או המתינו. לעריכה הקישו 2. למחיקת חיוג מקוצר זה הקישו 3 */
    M4228: 'M4228',
    /** ביטלתם בהצלחה את תהילים אישי מיקום מספר */
    M4229: 'M4229',
    /** סוף רשימה */
    M4230: 'M4230',
    /** במהלך ההשמעה תוכלו. לחזור 10 שניות אחורה בהקשה על 4. או לדלג 10 שניות קדימה בהקשה על 6. לעצירה הקישו 5 ולחזרה שוב 5. להפעלת הפרק מחדש הקישו 0. לחזרה לפרק הקודם הקישו 2. ולמעבר לפרק הבא הקישו 8. ליציאה הקישו כוכבית */
    M4231: 'M4231',
    /** יציאה מההשמעה */
    M4232: 'M4232',
    /** אנא הקישו את הפרק התהילים להשמעה וסולמית לסיום */
    M4233: 'M4233',
    /** להגדרה שהשמעת התהילים תהיה בנוסח ספרד הקישו 1. להגדרה שהשמעת התהילים תהיה בנוסח אשכנז הקישו 2. להגדרה כי בכל פעם יושמע תפריט לפני ההשמעה ובו תבחרו באיזה נוסח לשמוע הקישו 3 */
    M4234: 'M4234',
    /** נוסח ספרדי נקבע בהצלחה */
    M4235: 'M4235',
    /** נוסח אשכנזי נקבע בהצלחה */
    M4236: 'M4236',
    /** תפריט בחירה לנוסח התהילים נקבע בהצלחה */
    M4237: 'M4237',
    /** אנא הקישו את השלוחה ממנה תרצו לקחת את הקובץ כאשר במקום סלש יש להקיש כוכבית */
    M4350: 'M4350',
    /** אנא הקישו את מספר הטלפון איליו תרצו לשלוח את ההזמנה. בסיום הקישו סולמית. לחזרה הקישו כוכבית וסולמית */
    M4351: 'M4351',
    /** שיחת ההזמנה נשלחה בהצלחה */
    M4352: 'M4352',
    /** שלוחה זו לא הגודרה בצורה תקינה. */
    M4353: 'M4353',
    /** מספר הטלפון שלכם לא מזוהה או לא תקין */
    M4354: 'M4354',
    /** קובץ ההזמה ארוך מ6 שניות. יש לפנות למנהל המערכת */
    M4355: 'M4355',
    /** מספר הטלפון שהוקש אינו תקין */
    M4356: 'M4356',
    /** לא ניתן להזמין את מספר הטלפון הזה, יתכן שהוא קיים ברשימה */
    M4357: 'M4357',
    /** אנא הקישו את הערך הרצוי ובסיום סולמית */
    M4358: 'M4358',
    /** הנכם מועברים לכתיבת מפתח */
    M4359: 'M4359',
    /** הנכם מועברים לכתיבת ערך */
    M4360: 'M4360',
    /** אנא הקישו את הפתיח להודעה שתישלח, בסיום הקישו סולמית */
    M4361: 'M4361',
    /** הפתיח שהקשתם לא קיים, אנא הקישו בשנית */
    M4362: 'M4362',
    /** הפתיח שזוהה הינו */
    M4363: 'M4363',
    /** לאישור הקישו 1, להקשה מחודשת הקישו 2 */
    M4364: 'M4364',
    /** הפתיח שהקשתם אינו קיים, להמשך הקישו 1, להקשה מחודשת הקישו 2 */
    M4365: 'M4365',
    /** במערכת זו אין סיסמת הקלטות. */
    M4366: 'M4366',
    /** במערכת זו אין סיסמת גישה */
    M4367: 'M4367',
    /** כדי ליצור סיסמה, הקישו את הסיסמה כעת ובסיום סולמית, ליציאה, הקישו כוכבית וסולמית */
    M4368: 'M4368',
    /** סיסמת ההקלטות שלכם היא.. */
    M4369: 'M4369',
    /** סיסמת הגישה שלכם היא.. */
    M4370: 'M4370',
    /** הקישו את הסיסמה החדשה ובסיום סולמית, לביטול הסיסמה, הקישו סולמית, ליציאה, הקישו כוכבית וסולמית */
    M4371: 'M4371',
    /** ביטול סיסמה, האם הינכם בטוחים? לאישור הקישו 1 ליציאה הקישו כוכבית */
    M4372: 'M4372',
    /** הקישו את הסיסמה החדשה ובסיום סולמית, ליציאה, הקישו כוכבית וסולמית */
    M4373: 'M4373',
    /** הסיסמה שונתה בהצלחה */
    M4374: 'M4374',
    /** הסיסמה החדשה היא */
    M4375: 'M4375',
    /** לא ניתן להתחבר בו זמנית מאותו משתמש */
    M4376: 'M4376',
    /** כעת המערכת תבקש מכם לעדכן את המיקום של הדף או הדפים אותם למדתם */
    M4379: 'M4379',
    /** הקישו את הסדר */
    M4380: 'M4380',
    /** הקישו את המסכת */
    M4381: 'M4381',
    /** הקישו את הדף */
    M4387: 'M4387',
    /** לא ניתן לבחור את הדף שהקשתם. דף זה לא קיים במסכת שנבחרה */
    M4388: 'M4388',
    /** במידה וכל הדפים האחרים אותם למדתם שייכים למסכת הנוכחית והינם בסדר רץ הקישו אחת.במידה ורק חלק מהדפים האחרים אותם למדתם הינם בסדר רץ הקישו שתיים.במידה והדפים האחרים אותם למדתם הינם במיקום אחר הקישו שלוש. */
    M4389: 'M4389',
    /** אנא הקישו את הכמות של הדפים הבאים שהם בסדר רץ - לדוגמא, אם כבר עדכנתם את דף ב', ויש לכם לעדכן עד דף י' לחצו 8 */
    M4390: 'M4390',
    /** הכמות אותה הקשתם כעת גבוהה מכמות הדפים אותה הקשתם מקודם. אנא נסו שנית */
    M4391: 'M4391',
    /** לא ניתן לבחור אפשרות זו, מפני שמספר הדפים שהוקשו לדווח, גדול מסך הדפים שנותרו במסכת זו */
    M4392: 'M4392',
    /** לכניסה לחנות הקישו 1, לשמיעת והגדרת פרטים אישיים והגדרות אבטחה הקישו 2 */
    M4400: 'M4400',
    /** כדי להיכנס לאיזור האישי יש להקיש את סיסמת הניהול ולסיום סולמית אי הקשת הסיסמה הנכונה יגרום לשיבוש בהמשך האיזור האישי, אם שכחתם את הסיסמה הקישו 0 וסולמית */
    M4401: 'M4401',
    /** שגיאה בקבלת הגדרות האבטחה של חשבונך הינך מוחזר */
    M4402: 'M4402',
    /** שגיאה בשינוי הסיסמה, הינך מוחזר */
    M4403: 'M4403',
    /** שינוי סיסמה בוצע בהצלחה */
    M4404: 'M4404',
    /** שגיאה בקליטת השינוי הינך מוחזר */
    M4405: 'M4405',
    /** השינוי נקלט בהצלחה */
    M4406: 'M4406',
    /** נא הקישו את מספר הטלפון ולסיום סולמית, לביטול הקישו 0 וסולמית */
    M4407: 'M4407',
    /** לשינוי עיר מגורים הקישו 1, לשינוי רחוב הקישו 2, לשינוי מספר בית הקישו 3, לשינוי כניסה הקישו 4, לשינוי המיקוד הקישו 5, לשינוי מספר הדירה הקישו 6, לחזרה הקישו 7 */
    M4408: 'M4408',
    /** נא הקישו את מספר הבית ולסיום סולמית לביטול הקישו 0 וסולמית */
    M4409: 'M4409',
    /** נא הקישו את מספר הכניסה ולסיום סולמית לביטול הקישו 0 וסולמית */
    M4410: 'M4410',
    /** נא הקישו את המיקוד ולסיום סולמית לביטול הקישו 0 וסולמית */
    M4411: 'M4411',
    /** נא הקישו את מספר הדירה ולסיום סולמית לביטול הקישו 0 וסולמית */
    M4412: 'M4412',
    /** כעת תקבלו שיחת צינתוק, עליכם לשמור את הארבע ספרות אחרונות של המספר, לאחמכ תצטרכו להקיש אותם כדי לבצע אימות */
    M4413: 'M4413',
    /** המערכת לא הצליחה להוציא שיחת אימות לטלפון המעודכן למערכת, נא פנו למנהל המערכת */
    M4414: 'M4414',
    /** נא הקישו את ארבע ספרות אחרונות של המספר שהתקשר אליכם עכשיו ולסיום הקישו סולמית */
    M4415: 'M4415',
    /** כעת תוכלו להוסיף עוד טלפון לחשבון, להוספת טלפון בבית הקישו 1 לסיום ומעבר לביצוע הרשמה הקישו 2 */
    M4416: 'M4416',
    /** להוספת טלפון נוסף הקישו 1, לסיום ומעבר לביצוע ההרשמה הקישו 2 */
    M4417: 'M4417',
    /** מספר החנות */
    M4418: 'M4418',
    /** שם החנות */
    M4419: 'M4419',
    /** תאריך הקנייה */
    M4420: 'M4420',
    /** עלות הקניה */
    M4421: 'M4421',
    /** להכנסת שם איש הקשר בהקלטה הקישו 1, להכנסת שם איש הקשר בהקשה הקישו 2, לחזרה הקישו 3 */
    M4422: 'M4422',
    /** להכנסת ההערה בהקלטה הקישו 1, להכנסת ההערה בהקשה הקישו 2 לחזרה הקישו 3 */
    M4423: 'M4423',
    /** במוצר זה יש לבחור */
    M4424: 'M4424',
    /** בחירתך נקלטה, בנוסף במוצר זה יש לבחור */
    M4425: 'M4425',
    /** ל... */
    M4426: 'M4426',
    /** וסולמית */
    M4427: 'M4427',
    /** לקטגורייה */
    M4428: 'M4428',
    /** לשמיעת כל המוצרים מקטגורייה זו ברצף הקישו 1, לשמיעת כל המוצרים מסודרים לפי תתי קטגוריות הקישו 2, לחזרה להקשת קטגורייה אחרת הקישו 3, לחזרה לתחילת החנות הקישו 4 */
    M4429: 'M4429',
    /** יש לנו פרטים שהכניס מוכר עליך, הקש 1 לשמיעת הפרטים, הקש 2 לאישור והרשמה עם הפרטים האלו, הקש 3 להרשמה רגילה והכנסה מחדש של כל הפרטים */
    M4430: 'M4430',
    /** בכדי להיכנס לחנות זו, יש ליצור קשר עם מנהל החנות עמ שירשום אתכם כלקוחות, שלום ותודה */
    M4431: 'M4431',
    /** כעת יושמעו כל המוצרים בחנות בכל מוצר תוכלו להקיש 1 להזמנה מהמוצר, 2 או המתנה בכדי לעבור למוצר הבא, 3 למוצר קודם, 4 למעבר לתשלום, 5 ליציאה מהקראת המוצרים */
    M4432: 'M4432',
    /** כעת יושמעו כל הקטגוריות ברצף, בכל קטגורייה תוכלו להקיש 1 לכניסה לקטגורייה, 2 או המתנה בכדי לעבור לקטגורייה הבאה, 3 לחזרה לקטגורייה קודמת, 4 לחזרה */
    M4433: 'M4433',
    /** כעת יושמעו כל תתי הקטגוריות ברצף, בכל תת קטגורייה תוכלו להקיש 1 לכניסה לתת הקטגורייה, 2 או המתנה בכדי לעבור לתת קטגורייה הבאה, 3 לחזרה לתת קטגורייה קודמת, 4 לחזרה */
    M4434: 'M4434',
    /** לא הוגדר קוד שאלון */
    M4600: 'M4600',
    /** קוד השאלון שהוגדר אינו תקין */
    M4601: 'M4601',
    /** המערכת מזהה שכבר עניתם על השאלון */
    M4602: 'M4602',
    /** שגיאה כללית */
    M4603: 'M4603',
    /** לדילוג הקישו * וסולמית */
    M4604: 'M4604',
    /** שגיאה, השאלה לא נמצאת */
    M4605: 'M4605',
    /** שגיאה, המערכת מזהה שכבר עניתם על שאלה זו */
    M4606: 'M4606',
    /** התשובה נקלטה בהצלחה */
    M4607: 'M4607',
    /** סיימתם בהצלחה את השאלון */
    M4608: 'M4608',
    /** הקישו */
    M4609: 'M4609',
    /** לבחירה הקישו 1 להמשך ללא בחירה הקישו 2 */
    M4610: 'M4610',
    /** דילוג על השאלה נקלטה בהצלחה */
    M4611: 'M4611',
    /** נא הקישו את תשובתכם ולסיום הקישו סולמית */
    M4612: 'M4612',
    /** נא הקליטו את תשובתכם ולסיום הקישו סולמית */
    M4613: 'M4613',
    /** אם התשובה היא כן הקישו 1, אם התשובה היא לא הקישו 2 */
    M4614: 'M4614',
    /** נא בחרו את אחד מהאפשרויות הבאות ולסיום הקישו סולמית */
    M4615: 'M4615',
    /** מייד נשמיע לכם את האפשרויות הניתנות לבחירה, ניתן לבחור יותר מאפשרות אחת */
    M4616: 'M4616',
    /** לשאלון זה יש תשלום בסך */
    M4617: 'M4617',
    /** להמשך למענה לשאלון הקישו 1 ליציאה הקישו 2 */
    M4618: 'M4618',
    /** השאלון עדיין לא נפתח */
    M4619: 'M4619',
    /** השאלון כבר פג תוקף */
    M4620: 'M4620',
    /** השאלון כבר עבר את המקסימום התשובות שניתן לענות */
    M4621: 'M4621',
    /** שגיאה בנתונים */
    M4622: 'M4622',
    /** בכדי לסיים ולשמור את התגובות הינכם מועברים לתשלום */
    M4623: 'M4623',
    /** התשלום התקבל בהצלחה ותגובתכם נשמרה בהצלחה */
    M4624: 'M4624',
    /** שגיאה בקבלת התשלום */
    M4625: 'M4625',
    /** למענה בהקלטה הקישו 1, למענה בהקשה הקישו 2 */
    M4626: 'M4626',
    /** נא הקישו את התאריך בשמונה ספרות, שתים ליום שתים לחודש וארבע לשנה, לסיום הקישו סולמית */
    M4627: 'M4627',
    /** לאישור הקישו 1 */
    M4628: 'M4628',
    /** מספר אישור */
    M4629: 'M4629',
    /** לשמיעה חוזרת של מספר האישור הקישו 1 לסיום הקישו 2 או המתינו */
    M4630: 'M4630',
    /** הכנסתם אימייל לא תקין */
    M4631: 'M4631',
    /** הכנסתם טלפון לא תקין */
    M4632: 'M4632',
    /** הכנסתם תאריך לא תקין */
    M4633: 'M4633',
    /** הכנסתם מספר לא תקין */
    M4634: 'M4634',
    /** כן ולא חייב להיות או 1 או 0 */
    M4635: 'M4635',
    /** תיבת סימון חייבת להיות כן */
    M4636: 'M4636',
    /** הערך שהכנסתם לא תקין */
    M4637: 'M4637',
    /** הערך חייב להיות */
    M4638: 'M4638',
    /** הסכום לא מגיע למינימום שהוגדר */
    M4639: 'M4639',
    /** המינימום הוא */
    M4640: 'M4640',
    /** הסכום עובר את המקסימום שהוגדר */
    M4641: 'M4641',
    /** המקסימום הוא */
    M4642: 'M4642',
    /** אורך הטקסט קצר מידי */
    M4643: 'M4643',
    /** אורך הטקסט חייב להיות */
    M4644: 'M4644',
    /** אורך הטקסט ארוך מידי */
    M4645: 'M4645',
    /** אורך הטקסט חייב להיות עד */
    M4646: 'M4646',
    /** תוים */
    M4647: 'M4647',
    /** התאריך מוקדם מידי */
    M4648: 'M4648',
    /** התאריך המינימלי הוא */
    M4649: 'M4649',
    /** התאריך מאוחר מידי */
    M4650: 'M4650',
    /** התאריך המקסימלי הוא */
    M4651: 'M4651',
    /** למעבר להכנסת אימייל הקישו 1 */
    M4652: 'M4652',
    /** הינכם מועברים להקשת אימייל */
    M4653: 'M4653',
    /** שימו לב המענה לשאלה הבאה כרוכה באימות נוסף למספר הטלפון שתכניסו */
    M4654: 'M4654',
    /** האימות יתבצע בסמס */
    M4655: 'M4655',
    /** האימות יתבצע בשיחת צינתוק */
    M4656: 'M4656',
    /** האימות יישלח לטלפון כשר בשיחת צינתוק במקום סמס */
    M4657: 'M4657',
    /** נא בחרו את אופן ביצוע האימות, לסמס הקישו 1 לשיחת צינתוק הקישו 2 ליציאה הקישו כוכבית */
    M4658: 'M4658',
    /** כעת נשלחה קוד זמני בהודעת סמס למספר הטלפון שהוזן, נא הקישו אותו במקשי הטלפון ולסיום הקישו סולמית */
    M4659: 'M4659',
    /** כעת נשלחה קוד זמני בשיחת צינתוק למספר הטלפון שהוזן יש לזכור את ארבע ספרות האחרונות של המספר שחייג אליכם, ולהקיש אותו במקשי הטלפון ולסיום סולמית */
    M4660: 'M4660',
    /** האימות הצליח */
    M4661: 'M4661',
    /** האימות נכשל */
    M4662: 'M4662',
    /** שגיאה, לא נמצא מרכזייה מחוברת לשאלון, בכדי לשלוח אימות יש לחבר מרכזייה טלפונית */
    M4663: 'M4663',
    /** שגיאה בשליחת האימות, לא ניתן לשלוח סמס למספר כשר */
    M4664: 'M4664',
    /** הינכם מסיימים את השאלון ללא שמירה */
    M4665: 'M4665',
    /** להשארת מספר הטלפון ממנו אתם מתקשרים כעת, הקישו 1 וסולמית, להשארת מספר אחר, הקישו את המספר הרצוי ולאחריו סולמית. */
    M4666: 'M4666',
    /** לבחירת העיר מתוך רשימת הערים הקישו 1 להקלטת שם העיר הקישו 2 */
    M4667: 'M4667',
    /** נא הקליטו את שם העיר בקול ברור ולסיום הקישו סולמית */
    M4668: 'M4668',
    /** שם העיר שזוהה הוא */
    M4669: 'M4669',
    /** לאישור הקישו 1 לתיקון הקישו 2 */
    M4670: 'M4670',
    /** לא נמצאה התאמה לשם העיר שהקלטתם הינכם מועברים להקלטה מחדש */
    M4671: 'M4671',
    /** הקישו את האות הראשונה משם העיר כמו שמקישים טקסט ולסיום הקישו סולמית, לדוגמה לאות א הקישו 3 וסולמית לאות ב הקישו 33 וסולמית ולאות ט הקישו 666 וסולמית וכן הלאה */
    M4672: 'M4672',
    /** נמצאו מידי הרבה תוצאות, הינכם מועברים להקשת האות הבאה, בכדי לצמצם את רשימת הערים */
    M4673: 'M4673',
    /** הקישו את אות */
    M4674: 'M4674',
    /** משם העיר, כמו שמקישים טקסט ולסיום הקישו סולמית, לדוגמה לאות א הקישו 3 וסולמית לאות ב הקישו 33 וסולמית ולאות ט הקישו 666 וסולמית וכן הלאה */
    M4675: 'M4675',
    /** לעיר */
    M4676: 'M4676',
    /** הקישו */
    M4677: 'M4677',
    /** לא נמצאו כלל ערים המתחילות באותיות שהקשתם, הינכם מועברים להתחלת ההקלדה */
    M4678: 'M4678',
    /** נמצאו מידי הרבה תוצאות, הינכם מועברים להקלטה מחדש של שם העיר, נא אמרו את שם העיר המלא */
    M4679: 'M4679',
    /** גמרא. לשמיעה בשפה העברית, הקישו 1. אוף אידיש, דריקט צווי. לחזרה הקישו כוכבית */
    M4700: 'M4700',
    /** גמרה - תפריט עברית */
    M4701: 'M4701',
    /** גנרה - תפריש אידיש */
    M4702: 'M4702',
    /** גמרא ליום */
    M4703: 'M4703',
    /** גמרא ליום (אידיש) */
    M4704: 'M4704',
    /** דף */
    M4705: 'M4705',
    /** דף (אידיש) */
    M4706: 'M4706',
    /** במסכת */
    M4707: 'M4707',
    /** במסכת (אידיש) */
    M4708: 'M4708',
    /** גמרה - תפריט בחירת סדר (עברית) */
    M4709: 'M4709',
    /** גמרה - תפריט בחירת סדר (אידיש) */
    M4710: 'M4710',
    /** הודעה מאת.. */
    M4808: 'M4808',
    /** להשתקת התראות הקישו 1, לביטול השתקת התראות הקישו 2, לבדיקת הסטטוס הנוכחי הקישו 3 */
    M4809: 'M4809',
    /** להשתקת התראות לזמן מסוים הקישו 1, להשתקת התראות החל מזמן מסוים הקישו 2, להשתקת התראות לצמיתות הקישו 3 */
    M4810: 'M4810',
    /** ביטול השתקת התראות מהמערכת לטלפון שלכם, בוצע בהצלחה */
    M4811: 'M4811',
    /** השתקת התראות מהמערכת לטלפון שלכם, בוצע לצמיתות */
    M4812: 'M4812',
    /** להשתקת התראות למספר דקות, הקישו 1, למספר שעות, הקישו 2, למספר ימים הקישו 3, למספר חודשים, הקישו 4 */
    M4813: 'M4813',
    /** הקישו את מספר הדקות שברצונכם להפסיק לקבל התראות מהמערכת, ולסיום הקישו סולמית */
    M4814: 'M4814',
    /** הקישו את מספר השעות שברצונכם להפסיק לקבל התראות מהמערכת, ולסיום הקישו סולמית */
    M4815: 'M4815',
    /** הקישו את מספר הימים שברצונכם להפסיק לקבל התראות מהמערכת, ולסיום הקישו סולמית */
    M4816: 'M4816',
    /** הקישו את מספר החודשים שברצונכם להפסיק לקבל התראות מהמערכת, ולסיום הקישו סולמית */
    M4817: 'M4817',
    /** השתקת התראות מהמערכת לטלפון שלכם, בוצע בהצלחה למשך הזמן שהגדרתם */
    M4818: 'M4818',
    /** להשתקת התראות בעוד מספר דקות, הקישו 1, בעוד מספר שעות, הקישו 2, בעוד מספר ימים הקישו 3, בעוד מספר חודשים, הקישו 4 */
    M4819: 'M4819',
    /** הקישו את מספר הדקות שלאחיהן יתבצע השתקת התראות מהמערכת, ולסיום הקישו סולמית */
    M4820: 'M4820',
    /** הקישו את מספר השעות שלאחיהן יתבצע השתקת התראות מהמערכת, ולסיום הקישו סולמית */
    M4821: 'M4821',
    /** הקישו את מספר הימים שלאחיהן יתבצע השתקת התראות מהמערכת, ולסיום הקישו סולמית */
    M4822: 'M4822',
    /** הקישו את מספר החודשים שלאחיהן יתבצע השתקת התראות מהמערכת, ולסיום הקישו סולמית */
    M4823: 'M4823',
    /** הגדרת השתקת התראות מהמערכת לטלפון שלכם, בוצע בהצלחה החל מהזמן שהגדרתם ולצמיתות */
    M4824: 'M4824',
    /** הטלפון שלכם מושתק מקבלת התראות מהמערכת */
    M4825: 'M4825',
    /** הטלפון שלכם מושתק מקבלת התראות מהמערכת לצמיתות */
    M4826: 'M4826',
    /** מספר הטלפון שלכם מורשה לקבל התראות מהמערכת */
    M4827: 'M4827',
    /** עד */
    M4828: 'M4828',
    /** היום */
    M4829: 'M4829',
    /** בעוד */
    M4830: 'M4830',
    /** שעות */
    M4831: 'M4831',
    /** מחר */
    M4832: 'M4832',
    /** תאריך */
    M4833: 'M4833',
    /** בשעה */
    M4834: 'M4834',
    /** ו */
    M4835: 'M4835',
    /** דקות */
    M4836: 'M4836',
    /** אנא הקישו את המספר לחסימה, ובסיום הקישו סולמית */
    M4837: 'M4837',
    /** המספר שהקשתם הוגדר כחסום */
    M4838: 'M4838',
    /** הקליטו את שם המערכת אותו ברצונכם להשמיע למזמין ובסיום הקישו סולמית */
    M4839: 'M4839',
    /** אנא בחרו את הקבוצה שבה אתם מעוניינים לרכוש כרטיס */
    M4840: 'M4840',
    /** לקבוצה מסוג */
    M4841: 'M4841',
    /** לקוח יקר, אירוע זה דורש הזדהות. אנא הקישו את מספר תעודת הזהות שלכם, בסיום הקישו סולמית */
    M4847: 'M4847',
    /** האימות נכשל. אנא נסו שנית או פנוי למנהל האירוע */
    M4848: 'M4848',
    /** האימות בוצעה בהצלחה. */
    M4849: 'M4849',
    /** ניתן להזמין ילדים לפי כמות הכרטיסים לבוגרים, */
    M4850: 'M4850',
    /** כמות הכרטיסים לבוגרים שהוזמנה הינה x */
    M4851: 'M4851',
    /** לא נבחרו כרטיסים לבוגרים, יש לבחור תחילה כרטיסים לבוגרים ולאחר מכן לבחור כרטיסים לילדים */
    M4852: 'M4852',
    /** הנכם מוחזרים לבחירת סוג כרטיס */
    M4853: 'M4853',
    /** להלן ההזמנות שנמצאו */
    M4854: 'M4854',
    /** הזמנה על שם */
    M4855: 'M4855',
    /** בהזמנה זו יש */
    M4856: 'M4856',
    /** לשחזור ושליחה של הכרטיסים מהזמנה זו הקישו */
    M4857: 'M4857',
    /** הזמנה הבאה */
    M4858: 'M4858',
    /** מספר ההזמנה הוא */
    M4859: 'M4859',
    /** מספר האישור הוא */
    M4860: 'M4860',
    /** ההזמנה אותרה. אנא בחרו את הצורה בה תרצו לקבל את הכרטיסים. לקבל הכרטיסים בהודעת סמס לטלפון שתקישו - הקישו 1, לקבל הכרטיסים בפקס אותו תקישו הקישו 2, לקבלת הכרטיסים במייל אותו תקישו - הקישו 3 */
    M4861: 'M4861',
    /** אנא הקישו את מספר הטלפון אליו תרצו לקבל את הסמס עם הכרטיסים, מספר הטלפון לא חייב להיות הטלפון של מי שביצע את ההזמנה. בסיום הקישו סולמיצ */
    M4862: 'M4862',
    /** שימו לב, על מנת לשחזר הזמנה ללא מספר הזמנה יש לחייג באמצעות הטלפון ממנו בוצעה ההזמנה. */
    M4863: 'M4863',
    /** ציינתם שכתובת המייל שלכם מכילה רק ספרות לפני השתרודל. אנא הקישו את הספרות ובסיום הקישו סולמית */
    M4864: 'M4864',
    /** שימו לב, לא בחרתם ספק מייל, אי לכך יש להקיש את המייל במלואו. לשתטרודל יש להקיש 0000 וסולמית. לנקודה יש להקיש 1 וסולמית. */
    M4865: 'M4865',
    /** שליחת מייל. להקלדת המייל בצורה מלאה הקישו 9. תוכלו לחלופין לבחור ספק מייל ובכך לקצר את תהליך ההקלדה. */
    M4866: 'M4866',
    /** ציינתם את ספק האימייל שלכם. שימו לב. יש לסיים את ההקלדה ולא להקליד שתרודל בכלל, יש להקליד רק את הטקסט לפי השטרודך */
    M4867: 'M4867',
    /** הזמנתכם ביום - */
    M4868: 'M4868',
    /** בשעה */
    M4869: 'M4869',
    /** מיקום היציאה: */
    M4870: 'M4870',
    /** להלן פירוט הכרטיסים: */
    M4871: 'M4871',
    /** הנכם יוצאים ב */
    M4872: 'M4872',
    /** כמות הכרטיסים בהזמנה הוא: */
    M4873: 'M4873',
    /** שוקה שיווק - הפעולה בוצעה בהצלחה, בדקות הקרובות תקבלו שיחה חוזרת להמשך אימות */
    M4874: 'M4874',
    /** באפשרותכם לשמור את כרטיס האשראי לסליקות הבאות, פרטי הכרטיס יישמרו באופן מאובטח על ידי חברת האשראי, לשמירת פרטי הכרטיס הקישו 1 להמשך ללא שמירה הקישו 2 */
    M4880: 'M4880',
    /** העיסקה עברה בהצלחה והכרטיס נשמר לפעמים הבאות */
    M4881: 'M4881',
    /** העיסקה עברה בהצלחה אך לא הצלחנו לשמור את הכרטיס לפעמים הבאות */
    M4882: 'M4882',
    /** לפי המעודכן יש לכם פרטי כרטיס אשראי שמור במערכת, הכרטיס מסתיים בספרות */
    M4883: 'M4883',
    /** לביצוע סליקה עם הכרטיס השמור הקישו 1 וסולמית לסליקה עם כרטיס אחר הקישו את מספר הכרטיס ולסיום סולמית, למחיקת הכרטיס השמור הקישו 0 וסולמית */
    M4884: 'M4884',
    /** לפי המעודכן יש לכם כרטיסי אשראי שמורים במערכת, לשמיעת וביצוע סליקה עם הכרטיסים השמורים הקישו 1 להמשך עם כרטיס אחר הקישו 2 למחיקת כרטיסים שמורים הקישו 3 */
    M4885: 'M4885',
    /** לכרטיס המסתיים בספרות */
    M4886: 'M4886',
    /** הקישו */
    M4887: 'M4887',
    /** לאישור מחיקת כרטיס המסתיים בספרות */
    M4888: 'M4888',
    /** הקישו 1 לביטול הקישו 2 או המתינו */
    M4889: 'M4889',
    /** הכרטיס נמחק בהצלחה */
    M4890: 'M4890',
    /** מחיקת הכרטיס נכשלה */
    M4891: 'M4891',
    /** הסכום לתשלום בודד לפי מספר התשלומים שהקשתם אינו מגיע למינימום הנצרך, מינימום הסכום הנצרך לתשלום בודד הוא */
    M4892: 'M4892',
    /** הינכם מועברים להקשה מחדש של כמות התשלומים עד */
    M4893: 'M4893',
    /** חסר רשימת שיעורים בשלוחת היעד */
    M4900: 'M4900',
    /** יתרת השיעורים בחשבונך הוא */
    M4901: 'M4901',
    /** לדיוח על שיעור שבוצע הקישו 1, לשמיעת סך השיעורים שבוצעו הקישו 2, ליציאה הקישו 3 */
    M4902: 'M4902',
    /** נא הקישו את מספר המזהה של התלמיד ולסיום הקישו סולמית */
    M4903: 'M4903',
    /** אין יתרת שיעורים לתלמיד הנבחר, להקשת מספר תלמיד אחר הקישו 1 לסיום הקישו 2 */
    M4904: 'M4904',
    /** לדיוח על שיעורים שבוצעו היום הקישו 1, לדיוח על שיעורים בתאריך אחר הקישו 2 */
    M4905: 'M4905',
    /** נא הקישו את התאריך ב 8 ספרות, 2 ליום 2 לחודש ו 4 לשנה ולסיום הקישו סולמית */
    M4906: 'M4906',
    /** נא הקישו את מספר השיעורים שברצונכם לדווח על ביצוע ולסיום הקישו סולמית, ליציאה הקישו כוכבית וסולמית */
    M4907: 'M4907',
    /** הדיוח נקלט הצלחה */
    M4908: 'M4908',
    /** יתרת השיעורים בחשבון התלמיד נמוכה ממספר השיעורים שהינכם מבקשים לעדכן, יתרת השיעורים הוא */
    M4909: 'M4909',
    /** להקשת מספר שיעורים אחר הקישו 1, לסיום הקישו 2 */
    M4910: 'M4910',
    /** לחודש הנוכחי הקישו 1, לחודש אחר הקישו 2 */
    M4911: 'M4911',
    /** נא בחרו את החודש ב 6 ספרות, 2 לחודש, ו 4 לשנה */
    M4912: 'M4912',
    /** סך השיעורים שבוצעו בחודש הנבחר הוא */
    M4913: 'M4913',
    /** שגיאה בעדכון השיעורים */
    M4914: 'M4914',
    /** ברוכים הבאים */
    M5000: 'M5000',
    /** הודעה מיוחדת שתושמע ראשונה אם קיימת */
    M5001: 'M5001',
    /** הודעה זמנית */
    M5002: 'M5002',
    /** הודעה על חדר וועידה */
    M5003: 'M5003',
    /** יש לכם */
    M5004: 'M5004',
    /** הודעות אישיות חדשות. להאזנה הקישו 0 */
    M5005: 'M5005',
    /** הודעה אישית חדשה. להאזנה הקישו 0 */
    M5006: 'M5006',
    /** תפריט ראשי */
    M5007: 'M5007',
    /** מאזינים יקרים, שימו לב, כדי לקבל התראת צינתוק לטלפון שלכם כשמתעדכנת הודעה חדשה בקבוצה, עליכם להרשם בשלוחה 4. הקישו כעת 4 והירשמו לקבלת התראות מקבוצה זו. */
    M5009: 'M5009',
    /** פרשת בראשית */
    M5500: 'M5500',
    /** פרשת נח */
    M5501: 'M5501',
    /** פרשת לך לך */
    M5502: 'M5502',
    /** פרשת וירא */
    M5503: 'M5503',
    /** פרשת  חיי שרה */
    M5504: 'M5504',
    /** פרשת תולדות */
    M5505: 'M5505',
    /** פרשת ויצא */
    M5506: 'M5506',
    /** פרשת וישלח */
    M5507: 'M5507',
    /** פרשת וישב */
    M5508: 'M5508',
    /** פרשת מקץ */
    M5509: 'M5509',
    /** פרשת ויגש */
    M5510: 'M5510',
    /** פרשת ויחי */
    M5511: 'M5511',
    /** פרשת שמות */
    M5512: 'M5512',
    /** פרשת וארא */
    M5513: 'M5513',
    /** פרשת בו */
    M5514: 'M5514',
    /** פרשת בשלח */
    M5515: 'M5515',
    /** פרשת יתרו */
    M5516: 'M5516',
    /** פרשת משפטים */
    M5517: 'M5517',
    /** פרשת תרומה */
    M5518: 'M5518',
    /** פרשת תצווה */
    M5519: 'M5519',
    /** פרשת כיתשא */
    M5520: 'M5520',
    /** פרשת ויקהל */
    M5521: 'M5521',
    /** פרשת פיקודי */
    M5522: 'M5522',
    /** פרשת ויקרא */
    M5523: 'M5523',
    /** פרשת צו */
    M5524: 'M5524',
    /** פרשת שמיני */
    M5525: 'M5525',
    /** פרשת תזריע */
    M5526: 'M5526',
    /** פרשת מצורע */
    M5527: 'M5527',
    /** פרשת אחרי מות */
    M5528: 'M5528',
    /** פרשת קדושים */
    M5529: 'M5529',
    /** פרשת אמור */
    M5530: 'M5530',
    /** פרשת בהר */
    M5531: 'M5531',
    /** פרשת בחוקותי */
    M5532: 'M5532',
    /** פרשת במדבר */
    M5533: 'M5533',
    /** פרשת נשא */
    M5534: 'M5534',
    /** פרשת בהעלותך */
    M5535: 'M5535',
    /** פרשת שלח */
    M5536: 'M5536',
    /** פרשת קרח */
    M5537: 'M5537',
    /** פרשת חקת */
    M5538: 'M5538',
    /** פרשת בלק */
    M5539: 'M5539',
    /** פרשת פנחס */
    M5540: 'M5540',
    /** פרשת מטות */
    M5541: 'M5541',
    /** פרשת מסעי */
    M5542: 'M5542',
    /** פרשת דברים */
    M5543: 'M5543',
    /** פרשת ואתחנן */
    M5544: 'M5544',
    /** פרשת עקב */
    M5545: 'M5545',
    /** פרשת ראה */
    M5546: 'M5546',
    /** פרשת שופטים */
    M5547: 'M5547',
    /** פרשת כי תצא */
    M5548: 'M5548',
    /** פרשת כי תבוא */
    M5549: 'M5549',
    /** פרשת ניצבים */
    M5550: 'M5550',
    /** פרשת וילך */
    M5551: 'M5551',
    /** פרשת האזינו */
    M5552: 'M5552',
    /** וזאת הברכה */
    M5553: 'M5553',
    /** מספרכם אינו מזוהה במערכת, אנא חייגו ממספר מזוהה */
    M5555: 'M5555',
    /** ניתן לפתוח מערכת אחת בשבוע, אנא נסו שוב בשבוע הבא */
    M5556: 'M5556',
    /** לאחר הצליל אנא אמרו את שמכם המלא, שם פרטי ושם משפחה, לסיום הקישו סולמית. */
    M5557: 'M5557',
    /** שמכם כפי שנקלט במערכת הוא */
    M5558: 'M5558',
    /** לאישור הקישו 1 לתיקון הקישו 2 */
    M5559: 'M5559',
    /** אנא הקישו מספר זהות, לסיום הקישו סולמית */
    M5560: 'M5560',
    /** מספר תעודת הזהות שהקשתם אינו תקין, אנא נסו שנית. */
    M5561: 'M5561',
    /** אנא בחרו סיסמת ניהול */
    M5562: 'M5562',
    /** סיסמה קצרה מידי */
    M5563: 'M5563',
    /** לאישור הקישו 1 לתיקון הקישו 2 */
    M5564: 'M5564',
    /** לצערנו אין כעת מספרים פנויים להקצאה */
    M5565: 'M5565',
    /** מזל טוב פתחתם מערכת */
    M5566: 'M5566',
    /** סיסמת הניהול היא */
    M5567: 'M5567',
    /** לשמיעה חוזרת 1 לסיום 2 */
    M5568: 'M5568',
    /** להוספת שברי נקודות, הקישו כוכבית במקום נקודה. לדוגמה, להוספת 2 וחצי נקודות הקישו 2 כוכבית 5 וסולמית לסיום */
    M5570: 'M5570',
    /** עשיריות */
    M5571: 'M5571',
    /** מאיות */
    M5572: 'M5572',
    /** תר (שנה תף ריש) */
    M5600: 'M5600',
    /** יום ראשון */
    M5601: 'M5601',
    /** יום שני */
    M5602: 'M5602',
    /** יום שלישי */
    M5603: 'M5603',
    /** יום רביעי */
    M5604: 'M5604',
    /** יום חמישי */
    M5605: 'M5605',
    /** יום שישי */
    M5606: 'M5606',
    /** שבת */
    M5607: 'M5607',
    /** מוצאי שבת קודש */
    M5608: 'M5608',
    /** אין לך זכאות לחיוג, יש לרכוש חבילת חיוג מתאימה */
    M5660: 'M5660',
    /** אתה מחייג כעת ליעד בתשלום - הדקות ירדו מחבילת הדקות שרכשת - החיוב יחל לאחר הצליל בעוד כ3 שניות */
    M5661: 'M5661',
    /** לחבילה */
    M5662: 'M5662',
    /** הקישו */
    M5663: 'M5663',
    /** אנא בחרו חבילה לפי האפשרויות הבאות */
    M5664: 'M5664',
    /** בחרת חבילה.. */
    M5665: 'M5665',
    /** נא להקיש מספר תעודת זהות בן 9 ספרות */
    M5666: 'M5666',
    /** נא להקיש את ארבעת הספרות האחרונות של כרטיס האשראי */
    M5667: 'M5667',
    /** אשראי זה אינו קיים במערכת, הנכם מועברים להקשת מספר האשראי המלא */
    M5668: 'M5668',
    /** אנא אימרו את שמכם המלא לאחר הצליל, ולסיום הקישו סולמית */
    M5669: 'M5669',
    /** דיבור לא ברור. אנא אמרו שוב */
    M5670: 'M5670',
    /** לא הוקשה בחירה */
    M5671: 'M5671',
    /** המקש שהוקש שגוי אנא נסו שנית */
    M5672: 'M5672',
    /** אנא הקישו את מספר כרטיס האשראי משמאל לימין ובסיום הקישו סולמית ליציאה הקישו כוכבית וסולמית */
    M5673: 'M5673',
    /** לאישור הקישו 1 להקשה מחודשת 2 */
    M5674: 'M5674',
    /** תוקף הכרטיס שגוי - יש להקיש תוקף ב4 ספרות חודש ב2 ספרות ושנה ב2 ספרות. */
    M5675: 'M5675',
    /** אנא הקישו את תוקף הכרטיס */
    M5676: 'M5676',
    /** אנא הקישו את 3 הספרות בגב הכרטיס */
    M5677: 'M5677',
    /** חלה שגיאה - לרכישת חבילה, אנא פנו לשירות הלקוחות */
    M5678: 'M5678',
    /** תודה רבה ! החבילה נרכשה בהצלחה ! הנכם מוחזרים אוטומטית להמשך הפעולה המבוקשת */
    M5679: 'M5679',
    /** לאישור 1 לתנאים 2 לחזרה הקישו כוכבית */
    M5680: 'M5680',
    /** תש */
    M5700: 'M5700',
    /** תשא */
    M5701: 'M5701',
    /** תשב */
    M5702: 'M5702',
    /** תשג */
    M5703: 'M5703',
    /** תשד */
    M5704: 'M5704',
    /** תשה */
    M5705: 'M5705',
    /** תשו */
    M5706: 'M5706',
    /** תשז */
    M5707: 'M5707',
    /** תשח */
    M5708: 'M5708',
    /** תשט */
    M5709: 'M5709',
    /** תשי */
    M5710: 'M5710',
    /** תשיא */
    M5711: 'M5711',
    /** תשיב */
    M5712: 'M5712',
    /** תשיג */
    M5713: 'M5713',
    /** תשיד */
    M5714: 'M5714',
    /** תשטו */
    M5715: 'M5715',
    /** תשטז */
    M5716: 'M5716',
    /** תשיז */
    M5717: 'M5717',
    /** תשיח */
    M5718: 'M5718',
    /** תשיט */
    M5719: 'M5719',
    /** תשכ */
    M5720: 'M5720',
    /** תשכא */
    M5721: 'M5721',
    /** תשכב */
    M5722: 'M5722',
    /** תשכג */
    M5723: 'M5723',
    /** תשכד */
    M5724: 'M5724',
    /** תשכה */
    M5725: 'M5725',
    /** תשכו */
    M5726: 'M5726',
    /** תשכז */
    M5727: 'M5727',
    /** תשכח */
    M5728: 'M5728',
    /** תשכט */
    M5729: 'M5729',
    /** תשל */
    M5730: 'M5730',
    /** תשלא */
    M5731: 'M5731',
    /** תשלב */
    M5732: 'M5732',
    /** תשלג */
    M5733: 'M5733',
    /** תשלד */
    M5734: 'M5734',
    /** תשלה */
    M5735: 'M5735',
    /** תשלו */
    M5736: 'M5736',
    /** תשלז */
    M5737: 'M5737',
    /** תשלח */
    M5738: 'M5738',
    /** תשלט */
    M5739: 'M5739',
    /** תשמ */
    M5740: 'M5740',
    /** תשמא */
    M5741: 'M5741',
    /** תשמב */
    M5742: 'M5742',
    /** תשמג */
    M5743: 'M5743',
    /** תשמד */
    M5744: 'M5744',
    /** תשמה */
    M5745: 'M5745',
    /** תשמו */
    M5746: 'M5746',
    /** תשמז */
    M5747: 'M5747',
    /** תשמח */
    M5748: 'M5748',
    /** תשמט */
    M5749: 'M5749',
    /** תשנ */
    M5750: 'M5750',
    /** תשנא */
    M5751: 'M5751',
    /** תשנב */
    M5752: 'M5752',
    /** תשנג */
    M5753: 'M5753',
    /** תשנד */
    M5754: 'M5754',
    /** תשנה */
    M5755: 'M5755',
    /** תשנו */
    M5756: 'M5756',
    /** תשנז */
    M5757: 'M5757',
    /** תשנח */
    M5758: 'M5758',
    /** תשנט */
    M5759: 'M5759',
    /** תשס */
    M5760: 'M5760',
    /** תשסא */
    M5761: 'M5761',
    /** תשסב */
    M5762: 'M5762',
    /** תשסג */
    M5763: 'M5763',
    /** תשסד */
    M5764: 'M5764',
    /** תשסה */
    M5765: 'M5765',
    /** תשסו */
    M5766: 'M5766',
    /** תשסז */
    M5767: 'M5767',
    /** תשסח */
    M5768: 'M5768',
    /** תשסט */
    M5769: 'M5769',
    /** תשע */
    M5770: 'M5770',
    /** תשעא */
    M5771: 'M5771',
    /** תשעב */
    M5772: 'M5772',
    /** תשעג */
    M5773: 'M5773',
    /** תשעד */
    M5774: 'M5774',
    /** תשעה */
    M5775: 'M5775',
    /** תשעו */
    M5776: 'M5776',
    /** תשעז */
    M5777: 'M5777',
    /** תשעח */
    M5778: 'M5778',
    /** תשעט */
    M5779: 'M5779',
    /** תשפ */
    M5780: 'M5780',
    /** תשפא */
    M5781: 'M5781',
    /** תשפב */
    M5782: 'M5782',
    /** תשפג */
    M5783: 'M5783',
    /** תשפד */
    M5784: 'M5784',
    /** תשפה */
    M5785: 'M5785',
    /** תשפו */
    M5786: 'M5786',
    /** תשפז */
    M5787: 'M5787',
    /** תשפח */
    M5788: 'M5788',
    /** תשפט */
    M5789: 'M5789',
    /** תשצ */
    M5790: 'M5790',
    /** תשצא */
    M5791: 'M5791',
    /** תשצב */
    M5792: 'M5792',
    /** תשצג */
    M5793: 'M5793',
    /** תשצד */
    M5794: 'M5794',
    /** תשצה */
    M5795: 'M5795',
    /** תשצו */
    M5796: 'M5796',
    /** תשצז */
    M5797: 'M5797',
    /** תשצח */
    M5798: 'M5798',
    /** תשצט */
    M5799: 'M5799',
    /** תת */
    M5800: 'M5800',
    /** א */
    M5801: 'M5801',
    /** ב */
    M5802: 'M5802',
    /** ג */
    M5803: 'M5803',
    /** ד */
    M5804: 'M5804',
    /** ה */
    M5805: 'M5805',
    /** ו */
    M5806: 'M5806',
    /** ז */
    M5807: 'M5807',
    /** ח */
    M5808: 'M5808',
    /** ט */
    M5809: 'M5809',
    /** י */
    M5810: 'M5810',
    /** יא */
    M5811: 'M5811',
    /** יב */
    M5812: 'M5812',
    /** יג */
    M5813: 'M5813',
    /** יד */
    M5814: 'M5814',
    /** טו */
    M5815: 'M5815',
    /** טז */
    M5816: 'M5816',
    /** יז */
    M5817: 'M5817',
    /** יח */
    M5818: 'M5818',
    /** יט */
    M5819: 'M5819',
    /** כ */
    M5820: 'M5820',
    /** כא */
    M5821: 'M5821',
    /** כב */
    M5822: 'M5822',
    /** כג */
    M5823: 'M5823',
    /** כד */
    M5824: 'M5824',
    /** כה */
    M5825: 'M5825',
    /** כו */
    M5826: 'M5826',
    /** כז */
    M5827: 'M5827',
    /** כח */
    M5828: 'M5828',
    /** כט */
    M5829: 'M5829',
    /** ל */
    M5830: 'M5830',
    /** לא */
    M5831: 'M5831',
    /** לב */
    M5832: 'M5832',
    /** לג */
    M5833: 'M5833',
    /** לד */
    M5834: 'M5834',
    /** לה */
    M5835: 'M5835',
    /** לו */
    M5836: 'M5836',
    /** לז */
    M5837: 'M5837',
    /** לח */
    M5838: 'M5838',
    /** לט */
    M5839: 'M5839',
    /** מ */
    M5840: 'M5840',
    /** מא */
    M5841: 'M5841',
    /** מב */
    M5842: 'M5842',
    /** מג */
    M5843: 'M5843',
    /** מד */
    M5844: 'M5844',
    /** מה */
    M5845: 'M5845',
    /** מו */
    M5846: 'M5846',
    /** מז */
    M5847: 'M5847',
    /** מח */
    M5848: 'M5848',
    /** מט */
    M5849: 'M5849',
    /** נ */
    M5850: 'M5850',
    /** ס */
    M5851: 'M5851',
    /** ע */
    M5852: 'M5852',
    /** פ */
    M5853: 'M5853',
    /** צ */
    M5854: 'M5854',
    /** ק */
    M5855: 'M5855',
    /** ר */
    M5856: 'M5856',
    /** ש */
    M5857: 'M5857',
    /** ת */
    M5858: 'M5858',
    /** תשרי */
    M5901: 'M5901',
    /** מר-חשון */
    M5902: 'M5902',
    /** כסלו */
    M5903: 'M5903',
    /** טבת */
    M5904: 'M5904',
    /** שבט */
    M5905: 'M5905',
    /** אדר */
    M5906: 'M5906',
    /** ניסן */
    M5907: 'M5907',
    /** אייר */
    M5908: 'M5908',
    /** סיון */
    M5909: 'M5909',
    /** תמוז */
    M5910: 'M5910',
    /** מנחם אב */
    M5911: 'M5911',
    /** אלול */
    M5912: 'M5912',
    /** אדר א */
    M5913: 'M5913',
    /** אדר ב */
    M5914: 'M5914',
    /** אנא הקישו את מספר התיקיה להעברה */
    M3346: 'M3346',
    /** אנא הקישו את מספר התיקיה לשיכפול */
    M3347: 'M3347',
    /** סך הניקוד לקבוצה בה הלקוח שייך הוא.. */
    M3517: 'M3517',
    /** סך הניקוד החדש בקבוצה שבה משוייך הלקוח, הוא.. */
    M3518: 'M3518',
    /** נא הקישו את המגדר שלכם, לזכר הקישו 1 לנקבה הקישו 2 */
    M5580: 'M5580',
    /** נא הקישו את הגיל שלכם ולסיום הקישו סולמית */
    M5581: 'M5581',
    /** נא הקישו את הגובה שלכם ב 3 ספרות, לדוגמה למטר 75 היקשו 175 */
    M5582: 'M5582',
    /** נא הקישו את המשקל שלכם ולאחמ"כ סולמית */
    M5583: 'M5583',
    /** תוצאת ה BMI שלכם היא */
    M5584: 'M5584',
    /** טוב מאוד ! ערך ה BMI בטווח הבריא, כדי להמשיך לשמור על בריאות תקינה כדי להתעמל ולשמור על תזונה בריאה */
    M5585: 'M5585',
    /** ערך ה BMI נמוך מהטווח המומלץ, כדי להימנע מחסרים תזונתיים כדי לפנות לייעוץ תזונתי */
    M5586: 'M5586',
    /** ערך ה BMI מצביע על עודף משקל, כדי למנוע סיבוכים הנובעים מעודף המשקל מומלץ לבצע שינויים באורח החיים, כדי לקבוע תור לייעוץ תזונה ולהירשם לסדנה לשינוי הרגלי אכילה */
    M5587: 'M5587',
    /** ערך ה BMI שלכם מצביע על השמנה בטווח העלול לפגוע בבריאותכם, כדי להימנע ממחלות כמו סכרת ומחלות לב, מומלץ לבצע שינויים באורח החיים, קבעו תור לייעוץ תזונה והירשמו לסדנה לשינויי הרגלי אכילה */
    M5588: 'M5588',
    /** יש להקיש גיל בטווח שבין 18 ל 120 */
    M5589: 'M5589',
    /** יש להקיש מספר בטווח ההקשה האפשרי */
    M5590: 'M5590',
    /** עברתם את סף הנקודות בהצלחה */
    M2468: 'M2468',
    /** לא עברתם את סף הנקודות הנדרש */
    M2469: 'M2469',
    /** להקשת קוד קופון הקישו 1, להמשך ללא קופון הקישו 2 */
    M5609: 'M5609',
    /** הקישו את הקופון שברשותכם ובסיום סולמית */
    M5610: 'M5610',
    /** הקופון שהקשתם מקנה החנה של... */
    M5611: 'M5611',
    /** אחוזים */
    M5612: 'M5612',
    /** שקלים */
    M5613: 'M5613',
    /** הקופון שהקשתם אינו קיים */
    M5614: 'M5614',
    /** קיימת שגיאה בקופון שהקשתם, נא לפנות למנהל */
    M5615: 'M5615'
};

exports.CallError = CallError;
exports.ExitError = ExitError;
exports.HangupError = HangupError;
exports.SYSTEM_MESSAGE_CODES = SYSTEM_MESSAGE_CODES;
exports.TimeoutError = TimeoutError;
exports.YemotRouter = YemotRouter;
